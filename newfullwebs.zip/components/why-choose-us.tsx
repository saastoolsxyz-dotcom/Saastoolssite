"use client"

import { Shield, Zap, Lock, TrendingUp, Users, Award } from "lucide-react"

export default function WhyChooseUs() {
  const benefits = [
    {
      icon: Zap,
      title: "Lightning Fast",
      description: "Experience unprecedented speed with our optimized AI models that deliver results in seconds.",
      gradient: "from-blue-500 to-cyan-500",
    },
    {
      icon: Shield,
      title: "Enterprise Security",
      description: "Bank-level encryption and security protocols keep your data safe and private at all times.",
      gradient: "from-purple-500 to-pink-500",
    },
    {
      icon: Lock,
      title: "Privacy First",
      description: "Your data stays yours. We never store, sell, or share your information with third parties.",
      gradient: "from-amber-500 to-orange-500",
    },
    {
      icon: TrendingUp,
      title: "Always Improving",
      description: "Regular updates with new features and models keep you at the cutting edge of AI technology.",
      gradient: "from-green-500 to-emerald-500",
    },
    {
      icon: Users,
      title: "Built for Teams",
      description: "Collaborate seamlessly with team members and scale your productivity without limits.",
      gradient: "from-indigo-500 to-blue-500",
    },
    {
      icon: Award,
      title: "Quality Guaranteed",
      description: "Production-ready outputs that meet professional standards every single time.",
      gradient: "from-rose-500 to-red-500",
    },
  ]

  return (
    <section className="py-24 px-4 bg-gradient-to-br from-slate-50 via-white to-blue-50 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute top-0 left-0 w-96 h-96 bg-blue-200/30 rounded-full blur-3xl"></div>
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-purple-200/30 rounded-full blur-3xl"></div>

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Section Header */}
        <div className="text-center mb-20">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-100 border border-blue-200 mb-6">
            <Award className="w-4 h-4 text-blue-600" />
            <span className="text-xs font-bold text-blue-600 uppercase tracking-wider">Why Choose Us</span>
          </div>

          <h2 className="text-5xl md:text-6xl font-black text-slate-900 tracking-tight mb-6">
            Why Choose{" "}
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-600 via-purple-600 to-amber-500">
              saastools.xyz
            </span>
          </h2>

          <p className="text-xl text-slate-600 max-w-3xl mx-auto font-medium leading-relaxed">
            Join thousands of professionals who trust us to power their AI-driven workflows with unmatched reliability
            and performance.
          </p>
        </div>

        {/* Benefits Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {benefits.map((benefit, index) => (
            <div
              key={index}
              className="group relative bg-white rounded-3xl p-8 border border-slate-200 shadow-lg hover:shadow-2xl transition-all duration-500 hover:-translate-y-2"
            >
              {/* Gradient background on hover */}
              <div
                className={`absolute inset-0 bg-gradient-to-br ${benefit.gradient} rounded-3xl opacity-0 group-hover:opacity-5 transition-opacity duration-500`}
              ></div>

              {/* Icon */}
              <div
                className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${benefit.gradient} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-500 shadow-lg`}
              >
                <benefit.icon className="w-8 h-8 text-white" />
              </div>

              {/* Content */}
              <h3 className="text-2xl font-bold text-slate-900 mb-4 group-hover:text-blue-600 transition-colors">
                {benefit.title}
              </h3>
              <p className="text-slate-600 leading-relaxed">{benefit.description}</p>

              {/* Decorative gradient line */}
              <div
                className={`h-1 w-0 group-hover:w-full bg-gradient-to-r ${benefit.gradient} rounded-full mt-6 transition-all duration-500`}
              ></div>
            </div>
          ))}
        </div>

        {/* CTA Section */}
        <div className="mt-20 text-center">
          <div className="inline-flex flex-col sm:flex-row items-center gap-4">
            <a
              href="/signup"
              className="px-10 py-5 text-lg font-bold text-white rounded-2xl bg-gradient-to-r from-blue-600 to-purple-600 shadow-2xl shadow-blue-300 hover:scale-105 transition-all"
            >
              Get Started Free
            </a>
            <a
              href="/about"
              className="px-10 py-5 text-lg font-bold text-slate-900 rounded-2xl border-2 border-slate-300 bg-white hover:bg-slate-50 transition-all"
            >
              Learn More
            </a>
          </div>
          <p className="text-sm text-slate-500 mt-6">No credit card required • Free forever plan available</p>
        </div>
      </div>
    </section>
  )
}
