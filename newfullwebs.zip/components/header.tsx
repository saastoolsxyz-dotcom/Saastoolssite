"use client"

import { useState } from "react"
import Link from "next/link"
import { Menu, X, LogIn, LogOut, Settings } from "lucide-react"
import { useAuth } from "@/lib/auth-context"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const { user, signOut, isAdmin } = useAuth()

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen)

  const getUserInitials = (email: string | null) => {
    if (!email) return "U"
    return email.charAt(0).toUpperCase()
  }

  return (
    <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-2 shrink-0">
            <img
              src="https://i.ibb.co/MDbqPgXH/IMG-20251214-081207.jpg"
              alt="SaasTools Icon"
              className="w-10 h-10 rounded-lg object-cover shadow-sm border border-white/20"
            />
            <img
              src="https://i.ibb.co/k6hz1MXV/1000100567-removebg-preview.png"
              alt="SaasTools"
              className="h-10 md:h-12 object-contain"
            />
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {[
              { label: "Home", path: "/" },
              { label: "Summarizer", path: "/summarizer" },
              { label: "Writer", path: "/writer" },
              { label: "Image Gen", path: "/image-gen" },
              { label: "Analyzer", path: "/analyzer" },
            ].map((item) => (
              <Link
                key={item.label}
                href={item.path}
                className="text-sm font-semibold text-slate-900 hover:text-blue-600 transition-colors"
              >
                {item.label}
              </Link>
            ))}
          </div>

          {/* Right Section */}
          <div className="flex items-center space-x-3">
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="flex items-center gap-2 px-3 py-2 rounded-xl hover:bg-slate-100 transition-colors">
                    <Avatar className="h-8 w-8">
                      <AvatarFallback className="bg-gradient-to-br from-blue-600 to-purple-600 text-white text-sm font-bold">
                        {getUserInitials(user.email)}
                      </AvatarFallback>
                    </Avatar>
                    <span className="hidden sm:inline text-sm font-semibold text-slate-900">
                      {user.email?.split("@")[0]}
                    </span>
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel>
                    <div className="flex flex-col">
                      <span className="text-sm font-semibold">My Account</span>
                      <span className="text-xs text-slate-500 truncate">{user.email}</span>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  {isAdmin && (
                    <>
                      <DropdownMenuItem asChild>
                        <Link href="/admin" className="cursor-pointer">
                          <Settings className="w-4 h-4 mr-2" />
                          Admin Dashboard
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                    </>
                  )}
                  <DropdownMenuItem onClick={() => signOut()} className="cursor-pointer text-red-600">
                    <LogOut className="w-4 h-4 mr-2" />
                    Sign Out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <div className="flex items-center gap-2">
                <Link
                  href="/login"
                  className="px-4 py-2 text-sm font-bold text-blue-600 hover:bg-blue-50 rounded-xl transition-all flex items-center gap-2"
                >
                  <LogIn className="w-4 h-4" />
                  <span className="hidden sm:inline">Sign In</span>
                </Link>
                <Link
                  href="/signup"
                  className="bg-gradient-to-r from-blue-600 to-blue-700 px-5 py-2 text-sm font-bold text-white rounded-xl shadow-lg shadow-blue-500/20 hover:shadow-xl hover:shadow-blue-500/30 transition-all"
                >
                  Sign Up
                </Link>
              </div>
            )}

            <button
              onClick={toggleMenu}
              className="md:hidden flex items-center justify-center p-2 rounded-xl bg-slate-50 text-blue-600"
              aria-label="Menu"
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden absolute top-16 left-0 right-0 bg-white border-b border-gray-100 shadow-xl p-4 space-y-2 animate-in slide-in-from-top-2">
          {[
            { label: "Home", path: "/" },
            { label: "Summarizer", path: "/summarizer" },
            { label: "Writer", path: "/writer" },
            { label: "Image Gen", path: "/image-gen" },
            { label: "Analyzer", path: "/analyzer" },
          ].map((item) => (
            <Link
              key={item.label}
              href={item.path}
              onClick={() => setIsMenuOpen(false)}
              className="block px-4 py-3 text-base font-semibold text-gray-800 hover:bg-blue-50 hover:text-blue-600 rounded-xl"
            >
              {item.label}
            </Link>
          ))}

          {user ? (
            <div className="pt-4 border-t border-slate-100 space-y-2">
              <div className="px-4 py-2">
                <div className="flex items-center gap-3">
                  <Avatar className="h-10 w-10">
                    <AvatarFallback className="bg-gradient-to-br from-blue-600 to-purple-600 text-white font-bold">
                      {getUserInitials(user.email)}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-sm font-semibold text-slate-900">{user.email?.split("@")[0]}</p>
                    <p className="text-xs text-slate-500 truncate">{user.email}</p>
                  </div>
                </div>
              </div>
              {isAdmin && (
                <Link
                  href="/admin"
                  onClick={() => setIsMenuOpen(false)}
                  className="flex items-center gap-2 px-4 py-3 text-sm font-semibold text-slate-900 hover:bg-blue-50 rounded-xl"
                >
                  <Settings className="w-4 h-4" />
                  Admin Dashboard
                </Link>
              )}
              <button
                onClick={() => {
                  signOut()
                  setIsMenuOpen(false)
                }}
                className="w-full flex items-center gap-2 px-4 py-3 text-sm font-semibold text-red-600 hover:bg-red-50 rounded-xl"
              >
                <LogOut className="w-4 h-4" />
                Sign Out
              </button>
            </div>
          ) : (
            <div className="pt-4 grid grid-cols-2 gap-3 border-t border-slate-100">
              <Link
                href="/login"
                onClick={() => setIsMenuOpen(false)}
                className="flex items-center justify-center px-4 py-3 text-sm font-bold text-blue-600 bg-blue-50 rounded-xl"
              >
                Sign In
              </Link>
              <Link
                href="/signup"
                onClick={() => setIsMenuOpen(false)}
                className="flex items-center justify-center bg-gradient-to-r from-blue-600 to-blue-700 px-4 py-3 text-sm font-bold text-white rounded-xl"
              >
                Sign Up
              </Link>
            </div>
          )}
        </div>
      )}
    </nav>
  )
}
