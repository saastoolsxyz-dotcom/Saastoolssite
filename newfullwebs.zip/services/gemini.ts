import { GoogleGenAI } from "@google/genai"
import { getToolConfig } from "../utils/adminSettings"

// --- Interfaces ---

export interface SummaryOptions {
  length: "short" | "medium" | "detailed"
  format: "paragraph" | "bullets" | "headline" | "action_items"
  style: "simple" | "formal" | "academic" | "creative"
  language?: string
  audience?: "general" | "expert" | "student" | "child"
}

export interface WriterOptions {
  type: string
  tone: string
  topic: string
  keywords?: string
  language?: string
  structure?: "standard" | "twitter_thread" | "linkedin_post" | "seo_blog"
}

export interface ImageGenOptions {
  aspectRatio: string
  style?: string
  mood?: string
  negativePrompt?: string
}

export interface CodeOptions {
  code: string
  sourceLang: string
  targetLang: string
  mode: "convert" | "debug" | "optimize" | "explain"
}

// --- Helpers ---

const callOpenRouter = async (model: string, apiKey: string, messages: any[], signal?: AbortSignal) => {
  if (!apiKey) throw new Error("OpenRouter API Key is missing. Please set it in Admin Dashboard.")

  const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "HTTP-Referer": window.location.origin,
      "X-Title": "SaasTools AI",
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: model || "mistralai/mistral-7b-instruct",
      messages: messages,
    }),
    signal,
  })

  if (!response.ok) {
    const err = await response.json().catch(() => ({ error: { message: "Unknown OpenRouter Error" } }))
    throw new Error(err.error?.message || `OpenRouter API Error: ${response.statusText}`)
  }

  const data = await response.json()
  return data.choices?.[0]?.message?.content || ""
}

const callHuggingFace = async (
  model: string,
  apiKey: string,
  input: string | any,
  task: "text" | "image" = "text",
  signal?: AbortSignal,
) => {
  if (!apiKey) throw new Error(`Hugging Face API Key is missing. Please add it to the Admin Panel for ${model}.`)

  let bodyData = input
  // If input is a base64 string and we need binary for HF
  if (task === "image" && typeof input === "string" && !input.startsWith("data:")) {
    const binary = atob(input)
    const array = new Uint8Array(binary.length)
    for (let i = 0; i < binary.length; i++) array[i] = binary.charCodeAt(i)
    bodyData = array
  }

  const response = await fetch(`https://router.huggingface.co/models/${model}`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey.trim()}`,
    },
    body: bodyData,
    signal,
  })

  if (!response.ok) {
    const errText = await response.text()
    let errorMessage = `Hugging Face Error (${response.status})`
    try {
      const errJson = JSON.parse(errText)
      errorMessage = errJson.error || errorMessage
    } catch {
      errorMessage = errText || errorMessage
    }

    if (response.status === 503) {
      throw new Error("Model is currently loading on Hugging Face. Please try again in 30 seconds.")
    }
    throw new Error(errorMessage)
  }

  if (task === "image") {
    const blob = await response.blob()
    return new Promise<string>((resolve, reject) => {
      const reader = new FileReader()
      reader.onloadend = () => {
        const base64 = (reader.result as string).split(",")[1]
        resolve(base64)
      }
      reader.onerror = () => reject(new Error("Failed to process image blob."))
      reader.readAsDataURL(blob)
    })
  } else {
    const data = await response.json()
    if (Array.isArray(data) && data[0]?.generated_text) {
      return data[0].generated_text
    }
    return typeof data === "string" ? data : JSON.stringify(data)
  }
}

// --- Service Functions ---

export const removeBackground = async (file: File, toolId = "bg-remover", signal?: AbortSignal): Promise<string> => {
  const config = getToolConfig(toolId)
  const arrayBuffer = await file.arrayBuffer()
  const bytes = new Uint8Array(arrayBuffer)

  if (config.provider === "huggingface") {
    const model = config.model || "briaai/RMBG-1.4"
    return await callHuggingFace(model, config.apiKey, bytes, "image", signal)
  }
  throw new Error(`Background removal requires a Hugging Face API key. Please check your Admin Panel.`)
}

export const summarizeContent = async (
  input: string,
  inputType: "text" | "url" | "file",
  options: SummaryOptions,
  mimeType = "text/plain",
  toolId = "summarizer",
  signal?: AbortSignal,
): Promise<string> => {
  const config = getToolConfig(toolId)

  let lengthPrompt = ""
  switch (options.length) {
    case "short":
      lengthPrompt = "Concise (approx 100 words)."
      break
    case "medium":
      lengthPrompt = "Balanced (approx 300 words)."
      break
    case "detailed":
      lengthPrompt = "Comprehensive."
      break
  }
  const systemInstruction = `TASK: Summarize content. Length: ${lengthPrompt}, Format: ${options.format}, Tone: ${options.style}. Use Markdown.`

  let contentStr = input
  if (inputType === "url") contentStr = `Summarize this URL: ${input}`

  if (config.provider === "huggingface") {
    return await callHuggingFace(
      config.model,
      config.apiKey,
      `${systemInstruction}\n\nInput: ${contentStr}`,
      "text",
      signal,
    )
  }

  if (config.provider === "openrouter") {
    return await callOpenRouter(
      config.model,
      config.apiKey,
      [
        { role: "system", content: systemInstruction },
        { role: "user", content: contentStr },
      ],
      signal,
    )
  }

  const ai = new GoogleGenAI({ apiKey: config.apiKey })
  let contents: any = []
  let tools: any[] = []

  if (inputType === "url") {
    tools = [{ googleSearch: {} }]
    contents = [
      { role: "user", parts: [{ text: `Analyze and summarize this website: ${input}. \n\n${systemInstruction}` }] },
    ]
  } else if (inputType === "file") {
    contents = [
      {
        role: "user",
        parts: [
          { inlineData: { mimeType: mimeType, data: input } },
          { text: `Summarize based on instructions. \n\n${systemInstruction}` },
        ],
      },
    ]
  } else {
    contents = [{ role: "user", parts: [{ text: `Summarize this: \n\n${input}. \n\n${systemInstruction}` }] }]
  }

  const response = await ai.models.generateContent({
    model: config.model,
    contents,
    config: {
      systemInstruction,
      tools: tools.length > 0 ? tools : undefined,
    },
  })

  return response.text || "Could not generate summary."
}

export const generateSmartContent = async (
  options: WriterOptions,
  toolId = "writer",
  signal?: AbortSignal,
): Promise<string> => {
  const config = getToolConfig(toolId)
  const { type, tone, topic, keywords, language, structure } = options
  const systemInstruction = `Role: Professional copywriter. Task: Write a ${type} about "${topic}". Tone: ${tone}. Structure: ${structure}. Keywords: ${keywords || "None"}. Language: ${language || "English"}. Use Markdown.`

  if (config.provider === "huggingface") {
    return await callHuggingFace(
      config.model,
      config.apiKey,
      `${systemInstruction}\n\nUser Request: Write the content now.`,
      "text",
      signal,
    )
  }

  if (config.provider === "openrouter") {
    return await callOpenRouter(
      config.model,
      config.apiKey,
      [
        { role: "system", content: systemInstruction },
        { role: "user", content: `Write the content now.` },
      ],
      signal,
    )
  }

  const ai = new GoogleGenAI({ apiKey: config.apiKey })
  const response = await ai.models.generateContent({
    model: config.model,
    contents: `Write the content now.`,
    config: { systemInstruction },
  })

  return response.text || "Could not generate content."
}

export const generateAdvancedImage = async (
  prompt: string,
  options: ImageGenOptions,
  toolId = "image-gen",
  signal?: AbortSignal,
): Promise<string> => {
  const config = getToolConfig(toolId)
  const { aspectRatio, style, mood, negativePrompt } = options
  let richPrompt = prompt
  if (style && style !== "None") richPrompt += `, art style: ${style}`
  if (mood && mood !== "None") richPrompt += `, lighting/mood: ${mood}`
  if (negativePrompt) richPrompt += ` --no ${negativePrompt}`

  if (config.provider === "huggingface") {
    const res = await callHuggingFace(config.model, config.apiKey, richPrompt, "image", signal)
    return `data:image/png;base64,${res}`
  }

  const ai = new GoogleGenAI({ apiKey: config.apiKey })
  const response = await ai.models.generateContent({
    model: config.model.includes("image") ? config.model : "gemini-2.5-flash-image",
    contents: { parts: [{ text: richPrompt }] },
    config: { imageConfig: { aspectRatio: aspectRatio as any } },
  })

  if (response.candidates?.[0]?.content?.parts) {
    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        const base64EncodeString: string = part.inlineData.data
        const imageUrl = `data:image/png;base64,${base64EncodeString}`
        return imageUrl
      }
    }
  }
  throw new Error("No image data received.")
}

export const runGeminiPrompt = async (prompt: string, toolId = "generic", signal?: AbortSignal): Promise<string> => {
  const config = getToolConfig(toolId)

  if (config.provider === "huggingface") {
    return await callHuggingFace(config.model, config.apiKey, prompt, "text", signal)
  }

  if (config.provider === "openrouter") {
    return await callOpenRouter(config.model, config.apiKey, [{ role: "user", content: prompt }], signal)
  }

  const ai = new GoogleGenAI({ apiKey: config.apiKey })
  const response = await ai.models.generateContent({
    model: config.model,
    contents: prompt,
  })
  return response.text || "No response generated."
}

export const analyzeImageAdvanced = async (
  file: File,
  prompt: string,
  task: string,
  toolId = "analyzer",
): Promise<string> => {
  const config = getToolConfig(toolId)
  const ai = new GoogleGenAI({ apiKey: config.apiKey })
  const arrayBuffer = await file.arrayBuffer()
  const bytes = new Uint8Array(arrayBuffer)
  let binary = ""
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i])
  }
  const base64 = btoa(binary)

  let systemInstruction = "Analyze this image in detail."
  if (task === "ocr") systemInstruction = "You are an OCR expert. Extract all text from the image accurately."
  else if (task === "caption") systemInstruction = "Generate a short, descriptive caption for this image."

  const response = await ai.models.generateContent({
    model: config.model || "gemini-3-flash-preview",
    contents: {
      parts: [{ inlineData: { data: base64, mimeType: file.type } }, { text: prompt || "Analyze this image." }],
    },
    config: { systemInstruction },
  })
  return response.text || "No analysis generated."
}

export const processCode = async (options: CodeOptions, toolId = "code-converter"): Promise<string> => {
  const config = getToolConfig(toolId)
  const { code, sourceLang, targetLang, mode } = options
  let prompt = ""
  if (mode === "convert") prompt = `Convert this ${sourceLang} code to ${targetLang}:\n\n${code}`
  else if (mode === "debug") prompt = `Find bugs and fix this ${sourceLang} code:\n\n${code}`
  else if (mode === "optimize") prompt = `Optimize this ${sourceLang} code for better performance:\n\n${code}`
  else prompt = `Explain how this ${sourceLang} code works:\n\n${code}`

  const ai = new GoogleGenAI({ apiKey: config.apiKey })
  const response = await ai.models.generateContent({
    model: config.model || "gemini-3-flash-preview",
    contents: prompt,
  })
  return response.text || "No output generated."
}

export const solveMathProblem = async (
  problem: string,
  options: { toolId: string; concise?: boolean },
): Promise<string> => {
  const config = getToolConfig(options.toolId)
  const ai = new GoogleGenAI({ apiKey: config.apiKey })
  const systemInstruction = options.concise
    ? "Solve this math problem. Provide ONLY the final numerical answer or expression."
    : "Solve this math problem step-by-step. Use LaTeX for mathematical notation (wrap in $$ for blocks and $ for inline)."

  const response = await ai.models.generateContent({
    model: config.model || "gemini-3-flash-preview",
    contents: problem,
    config: { systemInstruction },
  })
  return response.text || "Could not solve problem."
}

export const extractTextFromPdf = async (file: File, toolId: string): Promise<string> => {
  const config = getToolConfig(toolId)
  const ai = new GoogleGenAI({ apiKey: config.apiKey })
  const arrayBuffer = await file.arrayBuffer()
  const bytes = new Uint8Array(arrayBuffer)
  let binary = ""
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i])
  }
  const base64 = btoa(binary)

  const response = await ai.models.generateContent({
    model: config.model || "gemini-3-flash-preview",
    contents: {
      parts: [
        { inlineData: { data: base64, mimeType: "application/pdf" } },
        { text: "Extract and return all text from this PDF document accurately." },
      ],
    },
  })
  return response.text || "No text found in PDF."
}

export const runSearchAnalysis = async (url: string, toolId: string): Promise<string> => {
  const config = getToolConfig(toolId)
  const ai = new GoogleGenAI({ apiKey: config.apiKey })
  const response = await ai.models.generateContent({
    model: config.model || "gemini-3-pro-preview",
    contents: `Analyze the SEO strategy, keywords, and content of this URL: ${url}`,
    config: {
      tools: [{ googleSearch: {} }],
    },
  })
  return response.text || "Analysis failed."
}

export const generateText = async (prompt: string, toolId = "generic", signal?: AbortSignal): Promise<string> => {
  const config = getToolConfig(toolId)

  if (config.provider === "huggingface") {
    return await callHuggingFace(config.model, config.apiKey, prompt, "text", signal)
  }

  if (config.provider === "openrouter") {
    return await callOpenRouter(config.model, config.apiKey, [{ role: "user", content: prompt }], signal)
  }

  const ai = new GoogleGenAI({ apiKey: config.apiKey })
  const response = await ai.models.generateContent({
    model: config.model,
    contents: prompt,
  })
  return response.text || "No response generated."
}
