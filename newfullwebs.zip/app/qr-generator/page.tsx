"use client"

import { useState } from "react"
import { Home, Download, AlertCircle, QrCodeIcon } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"

export default function QRGeneratorPage() {
  const [data, setData] = useState("")
  const [type, setType] = useState("url")
  const [qrCode, setQrCode] = useState<string | null>(null)
  const { toast } = useToast()

  const generateQR = () => {
    if (!data.trim()) {
      toast({
        title: "No Data",
        description: "Please enter data to generate QR code",
        variant: "destructive",
      })
      return
    }

    // Generate QR using placeholder (in production, use a QR library)
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(data)}`
    setQrCode(qrUrl)
    toast({
      title: "QR Code Generated!",
      description: "Your QR code is ready",
    })
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-gray-50 to-zinc-50 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <Link href="/">
            <Button variant="outline" className="gap-2 bg-transparent">
              <Home className="w-4 h-4" />
              Back to Home
            </Button>
          </Link>
        </div>

        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-slate-700 to-gray-800 mb-6 shadow-lg">
            <QrCodeIcon className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-5xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-slate-700 to-gray-800">
            QR Code Generator
          </h1>
          <p className="text-xl text-slate-600">Create custom QR codes instantly</p>
        </div>

        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <div className="bg-white rounded-3xl shadow-2xl p-8">
            <h3 className="font-bold text-lg mb-6">QR Code Data</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Type</label>
                <Select value={type} onValueChange={setType}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="url">URL</SelectItem>
                    <SelectItem value="text">Text</SelectItem>
                    <SelectItem value="email">Email</SelectItem>
                    <SelectItem value="phone">Phone</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Data</label>
                {type === "text" ? (
                  <Textarea
                    value={data}
                    onChange={(e) => setData(e.target.value)}
                    placeholder="Enter text..."
                    className="min-h-[150px]"
                  />
                ) : (
                  <Input
                    value={data}
                    onChange={(e) => setData(e.target.value)}
                    placeholder={
                      type === "url" ? "https://example.com" : type === "email" ? "email@example.com" : "+1234567890"
                    }
                  />
                )}
              </div>
            </div>
          </div>

          <div className="bg-white rounded-3xl shadow-2xl p-8">
            <h3 className="font-bold text-lg mb-4">Generated QR Code</h3>
            {qrCode ? (
              <div className="text-center">
                <img src={qrCode || "/placeholder.svg"} alt="QR Code" className="mx-auto mb-4 rounded-xl" />
                <a href={qrCode} download="qr-code.png">
                  <Button className="gap-2">
                    <Download className="w-4 h-4" />
                    Download QR Code
                  </Button>
                </a>
              </div>
            ) : (
              <div className="bg-slate-100 rounded-xl h-[300px] flex items-center justify-center">
                <p className="text-slate-400">QR code will appear here</p>
              </div>
            )}
          </div>
        </div>

        <div className="mt-8 mb-12 grid md:grid-cols-3 gap-6 text-left">
          <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200">
            <div className="w-10 h-10 rounded-full bg-slate-700 text-white flex items-center justify-center font-bold mb-4">
              1
            </div>
            <h4 className="font-bold mb-2">Input URL</h4>
            <p className="text-sm text-slate-600">
              Paste your link into the <strong>qr code generator</strong> to get started.
            </p>
          </div>
          <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200">
            <div className="w-10 h-10 rounded-full bg-slate-700 text-white flex items-center justify-center font-bold mb-4">
              2
            </div>
            <h4 className="font-bold mb-2">Instant Build</h4>
            <p className="text-sm text-slate-600">
              Click generate to <strong>create qr code free</strong> for your marketing.
            </p>
          </div>
          <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200">
            <div className="w-10 h-10 rounded-full bg-slate-700 text-white flex items-center justify-center font-bold mb-4">
              3
            </div>
            <h4 className="font-bold mb-2">Save Code</h4>
            <p className="text-sm text-slate-600">
              Download from our <strong>qr maker online</strong> in high resolution.
            </p>
          </div>
        </div>

        <div className="text-center">
          <Button onClick={generateQR} size="lg" className="px-12">
            Generate QR Code
          </Button>
        </div>

        <div className="prose prose-slate max-w-none bg-white/50 backdrop-blur rounded-3xl p-8 shadow-sm border border-slate-200 mt-12 mb-8 text-left">
          <h2 className="text-2xl font-bold mb-4">Versatile QR Code Generator for Modern Business Needs</h2>
          <p className="text-slate-600 mb-4">
            Connect your physical and digital worlds with our professional <strong>qr code generator</strong>.
            SaasTools.xyz makes it incredibly easy to <strong>create qr code free</strong> of charge for websites,
            business cards, or product packaging. As a leading <strong>qr maker online</strong>, we provide
            high-quality, scannable codes that ensure your audience can access your information with a single smartphone
            tap.
          </p>
          <p className="text-slate-600">
            Our platform is the top choice for users who need a reliable <strong>qr maker online</strong> for
            large-scale campaigns. When you choose to <strong>create qr code free</strong> with us, you get a clean,
            professional design that works perfectly with any scanner. Explore the endless possibilities of our{" "}
            <strong>qr code generator</strong> and bridge the gap between your offline and online presence today.
          </p>
        </div>

        <div className="mt-8 bg-slate-50 rounded-2xl p-6 border border-slate-200">
          <div className="flex gap-3">
            <AlertCircle className="w-5 h-5 text-slate-600 flex-shrink-0 mt-0.5" />
            <div className="text-sm text-slate-900">
              <p className="font-semibold mb-1">Keywords for SEO:</p>
              <p className="text-slate-700">
                qr code generator, create qr code free, qr maker online, custom qr code, qr code creator
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
