import type { Metadata } from "next"

import PDFCompressClient from "./pdf-compress-client"

export const metadata: Metadata = {
  title: "PDF Compressor Online Free - Reduce PDF Size | SaasTools.xyz",
  description:
    "Compress PDF files online for free. Reduce PDF size without losing quality. Fast, secure, and easy to use PDF compression tool.",
  keywords: ["compress pdf", "reduce pdf size", "pdf compressor online", "minimize pdf", "shrink pdf file"],
}

export default function PDFCompressPage() {
  return <PDFCompressClient />
}
