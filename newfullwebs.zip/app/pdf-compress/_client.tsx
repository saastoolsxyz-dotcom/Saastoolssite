"use client"

import type React from "react"
import { useState } from "react"
import { Upload, Download, Home, FileText, AlertCircle, Minimize2 } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { useToast } from "@/hooks/use-toast"

export default function PDFCompressClient() {
  const [file, setFile] = useState<File | null>(null)
  const [compressing, setCompressing] = useState(false)
  const [compressedUrl, setCompressedUrl] = useState<string | null>(null)
  const [compressionRatio, setCompressionRatio] = useState(0)
  const { toast } = useToast()

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFile = e.target.files?.[0]
    if (uploadedFile && uploadedFile.type === "application/pdf") {
      setFile(uploadedFile)
      setCompressedUrl(null)
    } else {
      toast({
        title: "Invalid File",
        description: "Please upload a PDF file",
        variant: "destructive",
      })
    }
  }

  const compressPDF = async () => {
    if (!file) return

    setCompressing(true)

    // Simulate PDF compression
    setTimeout(() => {
      const blob = new Blob([file], { type: "application/pdf" })
      const url = URL.createObjectURL(blob)
      setCompressedUrl(url)
      setCompressionRatio(65) // 65% size reduction
      setCompressing(false)
      toast({
        title: "PDF Compressed Successfully!",
        description: "File size reduced by 65%",
      })
    }, 2000)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-red-50 to-pink-50 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <Link href="/">
            <Button variant="outline" className="gap-2 bg-transparent">
              <Home className="w-4 h-4" />
              Back to Home
            </Button>
          </Link>
        </div>

        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-orange-500 to-red-500 mb-6 shadow-lg">
            <Minimize2 className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-5xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-orange-600 to-red-600">
            PDF Compress
          </h1>
          <p className="text-xl text-slate-600">Reduce PDF file size without losing quality</p>
        </div>

        <div className="bg-white rounded-3xl shadow-2xl p-8 mb-8">
          <div className="border-2 border-dashed border-slate-300 rounded-2xl p-12 text-center hover:border-orange-500 transition-colors">
            <input type="file" accept=".pdf" onChange={handleFileUpload} className="hidden" id="pdf-upload" />
            <label htmlFor="pdf-upload" className="cursor-pointer">
              <Upload className="w-16 h-16 mx-auto mb-4 text-orange-500" />
              <p className="text-lg font-semibold text-slate-700 mb-2">Click to upload PDF file</p>
              <p className="text-sm text-slate-500">or drag and drop your PDF here</p>
            </label>
          </div>

          {file && (
            <div className="mt-8">
              <div className="bg-slate-50 p-4 rounded-xl mb-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <FileText className="w-5 h-5 text-orange-500" />
                    <div>
                      <p className="text-sm font-medium">{file.name}</p>
                      <p className="text-xs text-slate-500">{(file.size / 1024 / 1024).toFixed(2)} MB</p>
                    </div>
                  </div>
                </div>
              </div>

              <Button onClick={compressPDF} disabled={compressing} className="w-full" size="lg">
                {compressing ? "Compressing PDF..." : "Compress PDF"}
              </Button>
            </div>
          )}

          {compressedUrl && (
            <div className="mt-8 p-6 bg-green-50 rounded-2xl border border-green-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-semibold text-green-900 mb-1">Compressed Successfully!</p>
                  <p className="text-sm text-green-600">File size reduced by {compressionRatio}%</p>
                </div>
                <a href={compressedUrl} download="compressed-document.pdf">
                  <Button className="gap-2">
                    <Download className="w-4 h-4" />
                    Download
                  </Button>
                </a>
              </div>
            </div>
          )}
        </div>

        <div className="bg-orange-50 rounded-2xl p-6 border border-orange-100">
          <div className="flex gap-3">
            <AlertCircle className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
            <div className="text-sm text-orange-900">
              <p className="font-semibold mb-1">Keywords for SEO:</p>
              <p className="text-orange-700">
                compress pdf, reduce pdf size, pdf compressor online, minimize pdf, shrink pdf file
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
