import type { Metadata } from "next"
import AnalyzerClient from "./analyzer-client"

export const metadata: Metadata = {
  title: "Vision AI Analyzer - Image Analyzer AI | AI Photo Analyzer | Identify Object in Image",
  description:
    "Professional image analyzer AI tool to identify object in image, extract text with OCR, and generate descriptions. Free AI photo analyzer and picture identifier online with visual search capabilities.",
  keywords:
    "image analyzer ai, ai photo analyzer, identify object in image, ai image description generator, image to text converter ai, visual search engine, picture identifier online, what is in this picture ai, read text from image ai",
}

export default function AnalyzerPage() {
  return <AnalyzerClient />
}
