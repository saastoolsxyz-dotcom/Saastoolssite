"use client"

import type React from "react"
import { useState, useRef } from "react"
import { ScanEye, Upload, Loader2, FileText, ImageIcon, Sparkles, Home, CheckCircle2, Info } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { analyzeImageAdvanced } from "@/services/gemini"
import Link from "next/link"

export default function AnalyzerClient() {
  const [image, setImage] = useState<string | null>(null)
  const [imageFile, setImageFile] = useState<File | null>(null)
  const [prompt, setPrompt] = useState("")
  const [task, setTask] = useState<"analyze" | "ocr" | "caption">("analyze")
  const [result, setResult] = useState("")
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    if (!file.type.startsWith("image/")) {
      toast({
        title: "Invalid File",
        description: "Please select an image file.",
        variant: "destructive",
      })
      return
    }

    setImageFile(file)
    const reader = new FileReader()
    reader.onload = (e) => {
      setImage(e.target?.result as string)
      setResult("")
    }
    reader.readAsDataURL(file)
  }

  const handleAnalyze = async () => {
    if (!imageFile) {
      toast({
        title: "No Image",
        description: "Please upload an image first.",
        variant: "destructive",
      })
      return
    }

    setIsAnalyzing(true)

    try {
      const analysisResult = await analyzeImageAdvanced(imageFile, prompt, task, "analyzer")
      setResult(analysisResult)

      toast({
        title: "Success",
        description: "Image analyzed successfully!",
      })
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to analyze image.",
        variant: "destructive",
      })
    } finally {
      setIsAnalyzing(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-white py-20 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <Link href="/">
            <Button variant="outline" className="rounded-2xl bg-transparent">
              <Home className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </Link>
        </div>

        <div className="text-center mb-16">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-amber-500 to-orange-600 shadow-xl shadow-amber-200 mb-6">
            <ScanEye className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-5xl md:text-6xl font-bold text-slate-900 mb-4 tracking-tight">Vision AI Analyzer</h1>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto text-balance">
            Identify objects, extract text, and describe images with advanced AI vision technology
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 mb-16">
          <div className="space-y-6">
            <Card className="p-8 bg-white/50 backdrop-blur-sm border-2 border-slate-200 rounded-3xl">
              <h3 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-2">
                <ImageIcon className="w-6 h-6 text-amber-500" />
                Upload Image
              </h3>

              {!image ? (
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="border-4 border-dashed border-slate-300 rounded-2xl p-16 text-center cursor-pointer hover:border-amber-500 transition-all hover:bg-amber-50"
                >
                  <Upload className="w-16 h-16 text-slate-400 mx-auto mb-4" />
                  <p className="text-slate-600 font-medium mb-2">Click to upload an image</p>
                  <p className="text-sm text-slate-400">PNG, JPG, WebP supported</p>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleFileSelect}
                    className="hidden"
                  />
                </div>
              ) : (
                <div className="relative rounded-2xl overflow-hidden">
                  <img src={image || "/placeholder.svg"} alt="To analyze" className="w-full h-auto" />
                  <Button
                    onClick={() => {
                      setImage(null)
                      setImageFile(null)
                      setResult("")
                      if (fileInputRef.current) fileInputRef.current.value = ""
                    }}
                    variant="secondary"
                    size="sm"
                    className="absolute top-4 right-4 rounded-xl"
                  >
                    Change Image
                  </Button>
                </div>
              )}
            </Card>

            <Card className="p-8 bg-white/50 backdrop-blur-sm border-2 border-slate-200 rounded-3xl">
              <h3 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-2">
                <Sparkles className="w-6 h-6 text-amber-500" />
                Analysis Options
              </h3>

              <div className="space-y-6">
                <div>
                  <Label className="text-sm font-bold text-slate-700 mb-2 block">Task Type</Label>
                  <Select value={task} onValueChange={(v: any) => setTask(v)}>
                    <SelectTrigger className="rounded-2xl">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="analyze">General Analysis</SelectItem>
                      <SelectItem value="ocr">Extract Text (OCR)</SelectItem>
                      <SelectItem value="caption">Generate Caption</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="prompt" className="text-sm font-bold text-slate-700 mb-2 block">
                    Custom Prompt (Optional)
                  </Label>
                  <Textarea
                    id="prompt"
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder="What specific aspects should I analyze?"
                    className="min-h-[100px] rounded-2xl"
                  />
                </div>

                <Button
                  onClick={handleAnalyze}
                  disabled={!image || isAnalyzing}
                  className="w-full bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white rounded-2xl py-6 text-lg font-bold shadow-xl shadow-amber-200"
                >
                  {isAnalyzing ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      <ScanEye className="w-5 h-5 mr-2" />
                      Analyze Image
                    </>
                  )}
                </Button>
              </div>
            </Card>
          </div>

          <Card className="p-8 bg-white/50 backdrop-blur-sm border-2 border-slate-200 rounded-3xl">
            <h3 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-2">
              <FileText className="w-6 h-6 text-amber-500" />
              Analysis Result
            </h3>

            {!result && !isAnalyzing && (
              <div className="border-4 border-dashed border-slate-300 rounded-2xl p-16 text-center min-h-[400px] flex items-center justify-center">
                <div>
                  <FileText className="w-20 h-20 text-slate-300 mx-auto mb-4" />
                  <p className="text-slate-400 text-lg">Analysis result will appear here</p>
                </div>
              </div>
            )}

            {isAnalyzing && (
              <div className="border-4 border-dashed border-amber-300 rounded-2xl p-16 text-center min-h-[400px] flex items-center justify-center bg-amber-50">
                <div>
                  <Loader2 className="w-20 h-20 text-amber-500 mx-auto mb-4 animate-spin" />
                  <p className="text-slate-700 font-medium text-lg">Analyzing image with AI...</p>
                </div>
              </div>
            )}

            {result && (
              <div className="prose max-w-none">
                <div className="bg-slate-50 rounded-2xl p-6 text-slate-700 whitespace-pre-wrap leading-relaxed">
                  {result}
                </div>
              </div>
            )}
          </Card>
        </div>

        <Card className="mt-16 p-8 md:p-12 bg-gradient-to-br from-white to-amber-50/30 border-2 border-amber-200 rounded-3xl">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center">
              <CheckCircle2 className="w-6 h-6 text-white" />
            </div>
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900">How to Use</h2>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-2xl border-2 border-slate-200 hover:border-amber-400 transition-all hover:shadow-lg">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center mb-4">
                <span className="text-white font-bold text-lg">1</span>
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-3">Upload Your Media</h3>
              <p className="text-slate-600 leading-relaxed">
                Select the image you want to investigate and upload it to the image analyzer ai.
              </p>
            </div>

            <div className="bg-white p-6 rounded-2xl border-2 border-slate-200 hover:border-amber-400 transition-all hover:shadow-lg">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center mb-4">
                <span className="text-white font-bold text-lg">2</span>
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-3">AI Identification</h3>
              <p className="text-slate-600 leading-relaxed">
                The system will automatically identify object in image components and analyze the visual data.
              </p>
            </div>

            <div className="bg-white p-6 rounded-2xl border-2 border-slate-200 hover:border-amber-400 transition-all hover:shadow-lg">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center mb-4">
                <span className="text-white font-bold text-lg">3</span>
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-3">Review Results</h3>
              <p className="text-slate-600 leading-relaxed">
                Use the ai image description generator to receive a detailed breakdown or use the image to text
                converter ai to extract written data from the file.
              </p>
            </div>
          </div>
        </Card>

        <Card className="mt-8 p-8 md:p-12 bg-gradient-to-br from-white to-amber-50/30 border-2 border-amber-200 rounded-3xl">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center">
              <Info className="w-6 h-6 text-white" />
            </div>
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900">Tool Description</h2>
          </div>

          <div className="space-y-6 text-slate-700 leading-relaxed text-lg">
            <p>
              The Vision AI Analyzer is a sophisticated{" "}
              <span className="font-semibold text-amber-700">image analyzer ai</span> designed to help users understand
              and extract data from any visual content. Whether you need to{" "}
              <span className="font-semibold text-amber-700">identify object in image</span> files for research or
              require a fast <span className="font-semibold text-amber-700">ai photo analyzer</span> for personal use,
              this tool provides instant insights. It functions as a powerful{" "}
              <span className="font-semibold text-amber-700">visual search engine</span>, allowing you to ask "what is
              in this picture ai" and receive accurate, context-aware descriptions via our{" "}
              <span className="font-semibold text-amber-700">ai image description generator</span>.
            </p>
            <p>
              In addition to identification, this <span className="font-semibold text-amber-700">ai vision tool</span>{" "}
              is highly effective for data extraction. Users can seamlessly{" "}
              <span className="font-semibold text-amber-700">read text from image ai</span> or utilize the{" "}
              <span className="font-semibold text-amber-700">image to text converter ai</span> to turn scanned documents
              into editable formats. As a comprehensive{" "}
              <span className="font-semibold text-amber-700">picture identifier online</span>, it simplifies complex
              visual tasks, making it an essential{" "}
              <span className="font-semibold text-amber-700">ai photo analyzer</span> for anyone needing to bridge the
              gap between images and information.
            </p>
          </div>
        </Card>
      </div>
    </div>
  )
}
