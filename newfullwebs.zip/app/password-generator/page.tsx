"use client"

import { useState } from "react"
import { Home, Copy, RefreshCw, AlertCircle, Shield } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Checkbox } from "@/components/ui/checkbox"
import { useToast } from "@/hooks/use-toast"

export default function PasswordGeneratorPage() {
  const [password, setPassword] = useState("")
  const [length, setLength] = useState([16])
  const [options, setOptions] = useState({
    uppercase: true,
    lowercase: true,
    numbers: true,
    symbols: true,
  })
  const { toast } = useToast()

  const generatePassword = () => {
    let chars = ""
    if (options.uppercase) chars += "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    if (options.lowercase) chars += "abcdefghijklmnopqrstuvwxyz"
    if (options.numbers) chars += "0123456789"
    if (options.symbols) chars += "!@#$%^&*()_+-=[]{}|;:,.<>?"

    if (!chars) {
      toast({
        title: "No Options Selected",
        description: "Please select at least one character type",
        variant: "destructive",
      })
      return
    }

    let newPassword = ""
    for (let i = 0; i < length[0]; i++) {
      newPassword += chars.charAt(Math.floor(Math.random() * chars.length))
    }
    setPassword(newPassword)
    toast({
      title: "Password Generated!",
      description: "Strong password created",
    })
  }

  const copyPassword = () => {
    navigator.clipboard.writeText(password)
    toast({
      title: "Copied!",
      description: "Password copied to clipboard",
    })
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 via-orange-50 to-yellow-50 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <Link href="/">
            <Button variant="outline" className="gap-2 bg-transparent">
              <Home className="w-4 h-4" />
              Back to Home
            </Button>
          </Link>
        </div>

        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-red-500 to-orange-500 mb-6 shadow-lg">
            <Shield className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-5xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-red-600 to-orange-600">
            Password Generator
          </h1>
          <p className="text-xl text-slate-600">Create strong, secure passwords</p>
        </div>

        <div className="bg-white rounded-3xl shadow-2xl p-8 mb-8">
          {password && (
            <div className="bg-slate-50 rounded-2xl p-6 mb-8 flex items-center justify-between">
              <code className="text-2xl font-mono font-bold">{password}</code>
              <Button variant="ghost" size="sm" onClick={copyPassword}>
                <Copy className="w-5 h-5" />
              </Button>
            </div>
          )}

          <div className="space-y-6 mb-8">
            <div>
              <label className="block text-sm font-medium mb-3">Password Length: {length[0]}</label>
              <Slider value={length} onValueChange={setLength} min={8} max={32} step={1} />
            </div>

            <div className="space-y-3">
              <label className="block text-sm font-medium">Character Types:</label>
              <div className="space-y-2">
                <label className="flex items-center gap-3">
                  <Checkbox
                    checked={options.uppercase}
                    onCheckedChange={(checked) => setOptions({ ...options, uppercase: !!checked })}
                  />
                  <span className="text-sm">Uppercase (A-Z)</span>
                </label>
                <label className="flex items-center gap-3">
                  <Checkbox
                    checked={options.lowercase}
                    onCheckedChange={(checked) => setOptions({ ...options, lowercase: !!checked })}
                  />
                  <span className="text-sm">Lowercase (a-z)</span>
                </label>
                <label className="flex items-center gap-3">
                  <Checkbox
                    checked={options.numbers}
                    onCheckedChange={(checked) => setOptions({ ...options, numbers: !!checked })}
                  />
                  <span className="text-sm">Numbers (0-9)</span>
                </label>
                <label className="flex items-center gap-3">
                  <Checkbox
                    checked={options.symbols}
                    onCheckedChange={(checked) => setOptions({ ...options, symbols: !!checked })}
                  />
                  <span className="text-sm">Symbols (!@#$%...)</span>
                </label>
              </div>
            </div>
          </div>

          <Button onClick={generatePassword} className="w-full" size="lg">
            <RefreshCw className="w-5 h-5 mr-2" />
            Generate Password
          </Button>

          <div className="mt-12 grid md:grid-cols-3 gap-6 text-left">
            <div className="p-6 rounded-2xl bg-red-50/50 border border-red-100">
              <div className="w-10 h-10 rounded-full bg-red-500 text-white flex items-center justify-center font-bold mb-4">
                1
              </div>
              <h4 className="font-bold mb-2">Choose Style</h4>
              <p className="text-sm text-slate-600">Select options in our **password generator** for security.</p>
            </div>
            <div className="p-6 rounded-2xl bg-red-50/50 border border-red-100">
              <div className="w-10 h-10 rounded-full bg-red-500 text-white flex items-center justify-center font-bold mb-4">
                2
              </div>
              <h4 className="font-bold mb-2">Build Pass</h4>
              <p className="text-sm text-slate-600">Use this **strong password maker** to generate a code.</p>
            </div>
            <div className="p-6 rounded-2xl bg-red-50/50 border border-red-100">
              <div className="w-10 h-10 rounded-full bg-red-500 text-white flex items-center justify-center font-bold mb-4">
                3
              </div>
              <h4 className="font-bold mb-2">Get Random</h4>
              <p className="text-sm text-slate-600">Instantly copy a **random password** for your new account.</p>
            </div>
          </div>
        </div>

        <div className="prose prose-slate max-w-none bg-white/50 backdrop-blur rounded-3xl p-8 shadow-sm border border-slate-200 mb-8">
          <h2 className="text-2xl font-bold mb-4">Highly Secure Password Generator for Ultimate Account Protection</h2>
          <p className="text-slate-600 mb-4">
            Protecting your online identity starts with our advanced **password generator**. SaasTools.xyz provides a
            robust **strong password maker** that creates complex strings of characters virtually impossible for hackers
            to guess. Whether you are securing your email, banking, or social media, our **random password** technology
            ensures that every credential you use is built on the highest security standards.
          </p>
          <p className="text-slate-600">
            Our platform is recognized as a premier **strong password maker** for both individuals and businesses. By
            generating a truly **random password**, you significantly reduce the risk of unauthorized access to your
            sensitive data. Experience peace of mind with our powerful **password generator** and take the first step
            toward a more secure digital life.
          </p>
        </div>

        <div className="bg-red-50 rounded-2xl p-6 border border-red-100">
          <div className="flex gap-3">
            <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
            <div className="text-sm text-red-900">
              <p className="font-semibold mb-1">Keywords for SEO:</p>
              <p className="text-red-700">
                password generator, strong password maker, random password, secure password generator, password creator
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
