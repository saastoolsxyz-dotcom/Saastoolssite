import Link from "next/link"
import { Calendar, Clock, ArrowRight } from "lucide-react"

export const metadata = {
  title: "Blog - SaasTools AI Toolkit",
  description: "Insights, tutorials, and updates about AI tools, productivity, and technology.",
}

const blogPosts = [
  {
    slug: "ai-revolution-2024",
    title: "The AI Revolution: How Machine Learning is Transforming Business in 2024",
    excerpt:
      "Discover how artificial intelligence and machine learning are reshaping industries, from content creation to data analysis, and what it means for the future of work.",
    author: "Sarah Chen",
    date: "December 20, 2024",
    readTime: "8 min read",
    category: "AI Trends",
    gradient: "from-blue-500 to-cyan-500",
    image: "/futuristic-ai-technology-abstract.jpg",
  },
  {
    slug: "boost-productivity-ai-tools",
    title: "10 AI Tools That Will 10x Your Productivity in 2025",
    excerpt:
      "From automated content generation to intelligent image editing, explore the essential AI tools that are helping professionals work smarter, not harder.",
    author: "Michael Rodriguez",
    date: "December 18, 2024",
    readTime: "6 min read",
    category: "Productivity",
    gradient: "from-purple-500 to-pink-500",
    image: "/productivity-workspace-with-modern-technology.jpg",
  },
  {
    slug: "beginners-guide-prompt-engineering",
    title: "The Beginner's Guide to Prompt Engineering: Getting Better AI Results",
    excerpt:
      "Learn the art and science of crafting effective prompts for AI models. Master techniques that will help you get more accurate, creative, and useful outputs.",
    author: "Emily Watson",
    date: "December 15, 2024",
    readTime: "10 min read",
    category: "Tutorial",
    gradient: "from-amber-500 to-orange-500",
    image: "/person-writing-on-computer-with-ai-assistance.jpg",
  },
  {
    slug: "ai-content-creation-seo",
    title: "AI-Powered Content Creation: The Future of SEO and Digital Marketing",
    excerpt:
      "Explore how AI is revolutionizing content strategy, SEO optimization, and digital marketing. Learn best practices for leveraging AI while maintaining authenticity.",
    author: "David Kim",
    date: "December 12, 2024",
    readTime: "7 min read",
    category: "Marketing",
    gradient: "from-green-500 to-teal-500",
    image: "/digital-marketing-dashboard.png",
  },
  {
    slug: "privacy-ai-era",
    title: "Privacy and Security in the AI Era: What You Need to Know",
    excerpt:
      "As AI tools become ubiquitous, understanding data privacy and security is crucial. Learn how to protect your information while leveraging powerful AI capabilities.",
    author: "Lisa Anderson",
    date: "December 10, 2024",
    readTime: "9 min read",
    category: "Security",
    gradient: "from-indigo-500 to-purple-500",
    image: "/cybersecurity-shield-with-lock-icon.jpg",
  },
]

export default function BlogPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      {/* Header */}
      <section className="pt-32 pb-16 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-blue-50 to-purple-50 border border-blue-200 mb-8">
            <span className="text-xs font-bold text-blue-600 uppercase tracking-widest">Insights & Updates</span>
          </div>

          <h1 className="text-5xl md:text-7xl font-black text-slate-900 mb-6 tracking-tight">
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600">
              SaasTools Blog
            </span>
          </h1>

          <p className="text-xl md:text-2xl text-slate-600 leading-relaxed font-medium max-w-3xl mx-auto">
            Explore the latest insights on AI, productivity, and technology. Learn how to get the most out of modern
            tools.
          </p>
        </div>
      </section>

      {/* Featured Post */}
      <section className="pb-12 px-4">
        <div className="max-w-6xl mx-auto">
          <Link href={`/blog/${blogPosts[0].slug}`}>
            <div className="bg-white rounded-3xl overflow-hidden shadow-xl border border-slate-200 hover:shadow-2xl transition-all group">
              <div className="grid md:grid-cols-2 gap-0">
                <div className="relative h-64 md:h-full min-h-[400px] overflow-hidden">
                  <img
                    src={blogPosts[0].image || "/placeholder.svg"}
                    alt={blogPosts[0].title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div
                    className={`absolute top-4 left-4 px-4 py-2 rounded-full bg-gradient-to-r ${blogPosts[0].gradient} text-white text-xs font-bold uppercase tracking-wider shadow-lg`}
                  >
                    Featured
                  </div>
                </div>
                <div className="p-8 md:p-12 flex flex-col justify-center">
                  <div className="flex items-center gap-4 text-sm text-slate-500 mb-4">
                    <span className="px-3 py-1 bg-slate-100 rounded-full font-semibold">{blogPosts[0].category}</span>
                    <div className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      <span>{blogPosts[0].date}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      <span>{blogPosts[0].readTime}</span>
                    </div>
                  </div>

                  <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4 group-hover:text-blue-600 transition-colors">
                    {blogPosts[0].title}
                  </h2>

                  <p className="text-lg text-slate-600 leading-relaxed mb-6">{blogPosts[0].excerpt}</p>

                  <div className="flex items-center justify-between">
                    <span className="text-slate-700 font-semibold">By {blogPosts[0].author}</span>
                    <div className="flex items-center gap-2 text-blue-600 font-bold group-hover:gap-4 transition-all">
                      Read More <ArrowRight className="w-5 h-5" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Link>
        </div>
      </section>

      {/* Blog Grid */}
      <section className="py-12 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-black text-slate-900 mb-12">Latest Articles</h2>

          <div className="grid md:grid-cols-2 gap-8">
            {blogPosts.slice(1).map((post, index) => (
              <Link key={index} href={`/blog/${post.slug}`}>
                <div className="bg-white rounded-3xl overflow-hidden shadow-lg border border-slate-200 hover:shadow-xl transition-all group h-full flex flex-col">
                  <div className="relative h-56 overflow-hidden">
                    <img
                      src={post.image || "/placeholder.svg"}
                      alt={post.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div
                      className={`absolute top-4 left-4 px-3 py-1 rounded-full bg-gradient-to-r ${post.gradient} text-white text-xs font-bold uppercase tracking-wider`}
                    >
                      {post.category}
                    </div>
                  </div>

                  <div className="p-8 flex flex-col flex-grow">
                    <div className="flex items-center gap-3 text-xs text-slate-500 mb-4">
                      <div className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        <span>{post.date}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        <span>{post.readTime}</span>
                      </div>
                    </div>

                    <h3 className="text-2xl font-bold text-slate-900 mb-3 group-hover:text-blue-600 transition-colors leading-tight">
                      {post.title}
                    </h3>

                    <p className="text-slate-600 leading-relaxed mb-6 flex-grow">{post.excerpt}</p>

                    <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                      <span className="text-sm text-slate-700 font-semibold">By {post.author}</span>
                      <ArrowRight className="w-5 h-5 text-blue-600 group-hover:translate-x-2 transition-transform" />
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter CTA */}
      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600 rounded-3xl p-12 text-center text-white shadow-2xl">
            <h2 className="text-3xl md:text-4xl font-black mb-4">Stay Updated</h2>
            <p className="text-lg md:text-xl mb-8 opacity-90">
              Get the latest AI insights and productivity tips delivered to your inbox every week.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 px-6 py-4 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-white"
              />
              <button className="px-8 py-4 bg-white text-blue-600 rounded-xl font-bold hover:bg-slate-50 transition-all shadow-lg hover:scale-105">
                Subscribe
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
