import ImageGenClientPage from "./clientPage"

export const metadata = {
  title: "AI Image Studio | Best Free AI Image Generator & Photo Maker",
  description:
    "Unlock your creativity with our professional AI image generator. Convert text to image using advanced AI photo generator technology for stunning visuals.",
  keywords:
    "ai image generator, text to image ai generator, free ai art generator, realistic ai image generator, ai drawing generator, ai photo generator",
}

export default function ImageGenPage() {
  return <ImageGenClientPage />
}
