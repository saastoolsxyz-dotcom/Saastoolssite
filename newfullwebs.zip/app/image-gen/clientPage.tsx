"use client"

import { useState } from "react"
import { ImageIcon, Loader2, Download, Wand2, Sparkles, Home } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { generateAdvancedImage, type ImageGenOptions } from "@/services/gemini"

export default function ImageGenClientPage() {
  const [prompt, setPrompt] = useState("")
  const [aspectRatio, setAspectRatio] = useState("1:1")
  const [style, setStyle] = useState("None")
  const [mood, setMood] = useState("None")
  const [negativePrompt, setNegativePrompt] = useState("")
  const [generatedImage, setGeneratedImage] = useState<string | null>(null)
  const [isGenerating, setIsGenerating] = useState(false)
  const [history, setHistory] = useState<Array<{ url: string; prompt: string }>>([])
  const { toast } = useToast()

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      toast({
        title: "Missing Prompt",
        description: "Please enter a description for your image.",
        variant: "destructive",
      })
      return
    }

    setIsGenerating(true)

    try {
      const options: ImageGenOptions = {
        aspectRatio,
        style: style !== "None" ? style : undefined,
        mood: mood !== "None" ? mood : undefined,
        negativePrompt: negativePrompt || undefined,
      }

      const imageUrl = await generateAdvancedImage(prompt, options, "image-gen")
      setGeneratedImage(imageUrl)
      setHistory([{ url: imageUrl, prompt }, ...history.slice(0, 5)])

      toast({
        title: "Success",
        description: "Image generated successfully!",
      })
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to generate image.",
        variant: "destructive",
      })
    } finally {
      setIsGenerating(false)
    }
  }

  const handleDownload = (url: string) => {
    const link = document.createElement("a")
    link.href = url
    link.download = `ai-generated-${Date.now()}.png`
    link.click()
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-white py-20 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <Button onClick={() => (window.location.href = "/")} variant="outline" className="rounded-2xl">
            <Home className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
        </div>

        <div className="text-center mb-16">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-purple-500 to-indigo-600 shadow-xl shadow-purple-200 mb-6">
            <Wand2 className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-5xl md:text-6xl font-bold text-slate-900 mb-4 text-balance">AI Image Studio</h1>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto text-pretty">
            Generate stunning artwork simply by describing your ideas in words with our professional AI image generator.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8 mb-16">
          <div className="lg:col-span-1">
            <Card className="p-6 bg-white/50 backdrop-blur-sm border-2 border-slate-200 rounded-3xl sticky top-8">
              <h3 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-2">
                <Sparkles className="w-6 h-6 text-purple-500" />
                Settings
              </h3>

              <div className="space-y-6">
                <div>
                  <Label htmlFor="prompt" className="text-sm font-bold text-slate-700 mb-2 block">
                    Prompt *
                  </Label>
                  <Textarea
                    id="prompt"
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder="A serene landscape with mountains at sunset..."
                    className="min-h-[120px] rounded-2xl"
                  />
                </div>

                <div>
                  <Label className="text-sm font-bold text-slate-700 mb-2 block">Aspect Ratio</Label>
                  <Select value={aspectRatio} onValueChange={setAspectRatio}>
                    <SelectTrigger className="rounded-2xl">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1:1">Square (1:1)</SelectItem>
                      <SelectItem value="16:9">Landscape (16:9)</SelectItem>
                      <SelectItem value="9:16">Portrait (9:16)</SelectItem>
                      <SelectItem value="4:3">Standard (4:3)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-sm font-bold text-slate-700 mb-2 block">Art Style</Label>
                  <Select value={style} onValueChange={setStyle}>
                    <SelectTrigger className="rounded-2xl">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="None">None</SelectItem>
                      <SelectItem value="Photorealistic">Photorealistic</SelectItem>
                      <SelectItem value="Oil Painting">Oil Painting</SelectItem>
                      <SelectItem value="Watercolor">Watercolor</SelectItem>
                      <SelectItem value="Digital Art">Digital Art</SelectItem>
                      <SelectItem value="Anime">Anime</SelectItem>
                      <SelectItem value="3D Render">3D Render</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-sm font-bold text-slate-700 mb-2 block">Mood/Lighting</Label>
                  <Select value={mood} onValueChange={setMood}>
                    <SelectTrigger className="rounded-2xl">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="None">None</SelectItem>
                      <SelectItem value="Dramatic">Dramatic</SelectItem>
                      <SelectItem value="Cinematic">Cinematic</SelectItem>
                      <SelectItem value="Soft">Soft</SelectItem>
                      <SelectItem value="Vibrant">Vibrant</SelectItem>
                      <SelectItem value="Dark">Dark</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="negative" className="text-sm font-bold text-slate-700 mb-2 block">
                    Negative Prompt
                  </Label>
                  <Textarea
                    id="negative"
                    value={negativePrompt}
                    onChange={(e) => setNegativePrompt(e.target.value)}
                    placeholder="blurry, low quality..."
                    className="min-h-[80px] rounded-2xl"
                  />
                </div>

                <Button
                  onClick={handleGenerate}
                  disabled={isGenerating}
                  className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white rounded-2xl py-6 text-lg font-bold shadow-xl shadow-purple-200"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Wand2 className="w-5 h-5 mr-2" />
                      Generate Image
                    </>
                  )}
                </Button>
              </div>
            </Card>
          </div>

          <div className="lg:col-span-2 space-y-8">
            <Card className="p-8 bg-white/50 backdrop-blur-sm border-2 border-slate-200 rounded-3xl">
              <h3 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-2">
                <ImageIcon className="w-6 h-6 text-purple-500" />
                Generated Image
              </h3>

              {!generatedImage && !isGenerating && (
                <div className="border-4 border-dashed border-slate-300 rounded-2xl p-16 text-center">
                  <ImageIcon className="w-20 h-20 text-slate-300 mx-auto mb-4" />
                  <p className="text-slate-400 text-lg">Your generated image will appear here</p>
                </div>
              )}

              {isGenerating && (
                <div className="border-4 border-dashed border-purple-300 rounded-2xl p-16 text-center bg-purple-50">
                  <Loader2 className="w-20 h-20 text-purple-500 mx-auto mb-4 animate-spin" />
                  <p className="text-slate-700 font-medium text-lg">Creating your masterpiece...</p>
                </div>
              )}

              {generatedImage && (
                <div>
                  <div className="rounded-2xl overflow-hidden mb-4">
                    <img src={generatedImage || "/placeholder.svg"} alt="Generated" className="w-full h-auto" />
                  </div>
                  <Button
                    onClick={() => handleDownload(generatedImage)}
                    className="w-full bg-purple-600 hover:bg-purple-700 rounded-2xl py-6"
                  >
                    <Download className="w-5 h-5 mr-2" />
                    Download Image
                  </Button>
                </div>
              )}
            </Card>

            {history.length > 0 && (
              <Card className="p-8 bg-white/50 backdrop-blur-sm border-2 border-slate-200 rounded-3xl">
                <h3 className="text-2xl font-bold text-slate-900 mb-6">Recent Generations</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {history.map((item, idx) => (
                    <div
                      key={idx}
                      className="relative group cursor-pointer rounded-xl overflow-hidden border-2 border-slate-200 hover:border-purple-400 transition-all"
                      onClick={() => setGeneratedImage(item.url)}
                    >
                      <img src={item.url || "/placeholder.svg"} alt={item.prompt} className="w-full h-auto" />
                      <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <Button size="sm" onClick={() => handleDownload(item.url)} className="rounded-xl">
                          <Download className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            )}
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-16">
          <Card className="p-8 bg-white/60 backdrop-blur-md border-2 border-slate-200 rounded-[2.5rem] shadow-sm">
            <h2 className="text-3xl font-bold text-slate-900 mb-6 flex items-center gap-3">
              <span className="flex items-center justify-center w-10 h-10 rounded-xl bg-purple-100 text-purple-600 text-xl font-bold">
                1
              </span>
              How to Use AI Image Studio
            </h2>
            <div className="space-y-6">
              <div className="flex gap-4">
                <div className="w-1.5 h-auto bg-gradient-to-b from-purple-500 to-indigo-500 rounded-full shrink-0" />
                <div>
                  <h3 className="font-bold text-slate-800 text-lg">Enter Your Prompt</h3>
                  <p className="text-slate-600 leading-relaxed">
                    Start by typing a detailed description of the image you want to create into the text to image ai
                    generator.
                  </p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="w-1.5 h-auto bg-gradient-to-b from-indigo-500 to-blue-500 rounded-full shrink-0" />
                <div>
                  <h3 className="font-bold text-slate-800 text-lg">Select Style</h3>
                  <p className="text-slate-600 leading-relaxed">
                    Choose specific artistic styles or themes to guide the ai drawing generator in creating your vision.
                  </p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="w-1.5 h-auto bg-gradient-to-b from-blue-500 to-cyan-500 rounded-full shrink-0" />
                <div>
                  <h3 className="font-bold text-slate-800 text-lg">Generate and Save</h3>
                  <p className="text-slate-600 leading-relaxed">
                    Click generate to let the ai image generator process your request, then download your high-quality
                    artwork.
                  </p>
                </div>
              </div>
            </div>
          </Card>

          <Card className="p-8 bg-white/60 backdrop-blur-md border-2 border-slate-200 rounded-[2.5rem] shadow-sm">
            <h2 className="text-3xl font-bold text-slate-900 mb-6 flex items-center gap-3">
              <Sparkles className="w-8 h-8 text-purple-500" />
              Tool Description
            </h2>
            <div className="prose prose-slate max-w-none">
              <p className="text-slate-600 leading-relaxed mb-4 text-pretty">
                Unlock your creativity with our professional{" "}
                <strong className="text-purple-600">ai image generator</strong>, designed to turn any imagination into
                high-quality visuals. This advanced text to image ai technology allows users to create stunning artwork
                simply by describing their ideas in words. Whether you are looking for a{" "}
                <strong className="text-slate-900">free ai art generator</strong> for personal projects or a{" "}
                <strong className="text-slate-900">realistic ai image generator</strong> for professional marketing, our
                studio provides top-tier results in seconds.
              </p>
              <p className="text-slate-600 leading-relaxed text-pretty">
                Our platform serves as a powerful <strong className="text-purple-600">ai photo generator</strong> that
                can be used to create everything from unique social media posts to complex digital illustrations. If you
                need an <strong className="text-slate-900">ai avatar generator</strong> for your online profile or a
                reliable midjourney alternative free of cost, our{" "}
                <strong className="text-slate-900">ai drawing generator</strong> is the perfect solution. Simply
                generate image from text to see why this is considered the best ai image generator for fast,
                high-fidelity AI art.
              </p>
            </div>
          </Card>
        </div>
      </div>
    </div>
  )
}
