"use client"

import { useState } from "react"
import { Home, CalculatorIcon, AlertCircle, Activity } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"

export default function BMICalculatorPage() {
  const [unit, setUnit] = useState("metric")
  const [weight, setWeight] = useState("")
  const [height, setHeight] = useState("")
  const [bmi, setBmi] = useState<number | null>(null)
  const [category, setCategory] = useState("")
  const { toast } = useToast()

  const calculateBMI = () => {
    const w = Number.parseFloat(weight)
    const h = Number.parseFloat(height)

    if (!w || !h) {
      toast({
        title: "Invalid Input",
        description: "Please enter valid weight and height",
        variant: "destructive",
      })
      return
    }

    let bmiValue = 0
    if (unit === "metric") {
      // kg and meters
      bmiValue = w / (h * h)
    } else {
      // pounds and inches
      bmiValue = (w / (h * h)) * 703
    }

    setBmi(Number.parseFloat(bmiValue.toFixed(1)))

    if (bmiValue < 18.5) setCategory("Underweight")
    else if (bmiValue < 25) setCategory("Normal weight")
    else if (bmiValue < 30) setCategory("Overweight")
    else setCategory("Obese")

    toast({
      title: "BMI Calculated!",
      description: `Your BMI is ${bmiValue.toFixed(1)}`,
    })
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-50 via-blue-50 to-indigo-50 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <Link href="/">
            <Button variant="outline" className="gap-2 bg-transparent">
              <Home className="w-4 h-4" />
              Back to Home
            </Button>
          </Link>
        </div>

        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-cyan-500 to-blue-500 mb-6 shadow-lg">
            <Activity className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-5xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-cyan-600 to-blue-600">
            BMI Calculator
          </h1>
          <p className="text-xl text-slate-600">Calculate your Body Mass Index</p>
        </div>

        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <div className="bg-white rounded-3xl shadow-2xl p-8">
            <h3 className="font-bold text-lg mb-6">Your Details</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Unit System</label>
                <Select value={unit} onValueChange={setUnit}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="metric">Metric (kg, m)</SelectItem>
                    <SelectItem value="imperial">Imperial (lbs, in)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Weight ({unit === "metric" ? "kg" : "lbs"})</label>
                <Input
                  type="number"
                  value={weight}
                  onChange={(e) => setWeight(e.target.value)}
                  placeholder={unit === "metric" ? "70" : "154"}
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">
                  Height ({unit === "metric" ? "meters" : "inches"})
                </label>
                <Input
                  type="number"
                  step="0.01"
                  value={height}
                  onChange={(e) => setHeight(e.target.value)}
                  placeholder={unit === "metric" ? "1.75" : "69"}
                />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-3xl shadow-2xl p-8">
            <h3 className="font-bold text-lg mb-6">Your BMI</h3>
            {bmi !== null ? (
              <div className="text-center">
                <div className="bg-gradient-to-br from-cyan-500 to-blue-500 rounded-3xl p-8 mb-6">
                  <p className="text-6xl font-bold text-white mb-2">{bmi}</p>
                  <p className="text-white/90 text-lg">{category}</p>
                </div>
                <div className="bg-slate-50 rounded-xl p-6 text-left">
                  <h4 className="font-semibold mb-3">BMI Categories:</h4>
                  <ul className="space-y-2 text-sm">
                    <li className="flex justify-between">
                      <span>Underweight</span>
                      <span className="text-slate-500">&lt; 18.5</span>
                    </li>
                    <li className="flex justify-between">
                      <span>Normal weight</span>
                      <span className="text-slate-500">18.5 - 24.9</span>
                    </li>
                    <li className="flex justify-between">
                      <span>Overweight</span>
                      <span className="text-slate-500">25 - 29.9</span>
                    </li>
                    <li className="flex justify-between">
                      <span>Obese</span>
                      <span className="text-slate-500">&ge; 30</span>
                    </li>
                  </ul>
                </div>
              </div>
            ) : (
              <div className="bg-slate-100 rounded-xl h-full flex items-center justify-center min-h-[300px]">
                <p className="text-slate-400">Enter your details to calculate BMI</p>
              </div>
            )}
          </div>
        </div>

        <div className="mt-8 mb-12 grid md:grid-cols-3 gap-6 text-left">
          <div className="p-6 rounded-2xl bg-cyan-50/50 border border-cyan-100">
            <div className="w-10 h-10 rounded-full bg-cyan-500 text-white flex items-center justify-center font-bold mb-4">
              1
            </div>
            <h4 className="font-bold mb-2">Enter Stats</h4>
            <p className="text-sm text-slate-600">
              Input your stats into the <strong>bmi calculator</strong> online.
            </p>
          </div>
          <div className="p-6 rounded-2xl bg-cyan-50/50 border border-cyan-100">
            <div className="w-10 h-10 rounded-full bg-cyan-500 text-white flex items-center justify-center font-bold mb-4">
              2
            </div>
            <h4 className="font-bold mb-2">Get Ratio</h4>
            <p className="text-sm text-slate-600">
              Our <strong>body mass index calculator</strong> will analyze your data.
            </p>
          </div>
          <div className="p-6 rounded-2xl bg-cyan-50/50 border border-cyan-100">
            <div className="w-10 h-10 rounded-full bg-cyan-500 text-white flex items-center justify-center font-bold mb-4">
              3
            </div>
            <h4 className="font-bold mb-2">Check Score</h4>
            <p className="text-sm text-slate-600">
              Perform a <strong>bmi check online</strong> to see your health status.
            </p>
          </div>
        </div>

        <div className="text-center">
          <Button onClick={calculateBMI} size="lg" className="px-12">
            <CalculatorIcon className="w-5 h-5 mr-2" />
            Calculate BMI
          </Button>
        </div>

        <div className="prose prose-slate max-w-none bg-white/50 backdrop-blur rounded-3xl p-8 shadow-sm border border-slate-200 mt-12 mb-8 text-left">
          <h2 className="text-2xl font-bold mb-4">Accurate BMI Calculator for Health and Fitness Tracking</h2>
          <p className="text-slate-600 mb-4">
            Monitoring your health metrics is simple with our professional-grade <strong>bmi calculator</strong>.
            SaasTools.xyz offers a reliable <strong>body mass index calculator</strong> that helps you understand your
            weight relative to your height. Whether you are starting a new fitness journey or just staying informed, our{" "}
            <strong>bmi check online</strong> provides instant feedback to help you make better lifestyle decisions.
          </p>
          <p className="text-slate-600">
            Our platform is the go-to <strong>body mass index calculator</strong> for users who prioritize accuracy and
            speed. When you perform a <strong>bmi check online</strong> with us, you receive a clear breakdown of your
            health category based on the latest global standards. Take control of your wellness today with our
            easy-to-use and high-precision <strong>bmi calculator</strong>.
          </p>
        </div>

        <div className="mt-8 bg-cyan-50 rounded-2xl p-6 border border-cyan-100">
          <div className="flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-cyan-500 to-blue-500 mb-6 shadow-lg">
            <AlertCircle className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-5xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-cyan-600 to-blue-600">
            BMI Calculator
          </h1>
          <p className="text-xl text-slate-600">Calculate your Body Mass Index</p>
        </div>
      </div>
    </div>
  )
}
