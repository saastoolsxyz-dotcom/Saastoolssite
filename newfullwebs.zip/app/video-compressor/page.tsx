"use client"

import type React from "react"

import { useState } from "react"
import { Upload, Home, Video, AlertCircle, Minimize2 } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { useToast } from "@/hooks/use-toast"

export default function VideoCompressorPage() {
  const [video, setVideo] = useState<File | null>(null)
  const [quality, setQuality] = useState([70])
  const [compressing, setCompressing] = useState(false)
  const { toast } = useToast()

  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file && file.type.startsWith("video/")) {
      setVideo(file)
    } else {
      toast({
        title: "Invalid File",
        description: "Please upload a video file",
        variant: "destructive",
      })
    }
  }

  const compressVideo = () => {
    if (!video) return
    setCompressing(true)
    setTimeout(() => {
      setCompressing(false)
      toast({
        title: "Video Compressed!",
        description: `Size reduced by ${100 - quality[0]}%`,
      })
    }, 3000)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-50 via-purple-50 to-fuchsia-50 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <Link href="/">
            <Button variant="outline" className="gap-2 bg-transparent">
              <Home className="w-4 h-4" />
              Back to Home
            </Button>
          </Link>
        </div>

        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-violet-500 to-purple-500 mb-6 shadow-lg">
            <Minimize2 className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-5xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-violet-600 to-purple-600">
            Video Compressor
          </h1>
          <p className="text-xl text-slate-600">Reduce video file size online</p>
        </div>

        <div className="bg-white rounded-3xl shadow-2xl p-8 mb-8">
          <div className="border-2 border-dashed border-slate-300 rounded-2xl p-12 text-center hover:border-violet-500 transition-colors">
            <input type="file" accept="video/*" onChange={handleVideoUpload} className="hidden" id="video-upload" />
            <label htmlFor="video-upload" className="cursor-pointer">
              <Upload className="w-16 h-16 mx-auto mb-4 text-violet-500" />
              <p className="text-lg font-semibold text-slate-700 mb-2">Click to upload video</p>
              <p className="text-sm text-slate-500">MP4, MOV, AVI, WebM supported</p>
            </label>
          </div>

          {video && (
            <div className="mt-8">
              <div className="bg-slate-50 p-4 rounded-xl mb-6">
                <div className="flex items-center gap-3">
                  <Video className="w-5 h-5 text-violet-500" />
                  <div>
                    <p className="text-sm font-medium">{video.name}</p>
                    <p className="text-xs text-slate-500">{(video.size / 1024 / 1024).toFixed(2)} MB</p>
                  </div>
                </div>
              </div>

              <div className="mb-6">
                <label className="block text-sm font-medium mb-2">Quality: {quality[0]}%</label>
                <Slider value={quality} onValueChange={setQuality} max={100} step={10} />
              </div>

              <Button onClick={compressVideo} disabled={compressing} className="w-full" size="lg">
                {compressing ? "Compressing..." : "Compress Video"}
              </Button>
            </div>
          )}
        </div>

        <div className="bg-violet-50 rounded-2xl p-6 border border-violet-100">
          <div className="flex gap-3">
            <AlertCircle className="w-5 h-5 text-violet-600 flex-shrink-0 mt-0.5" />
            <div className="text-sm text-violet-900">
              <p className="font-semibold mb-1">Keywords for SEO:</p>
              <p className="text-violet-700">
                compress video online, reduce video size, video compressor free, shrink video, minimize video
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
