export const metadata = {
  title: "Privacy Policy - SaasTools AI Toolkit",
  description: "Learn how we protect your data and respect your privacy at SaasTools.",
}

export default function PrivacyPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      <div className="max-w-4xl mx-auto px-4 py-20">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-50 border border-blue-200 mb-6">
            <span className="text-xs font-bold text-blue-600 uppercase tracking-widest">Legal</span>
          </div>
          <h1 className="text-5xl md:text-6xl font-black text-slate-900 mb-6 tracking-tight">Privacy Policy</h1>
          <p className="text-xl text-slate-500 font-medium">Last updated: December 24, 2024</p>
        </div>

        {/* Content */}
        <div className="prose prose-lg max-w-none">
          <div className="bg-white rounded-3xl p-8 md:p-12 shadow-lg border border-slate-200 mb-8">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Introduction</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              At SaasTools, we take your privacy seriously. This Privacy Policy explains how we collect, use, disclose,
              and safeguard your information when you use our AI toolkit platform. Please read this privacy policy
              carefully.
            </p>
            <p className="text-slate-600 leading-relaxed">
              By accessing or using our services, you agree to the collection and use of information in accordance with
              this policy. If you do not agree with our policies and practices, please do not use our services.
            </p>
          </div>

          <div className="bg-white rounded-3xl p-8 md:p-12 shadow-lg border border-slate-200 mb-8">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Information We Collect</h2>
            <h3 className="text-2xl font-bold text-slate-800 mb-3 mt-6">Personal Information</h3>
            <p className="text-slate-600 leading-relaxed mb-4">
              We may collect personal information that you voluntarily provide to us when you:
            </p>
            <ul className="list-disc list-inside text-slate-600 space-y-2 mb-4">
              <li>Register for an account</li>
              <li>Use our AI tools and services</li>
              <li>Subscribe to our newsletter</li>
              <li>Contact our support team</li>
              <li>Participate in surveys or promotions</li>
            </ul>
            <p className="text-slate-600 leading-relaxed">
              This information may include your name, email address, payment information, and any content you input into
              our AI tools.
            </p>

            <h3 className="text-2xl font-bold text-slate-800 mb-3 mt-6">Usage Data</h3>
            <p className="text-slate-600 leading-relaxed">
              We automatically collect certain information when you visit, use, or navigate our platform. This includes
              device information, browser type, IP address, pages visited, time spent on pages, and other diagnostic
              data.
            </p>
          </div>

          <div className="bg-white rounded-3xl p-8 md:p-12 shadow-lg border border-slate-200 mb-8">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">How We Use Your Information</h2>
            <p className="text-slate-600 leading-relaxed mb-4">We use the information we collect to:</p>
            <ul className="list-disc list-inside text-slate-600 space-y-2">
              <li>Provide, operate, and maintain our services</li>
              <li>Process your transactions and manage your account</li>
              <li>Improve and personalize your experience</li>
              <li>Develop new features and functionality</li>
              <li>Communicate with you about updates, security alerts, and support</li>
              <li>Send marketing communications (with your consent)</li>
              <li>Detect, prevent, and address technical issues and fraud</li>
              <li>Comply with legal obligations</li>
            </ul>
          </div>

          <div className="bg-white rounded-3xl p-8 md:p-12 shadow-lg border border-slate-200 mb-8">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Data Security</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              We implement industry-standard security measures to protect your personal information. This includes
              encryption, secure servers, and regular security audits. However, no method of transmission over the
              Internet is 100% secure, and we cannot guarantee absolute security.
            </p>
            <p className="text-slate-600 leading-relaxed">
              We retain your personal information only as long as necessary to fulfill the purposes outlined in this
              policy, unless a longer retention period is required by law.
            </p>
          </div>

          <div className="bg-white rounded-3xl p-8 md:p-12 shadow-lg border border-slate-200 mb-8">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Your Rights</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              Depending on your location, you may have the following rights:
            </p>
            <ul className="list-disc list-inside text-slate-600 space-y-2">
              <li>Access the personal information we hold about you</li>
              <li>Request correction of inaccurate data</li>
              <li>Request deletion of your personal information</li>
              <li>Object to processing of your personal information</li>
              <li>Request restriction of processing</li>
              <li>Data portability</li>
              <li>Withdraw consent at any time</li>
            </ul>
          </div>

          <div className="bg-white rounded-3xl p-8 md:p-12 shadow-lg border border-slate-200 mb-8">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Third-Party Services</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              We may use third-party service providers to help us operate our business and deliver services to you.
              These providers have access to your information only to perform specific tasks on our behalf and are
              obligated to protect your information.
            </p>
            <p className="text-slate-600 leading-relaxed">
              Our platform may contain links to third-party websites. We are not responsible for the privacy practices
              of these external sites.
            </p>
          </div>

          <div className="bg-white rounded-3xl p-8 md:p-12 shadow-lg border border-slate-200 mb-8">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Cookies and Tracking</h2>
            <p className="text-slate-600 leading-relaxed">
              We use cookies and similar tracking technologies to track activity on our platform and store certain
              information. You can instruct your browser to refuse all cookies or to indicate when a cookie is being
              sent. However, some parts of our service may not function properly without cookies.
            </p>
          </div>

          <div className="bg-white rounded-3xl p-8 md:p-12 shadow-lg border border-slate-200">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Contact Us</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              If you have any questions about this Privacy Policy, please contact us:
            </p>
            <div className="bg-slate-50 rounded-2xl p-6 border border-slate-200">
              <p className="text-slate-700 font-semibold mb-2">Email: privacy@saastools.com</p>
              <p className="text-slate-700 font-semibold">Address: 123 AI Street, Tech Valley, CA 94000</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
