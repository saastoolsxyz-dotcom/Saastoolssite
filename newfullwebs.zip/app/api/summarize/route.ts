import { streamText } from "ai"

export async function POST(req: Request) {
  const { prompt, tone, length } = await req.json()

  const systemPrompt = `You are a professional content summarizer. 
  Your goal is to provide a clear, accurate, and concise summary of the provided text.
  Tone: ${tone}
  Target length: approximately ${length}% of the original content.
  
  Instructions:
  - If tone is 'professional', use formal language and clear structure.
  - If tone is 'casual', use friendly, accessible language.
  - If tone is 'academic', focus on key arguments, methodology, and conclusions.
  - If tone is 'concise', use bullet points and extremely short sentences.
  - Always preserve the core meaning and key facts.`

  const result = await streamText({
    model: "openai/gpt-4o", // Using the AI Gateway default model
    system: systemPrompt,
    prompt: prompt,
  })

  return result.toUIMessageStreamResponse()
}
