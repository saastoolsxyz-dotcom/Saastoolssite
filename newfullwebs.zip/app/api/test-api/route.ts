import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { provider, apiKey, model } = await request.json()

    if (!apiKey) {
      return NextResponse.json({ success: false, error: "API key is required" }, { status: 400 })
    }

    // Test based on provider
    if (provider === "google") {
      // Test Google Gemini API
      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/${model || "gemini-pro"}:generateContent?key=${apiKey}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contents: [{ parts: [{ text: "Say hello" }] }],
          }),
        },
      )

      if (!response.ok) {
        const error = await response.text()
        return NextResponse.json({ success: false, error: `API Error: ${error}` }, { status: 400 })
      }

      return NextResponse.json({ success: true, message: "Google Gemini API is working!" })
    } else if (provider === "openrouter") {
      // Test OpenRouter API
      const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: model || "openai/gpt-3.5-turbo",
          messages: [{ role: "user", content: "Say hello" }],
          max_tokens: 10,
        }),
      })

      if (!response.ok) {
        const error = await response.text()
        return NextResponse.json({ success: false, error: `API Error: ${error}` }, { status: 400 })
      }

      return NextResponse.json({ success: true, message: "OpenRouter API is working!" })
    } else if (provider === "huggingface") {
      // Test Hugging Face API
      const response = await fetch(`https://router.huggingface.co/models/${model || "gpt2"}`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ inputs: "Hello" }),
      })

      if (!response.ok) {
        const error = await response.text()
        return NextResponse.json({ success: false, error: `API Error: ${error}` }, { status: 400 })
      }

      return NextResponse.json({ success: true, message: "Hugging Face API is working!" })
    }

    return NextResponse.json({ success: false, error: "Unknown provider" }, { status: 400 })
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message || "Test failed" }, { status: 500 })
  }
}
