"use client"

import { useState } from "react"
import { Home, Search, TrendingUp, AlertCircle, Copy } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useToast } from "@/hooks/use-toast"
import { generateText } from "@/services/gemini"

export default function KeywordResearchPage() {
  const [topic, setTopic] = useState("")
  const [keywords, setKeywords] = useState<string[]>([])
  const [loading, setLoading] = useState(false)
  const { toast } = useToast()

  const researchKeywords = async () => {
    if (!topic.trim()) {
      toast({
        title: "No Topic",
        description: "Please enter a topic to research",
        variant: "destructive",
      })
      return
    }

    setLoading(true)
    try {
      const result = await generateText(
        `Generate 20 high-volume SEO keywords related to: "${topic}". Include long-tail keywords, question-based keywords, and trending search terms. Format as a numbered list.`,
        "keyword-research",
      )
      const keywordList = result.split("\n").filter((k) => k.trim())
      setKeywords(keywordList)
      toast({
        title: "Keywords Generated!",
        description: `Found ${keywordList.length} keywords`,
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to research keywords",
        variant: "destructive",
      })
    }
    setLoading(false)
  }

  const copyKeywords = () => {
    navigator.clipboard.writeText(keywords.join("\n"))
    toast({
      title: "Copied!",
      description: "Keywords copied to clipboard",
    })
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-teal-50 to-cyan-50 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <Link href="/">
            <Button variant="outline" className="gap-2 bg-transparent">
              <Home className="w-4 h-4" />
              Back to Home
            </Button>
          </Link>
        </div>

        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-emerald-500 to-teal-500 mb-6 shadow-lg">
            <TrendingUp className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-5xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-emerald-600 to-teal-600">
            Keyword Research Tool
          </h1>
          <p className="text-xl text-slate-600">Find the best SEO keywords for your content</p>
        </div>

        <div className="bg-white rounded-3xl shadow-2xl p-8 mb-8">
          <div className="flex gap-4 mb-8">
            <Input
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="Enter your topic or niche..."
              className="text-lg"
              onKeyPress={(e) => e.key === "Enter" && researchKeywords()}
            />
            <Button onClick={researchKeywords} disabled={loading} size="lg">
              <Search className="w-5 h-5 mr-2" />
              {loading ? "Researching..." : "Research"}
            </Button>
          </div>

          {keywords.length > 0 && (
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-lg">Found Keywords ({keywords.length})</h3>
                <Button variant="ghost" size="sm" onClick={copyKeywords}>
                  <Copy className="w-4 h-4 mr-2" />
                  Copy All
                </Button>
              </div>
              <div className="bg-slate-50 rounded-2xl p-6 max-h-[500px] overflow-y-auto">
                <ul className="space-y-2">
                  {keywords.map((keyword, index) => (
                    <li key={index} className="flex items-start gap-3 text-sm">
                      <TrendingUp className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                      <span>{keyword}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          )}

          <div className="mt-12 grid md:grid-cols-3 gap-6">
            <div className="p-6 rounded-2xl bg-emerald-50/50 border border-emerald-100">
              <div className="w-10 h-10 rounded-full bg-emerald-500 text-white flex items-center justify-center font-bold mb-4">
                1
              </div>
              <h4 className="font-bold mb-2">Enter Topic</h4>
              <p className="text-sm text-slate-600">Type your niche into our **keyword research tool** to start.</p>
            </div>
            <div className="p-6 rounded-2xl bg-emerald-50/50 border border-emerald-100">
              <div className="w-10 h-10 rounded-full bg-emerald-500 text-white flex items-center justify-center font-bold mb-4">
                2
              </div>
              <h4 className="font-bold mb-2">Analyze Data</h4>
              <p className="text-sm text-slate-600">Discover winning **seo keywords** for your next campaign.</p>
            </div>
            <div className="p-6 rounded-2xl bg-emerald-50/50 border border-emerald-100">
              <div className="w-10 h-10 rounded-full bg-emerald-500 text-white flex items-center justify-center font-bold mb-4">
                3
              </div>
              <h4 className="font-bold mb-2">Get Results</h4>
              <p className="text-sm text-slate-600">Use our **keyword finder free** to save your search terms.</p>
            </div>
          </div>
        </div>

        <div className="prose prose-slate max-w-none bg-white/50 backdrop-blur rounded-3xl p-8 shadow-sm border border-slate-200 mb-8">
          <h2 className="text-2xl font-bold mb-4">Advanced Keyword Research Tool for Dominating Search Rankings</h2>
          <p className="text-slate-600 mb-4">
            Unlock the secret to high-traffic content with our professional **keyword research tool**. SaasTools.xyz
            provides real-time access to valuable **seo keywords** that help your website rank higher on search engines.
            Whether you are a digital marketer or a blogger, our **keyword finder free** service gives you the insights
            needed to target the right audience and outshine your competition.
          </p>
          <p className="text-slate-600">
            Our platform is designed to be the most comprehensive **keyword finder free** online, offering a deep dive
            into search trends. By identifying the most relevant **seo keywords**, our **keyword research tool**
            empowers you to create content that resonates with users. Start your journey toward search engine dominance
            with our powerful and intuitive data analysis platform.
          </p>
        </div>

        <div className="bg-emerald-50 rounded-2xl p-6 border border-emerald-100">
          <div className="flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-emerald-500 to-teal-500 mb-6 shadow-lg">
            <AlertCircle className="w-10 h-10 text-white" />
          </div>
          <h3 className="font-bold text-lg mb-4">Keywords for SEO</h3>
          <p className="text-sm text-slate-600">
            keyword research tool, seo keywords, keyword finder free, keyword planner, search volume tool
          </p>
        </div>
      </div>
    </div>
  )
}
