"use client"

import { useState } from "react"
import { Home, FileText, Download, AlertCircle } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import { generateText } from "@/services/gemini"

export default function ResumeBuilderPage() {
  const [formData, setFormData] = useState({
    name: "",
    title: "",
    experience: "",
    skills: "",
  })
  const [resume, setResume] = useState("")
  const [loading, setLoading] = useState(false)
  const { toast } = useToast()

  const generateResume = async () => {
    if (!formData.name || !formData.title) {
      toast({
        title: "Missing Information",
        description: "Please fill in at least name and job title",
        variant: "destructive",
      })
      return
    }

    setLoading(true)
    try {
      const prompt = `Create a professional resume for:
Name: ${formData.name}
Job Title: ${formData.title}
Experience: ${formData.experience}
Skills: ${formData.skills}

Generate a well-structured resume with sections for summary, experience, skills, and education.`

      const result = await generateText(prompt, "resume-builder")
      setResume(result)
      toast({
        title: "Resume Generated!",
        description: "Your professional resume is ready",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate resume",
        variant: "destructive",
      })
    }
    setLoading(false)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-blue-50 to-cyan-50 py-12 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <Link href="/">
            <Button variant="outline" className="gap-2 bg-transparent">
              <Home className="w-4 h-4" />
              Back to Home
            </Button>
          </Link>
        </div>

        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-indigo-500 to-blue-500 mb-6 shadow-lg">
            <FileText className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-5xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-blue-600">
            AI Resume Builder
          </h1>
          <p className="text-xl text-slate-600">Create professional resumes with AI</p>
        </div>

        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <div className="bg-white rounded-3xl shadow-2xl p-8">
            <h3 className="font-bold text-lg mb-6">Your Information</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Full Name *</label>
                <Input
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="John Doe"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Job Title *</label>
                <Input
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="Software Engineer"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Experience</label>
                <Textarea
                  value={formData.experience}
                  onChange={(e) => setFormData({ ...formData, experience: e.target.value })}
                  placeholder="Describe your work experience..."
                  className="min-h-[100px]"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Skills</label>
                <Textarea
                  value={formData.skills}
                  onChange={(e) => setFormData({ ...formData, skills: e.target.value })}
                  placeholder="List your skills..."
                  className="min-h-[100px]"
                />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-3xl shadow-2xl p-8">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-lg">Generated Resume</h3>
              {resume && (
                <Button variant="ghost" size="sm">
                  <Download className="w-4 h-4 mr-2" />
                  Download
                </Button>
              )}
            </div>
            <div className="bg-slate-50 rounded-xl p-6 min-h-[400px] whitespace-pre-wrap text-sm">
              {resume || "Your resume will appear here..."}
            </div>
          </div>
        </div>

        <div className="mt-8 mb-12 grid md:grid-cols-3 gap-6">
          <div className="p-6 rounded-2xl bg-indigo-50/50 border border-indigo-100">
            <div className="w-10 h-10 rounded-full bg-indigo-500 text-white flex items-center justify-center font-bold mb-4">
              1
            </div>
            <h4 className="font-bold mb-2">Fill Details</h4>
            <p className="text-sm text-slate-600">Enter your history into our **resume builder online** form.</p>
          </div>
          <div className="p-6 rounded-2xl bg-indigo-50/50 border border-indigo-100">
            <div className="w-10 h-10 rounded-full bg-indigo-500 text-white flex items-center justify-center font-bold mb-4">
              2
            </div>
            <h4 className="font-bold mb-2">AI Generation</h4>
            <p className="text-sm text-slate-600">Let our **ai resume maker** craft your professional summary.</p>
          </div>
          <div className="p-6 rounded-2xl bg-indigo-50/50 border border-indigo-100">
            <div className="w-10 h-10 rounded-full bg-indigo-500 text-white flex items-center justify-center font-bold mb-4">
              3
            </div>
            <h4 className="font-bold mb-2">Export CV</h4>
            <p className="text-sm text-slate-600">Use this **cv generator free** to download your job-ready file.</p>
          </div>
        </div>

        <div className="text-center">
          <Button onClick={generateResume} disabled={loading} size="lg" className="px-12">
            {loading ? "Generating..." : "Generate Resume"}
          </Button>
        </div>

        <div className="prose prose-slate max-w-none bg-white/50 backdrop-blur rounded-3xl p-8 shadow-sm border border-slate-200 mt-12 mb-8 text-left">
          <h2 className="text-2xl font-bold mb-4">AI-Powered Resume Builder for Modern Job Seekers</h2>
          <p className="text-slate-600 mb-4">
            Landing your dream job starts with a standout CV, and our **resume builder online** is here to help you
            create one in minutes. SaasTools.xyz offers an intelligent **ai resume maker** that understands industry
            standards and highlights your strengths effectively. As a comprehensive **cv generator free** of complicated
            steps, our tool simplifies the professional writing process so you can focus on your interview preparation.
          </p>
          <p className="text-slate-600">
            Our platform is recognized as a top-tier **cv generator free** for candidates at all career levels. Whether
            you are a fresh graduate or a seasoned executive, our **ai resume maker** provides the structural guidance
            needed for success. Experience the power of an automated **resume builder online** and present your
            professional story with confidence.
          </p>
        </div>

        <div className="mt-8 bg-indigo-50 rounded-2xl p-6 border border-indigo-100">
          <div className="flex gap-3">
            <AlertCircle className="w-5 h-5 text-indigo-600 flex-shrink-0 mt-0.5" />
            <div className="text-sm text-indigo-900">
              <p className="font-semibold mb-1">Keywords for SEO:</p>
              <p className="text-indigo-700">
                resume builder online, ai resume maker, cv generator free, professional resume creator, resume template
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
