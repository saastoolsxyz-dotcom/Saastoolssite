"use client"

import type React from "react"
import { useState, useRef } from "react"
import {
  Layers,
  Upload,
  Download,
  Loader2,
  ImageIcon,
  Home,
  CheckCircle2,
  ShieldCheck,
  Zap,
  MousePointer2,
  Settings2,
  DownloadCloud,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { useToast } from "@/components/ui/use-toast"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Link from "next/link"

export default function ImageCompressorClient() {
  const [image, setImage] = useState<string | null>(null)
  const [fileName, setFileName] = useState("")
  const [quality, setQuality] = useState([80])
  const [compressedImage, setCompressedImage] = useState<string | null>(null)
  const [originalSize, setOriginalSize] = useState(0)
  const [compressedSize, setCompressedSize] = useState(0)
  const [isProcessing, setIsProcessing] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + " B"
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + " KB"
    return (bytes / (1024 * 1024)).toFixed(2) + " MB"
  }

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    if (!file.type.startsWith("image/")) {
      toast({
        title: "Invalid File",
        description: "Please select an image file.",
        variant: "destructive",
      })
      return
    }

    setFileName(file.name)
    setOriginalSize(file.size)
    const reader = new FileReader()
    reader.onload = (e) => {
      setImage(e.target?.result as string)
      setCompressedImage(null)
    }
    reader.readAsDataURL(file)
  }

  const handleCompress = async () => {
    if (!image) return

    setIsProcessing(true)

    try {
      const img = new window.Image()
      img.src = image
      await new Promise((resolve) => {
        img.onload = resolve
      })

      const canvas = document.createElement("canvas")
      canvas.width = img.width
      canvas.height = img.height
      const ctx = canvas.getContext("2d")
      if (!ctx) throw new Error("Canvas context not available")

      ctx.drawImage(img, 0, 0)

      const compressed = canvas.toDataURL("image/jpeg", quality[0] / 100)
      setCompressedImage(compressed)

      const base64 = compressed.split(",")[1]
      const binary = atob(base64)
      setCompressedSize(binary.length)

      toast({
        title: "Success",
        description: "Image compressed successfully!",
      })
    } catch (error: any) {
      toast({
        title: "Error",
        description: "Failed to compress image.",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  const handleDownload = () => {
    if (!compressedImage) return
    const link = document.createElement("a")
    link.href = compressedImage
    link.download = `compressed-${fileName}`
    link.click()
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-red-50 via-white to-slate-50 py-20 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <Link href="/">
            <Button
              variant="outline"
              className="rounded-2xl bg-white/80 backdrop-blur-sm border-slate-200 hover:bg-white hover:border-red-500 transition-all group"
            >
              <Home className="w-4 h-4 mr-2 group-hover:scale-110 transition-transform" />
              Back to Home
            </Button>
          </Link>
        </div>

        <div className="text-center mb-16">
          <div className="inline-flex items-center justify-center w-24 h-24 rounded-[2.5rem] bg-gradient-to-br from-red-500 to-orange-600 shadow-2xl shadow-red-200 mb-8 animate-in fade-in zoom-in duration-700">
            <Layers className="w-12 h-12 text-white" />
          </div>
          <h1 className="text-5xl md:text-7xl font-extrabold text-slate-900 mb-6 tracking-tight">
            Image{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-600 to-orange-600">
              Compressor
            </span>
          </h1>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto leading-relaxed">
            Reduce image file size without losing quality using our professional-grade compression technology
          </p>
        </div>

        <Tabs defaultValue="compress" className="max-w-6xl mx-auto mb-20">
          <TabsList className="grid w-full grid-cols-1 mb-10 p-1 bg-slate-100 rounded-[2rem]">
            <TabsTrigger
              value="compress"
              className="rounded-[1.75rem] py-4 data-[state=active]:bg-white data-[state=active]:text-red-600 data-[state=active]:shadow-sm text-lg font-semibold transition-all"
            >
              Professional Compression Tool
            </TabsTrigger>
          </TabsList>

          <TabsContent value="compress">
            <div className="grid md:grid-cols-2 gap-10">
              <Card className="p-8 bg-white/80 backdrop-blur-md border-2 border-slate-100 rounded-[2.5rem] shadow-xl shadow-slate-200/50 hover:shadow-2xl hover:shadow-red-100/50 transition-all group overflow-hidden relative">
                <div className="absolute top-0 right-0 w-32 h-32 bg-red-500/5 rounded-full -mr-16 -mt-16 group-hover:bg-red-500/10 transition-colors" />

                <h3 className="text-2xl font-bold text-slate-900 mb-8 flex items-center gap-3">
                  <div className="p-2 rounded-xl bg-red-100">
                    <Upload className="w-6 h-6 text-red-600" />
                  </div>
                  Upload Image
                </h3>

                {!image ? (
                  <div
                    onClick={() => fileInputRef.current?.click()}
                    className="border-4 border-dashed border-slate-200 rounded-[2rem] p-16 text-center cursor-pointer hover:border-red-500 transition-all hover:bg-red-50/50 group/upload"
                  >
                    <div className="w-20 h-20 bg-slate-100 rounded-[1.5rem] flex items-center justify-center mx-auto mb-6 group-hover/upload:bg-red-100 group-hover/upload:scale-110 transition-all duration-500">
                      <Upload className="w-10 h-10 text-slate-400 group-hover/upload:text-red-600" />
                    </div>
                    <p className="text-xl text-slate-700 font-bold mb-2">Drop image here</p>
                    <p className="text-slate-500 mb-6">or click to browse from computer</p>
                    <div className="flex justify-center gap-3">
                      <span className="px-3 py-1 bg-slate-100 text-slate-500 text-xs font-bold rounded-full">PNG</span>
                      <span className="px-3 py-1 bg-slate-100 text-slate-500 text-xs font-bold rounded-full">JPG</span>
                      <span className="px-3 py-1 bg-slate-100 text-slate-500 text-xs font-bold rounded-full">WEBP</span>
                    </div>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleFileSelect}
                      className="hidden"
                    />
                  </div>
                ) : (
                  <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
                    <div className="rounded-[2rem] overflow-hidden mb-6 border-4 border-slate-50 shadow-inner group/preview relative">
                      <img src={image || "/placeholder.svg"} alt="Original" className="w-full h-auto" />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/preview:opacity-100 transition-opacity flex items-center justify-center">
                        <Button
                          variant="secondary"
                          onClick={() => fileInputRef.current?.click()}
                          className="rounded-xl"
                        >
                          Change Image
                        </Button>
                      </div>
                    </div>

                    <div className="bg-slate-50 rounded-2xl p-6 mb-8 flex items-center justify-between border border-slate-100">
                      <div>
                        <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Original Size</p>
                        <p className="text-2xl font-black text-slate-900">{formatFileSize(originalSize)}</p>
                      </div>
                      <div className="h-10 w-[1px] bg-slate-200" />
                      <div className="text-right">
                        <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Type</p>
                        <p className="text-lg font-bold text-slate-700">{fileName.split(".").pop()?.toUpperCase()}</p>
                      </div>
                    </div>

                    <div className="space-y-6">
                      <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100">
                        <div className="flex justify-between items-center mb-4">
                          <Label className="text-sm font-black text-slate-700 uppercase tracking-wider">
                            Compression Quality
                          </Label>
                          <span className="px-3 py-1 bg-red-600 text-white text-xs font-bold rounded-lg">
                            {quality[0]}%
                          </span>
                        </div>
                        <Slider
                          value={quality}
                          onValueChange={setQuality}
                          min={1}
                          max={100}
                          step={1}
                          className="py-4"
                        />
                        <p className="text-[10px] text-slate-400 mt-2 font-medium">
                          Lower quality results in smaller file sizes.
                        </p>
                      </div>

                      <Button
                        onClick={handleCompress}
                        disabled={isProcessing}
                        className="w-full h-16 bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-700 hover:to-orange-700 text-white rounded-[1.25rem] text-lg font-bold shadow-xl shadow-red-200 hover:shadow-red-300 hover:scale-[1.02] active:scale-[0.98] transition-all"
                      >
                        {isProcessing ? (
                          <>
                            <Loader2 className="w-6 h-6 mr-3 animate-spin" />
                            Processing...
                          </>
                        ) : (
                          <>
                            <Zap className="w-6 h-6 mr-3" />
                            Compress Now
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                )}
              </Card>

              <Card className="p-8 bg-white/80 backdrop-blur-md border-2 border-slate-100 rounded-[2.5rem] shadow-xl shadow-slate-200/50 hover:shadow-2xl hover:shadow-orange-100/50 transition-all group overflow-hidden relative">
                <div className="absolute top-0 right-0 w-32 h-32 bg-orange-500/5 rounded-full -mr-16 -mt-16 group-hover:bg-orange-500/10 transition-colors" />

                <h3 className="text-2xl font-bold text-slate-900 mb-8 flex items-center gap-3">
                  <div className="p-2 rounded-xl bg-orange-100">
                    <DownloadCloud className="w-6 h-6 text-orange-600" />
                  </div>
                  Result
                </h3>

                {!compressedImage ? (
                  <div className="border-4 border-dashed border-slate-100 rounded-[2rem] p-16 text-center min-h-[500px] flex flex-col items-center justify-center bg-slate-50/30">
                    <div className="w-24 h-24 bg-white rounded-[2rem] flex items-center justify-center shadow-sm mb-6">
                      <ImageIcon className="w-12 h-12 text-slate-200" />
                    </div>
                    <p className="text-slate-400 text-xl font-medium max-w-[200px] mx-auto leading-relaxed">
                      Compressed image will appear here
                    </p>
                  </div>
                ) : (
                  <div className="animate-in fade-in zoom-in duration-500">
                    <div className="rounded-[2rem] overflow-hidden mb-6 border-4 border-green-50 shadow-inner">
                      <img src={compressedImage || "/placeholder.svg"} alt="Compressed" className="w-full h-auto" />
                    </div>

                    <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-2xl p-6 mb-8 border border-green-100">
                      <div className="flex justify-between items-center mb-4">
                        <p className="text-xs font-bold text-green-600 uppercase tracking-wider">Compressed Size</p>
                        <span className="px-3 py-1 bg-green-600 text-white text-[10px] font-black rounded-lg">
                          OPTIMIZED
                        </span>
                      </div>
                      <div className="flex items-baseline gap-2 mb-4">
                        <p className="text-3xl font-black text-slate-900">{formatFileSize(compressedSize)}</p>
                        <p className="text-sm font-bold text-slate-400 line-through">{formatFileSize(originalSize)}</p>
                      </div>
                      <div className="h-[2px] w-full bg-green-100 mb-4" />
                      <div className="flex items-center gap-2 text-green-700">
                        <CheckCircle2 className="w-5 h-5" />
                        <p className="text-lg font-black italic">
                          Saved {(((originalSize - compressedSize) / originalSize) * 100).toFixed(1)}% (
                          {formatFileSize(originalSize - compressedSize)})
                        </p>
                      </div>
                    </div>

                    <Button
                      onClick={handleDownload}
                      className="w-full h-16 bg-slate-900 hover:bg-black text-white rounded-[1.25rem] text-lg font-bold shadow-xl shadow-slate-200 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-3"
                    >
                      <Download className="w-6 h-6" />
                      Download Optimized Image
                    </Button>
                  </div>
                )}
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Improved SEO Content Sections */}
        <div className="max-w-5xl mx-auto space-y-20 animate-in fade-in slide-in-from-bottom-8 duration-1000 delay-300">
          <section>
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-5xl font-black text-slate-900 mb-4">How to Use</h2>
              <div className="w-20 h-1.5 bg-red-600 mx-auto rounded-full" />
            </div>
            <div className="grid md:grid-cols-3 gap-8">
              {[
                {
                  icon: <MousePointer2 className="w-8 h-8 text-red-600" />,
                  title: "Select Files",
                  desc: "Click the upload button to choose the files you want to compress image online.",
                },
                {
                  icon: <Settings2 className="w-8 h-8 text-red-600" />,
                  title: "Adjust Compression",
                  desc: "Set your desired output, such as using the compress jpg to 200kb setting for specific size requirements.",
                },
                {
                  icon: <DownloadCloud className="w-8 h-8 text-red-600" />,
                  title: "Download Optimized",
                  desc: "Use the photo size reducer to process your files and download the smaller versions.",
                },
              ].map((step, idx) => (
                <Card
                  key={idx}
                  className="p-8 rounded-[2rem] border-2 border-slate-100 hover:border-red-200 transition-all text-center group"
                >
                  <div className="w-16 h-16 bg-red-50 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
                    {step.icon}
                  </div>
                  <h4 className="text-xl font-bold text-slate-900 mb-3">{step.title}</h4>
                  <p className="text-slate-600 leading-relaxed">{step.desc}</p>
                </Card>
              ))}
            </div>
          </section>

          <section className="bg-white rounded-[3rem] p-10 md:p-16 border-2 border-slate-100 shadow-2xl shadow-slate-200/50">
            <h2 className="text-3xl md:text-4xl font-black text-slate-900 mb-10 flex items-center gap-4">
              <ShieldCheck className="w-10 h-10 text-red-600" />
              Tool Description
            </h2>
            <div className="space-y-8 text-lg text-slate-600 leading-relaxed">
              <p>
                Our <span className="text-slate-900 font-bold">image compressor online</span> is the perfect solution
                for users who need to{" "}
                <span className="text-slate-900 font-bold italic underline decoration-red-300">reduce image size</span>{" "}
                without sacrificing visual clarity. Designed for efficiency, this{" "}
                <span className="text-slate-900 font-bold">image compressor without losing quality</span> ensures that
                your high-resolution photos remain crisp while significantly decreasing their footprint. Whether you
                need to shrink image size for a personal gallery or require a{" "}
                <span className="text-slate-900 font-bold">photo size reducer</span> for professional storage, our tool
                handles every task with precision.
              </p>
              <div className="grid md:grid-cols-2 gap-8 my-10">
                <div className="p-6 bg-slate-50 rounded-2xl border-l-4 border-red-500">
                  <p className="font-bold text-slate-900 mb-2">For Developers & Designers</p>
                  <p className="text-sm">
                    Optimize your web assets with our bulk image compressor. Maintain transparency with the compress png
                    online feature while boosting page load speeds.
                  </p>
                </div>
                <div className="p-6 bg-slate-50 rounded-2xl border-l-4 border-orange-500">
                  <p className="font-bold text-slate-900 mb-2">For Daily Needs</p>
                  <p className="text-sm">
                    Easily <span className="font-bold">compress jpg to 200kb</span> for email attachments or job
                    applications without technical complexity.
                  </p>
                </div>
              </div>
              <p>
                This comprehensive <span className="text-slate-900 font-bold">image file size reducer</span> is built to
                help you manage your digital assets effectively while ensuring fast loading times for any platform.
                Experience why thousands of users trust us as their go-to{" "}
                <span className="text-slate-900 font-bold underline decoration-orange-300">compress image</span> tool
                for high-fidelity optimization.
              </p>
            </div>
          </section>
        </div>
      </div>
    </div>
  )
}
