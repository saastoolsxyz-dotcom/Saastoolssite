import type { Metadata } from "next"
import ImageCompressorClient from "./image-compressor-client"

export const metadata: Metadata = {
  title: "Image Compressor Online - Reduce Image Size Without Losing Quality",
  description:
    "Use our free image compressor online to reduce image size and compress jpg to 200kb. A professional photo size reducer and image file size reducer without losing quality.",
  keywords: [
    "compress image online",
    "reduce image size",
    "image compressor without losing quality",
    "photo size reducer",
    "compress jpg to 200kb",
    "image compressor online",
    "image file size reducer",
    "compress png online",
    "shrink image size",
  ],
}

export default function ImageCompressorPage() {
  return <ImageCompressorClient />
}
