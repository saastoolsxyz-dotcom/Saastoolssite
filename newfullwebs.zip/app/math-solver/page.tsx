"use client"

import { useState } from "react"
import { Calculator, Loader2, Lightbulb, BookOpen, Home } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { useToast } from "@/components/ui/use-toast"
import { solveMathProblem } from "@/services/gemini"

export default function MathSolverPage() {
  const [problem, setProblem] = useState("")
  const [solution, setSolution] = useState("")
  const [concise, setConcise] = useState(false)
  const [isSolving, setIsSolving] = useState(false)
  const [history, setHistory] = useState<Array<{ problem: string; solution: string }>>([])
  const { toast } = useToast()

  const handleSolve = async () => {
    if (!problem.trim()) {
      toast({
        title: "Missing Problem",
        description: "Please enter a math problem to solve.",
        variant: "destructive",
      })
      return
    }

    setIsSolving(true)

    try {
      const result = await solveMathProblem(problem, { toolId: "math-solver", concise })
      setSolution(result)
      setHistory([{ problem, solution: result }, ...history.slice(0, 4)])

      toast({
        title: "Success",
        description: "Problem solved!",
      })
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to solve problem.",
        variant: "destructive",
      })
    } finally {
      setIsSolving(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white py-20 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <Button onClick={() => (window.location.href = "/")} variant="outline" className="rounded-2xl">
            <Home className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
        </div>

        <div className="text-center mb-16">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-blue-500 to-indigo-600 shadow-xl shadow-blue-200 mb-6">
            <Calculator className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-5xl md:text-6xl font-bold text-slate-900 mb-4">Math Solver</h1>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto">
            Solve complex math problems with AI-powered step-by-step solutions
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1">
            <Card className="p-6 bg-white/50 backdrop-blur-sm border-2 border-slate-200 rounded-3xl sticky top-8">
              <h3 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-2">
                <Lightbulb className="w-6 h-6 text-blue-500" />
                Problem Input
              </h3>

              <div className="space-y-6">
                <div>
                  <Label htmlFor="problem" className="text-sm font-bold text-slate-700 mb-2 block">
                    Math Problem *
                  </Label>
                  <Textarea
                    id="problem"
                    value={problem}
                    onChange={(e) => setProblem(e.target.value)}
                    placeholder="Enter your math problem here..."
                    className="min-h-[200px] rounded-2xl font-mono"
                  />
                </div>

                <div className="flex items-center justify-between bg-slate-50 rounded-xl p-4">
                  <div>
                    <Label htmlFor="concise" className="text-sm font-bold text-slate-700">
                      Concise Mode
                    </Label>
                    <p className="text-xs text-slate-500">Answer only, no steps</p>
                  </div>
                  <Switch id="concise" checked={concise} onCheckedChange={setConcise} />
                </div>

                <Button
                  onClick={handleSolve}
                  disabled={isSolving}
                  className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white rounded-2xl py-6 text-lg font-bold shadow-xl shadow-blue-200"
                >
                  {isSolving ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Solving...
                    </>
                  ) : (
                    <>
                      <Calculator className="w-5 h-5 mr-2" />
                      Solve Problem
                    </>
                  )}
                </Button>
              </div>
            </Card>
          </div>

          <div className="lg:col-span-2 space-y-8">
            <Card className="p-8 bg-white/50 backdrop-blur-sm border-2 border-slate-200 rounded-3xl">
              <h3 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-2">
                <BookOpen className="w-6 h-6 text-blue-500" />
                Solution
              </h3>

              {!solution && !isSolving && (
                <div className="border-4 border-dashed border-slate-300 rounded-2xl p-16 text-center min-h-[400px] flex items-center justify-center">
                  <div>
                    <Calculator className="w-20 h-20 text-slate-300 mx-auto mb-4" />
                    <p className="text-slate-400 text-lg">Solution will appear here</p>
                  </div>
                </div>
              )}

              {isSolving && (
                <div className="border-4 border-dashed border-blue-300 rounded-2xl p-16 text-center min-h-[400px] flex items-center justify-center bg-blue-50">
                  <div>
                    <Loader2 className="w-20 h-20 text-blue-500 mx-auto mb-4 animate-spin" />
                    <p className="text-slate-700 font-medium text-lg">Solving problem with AI...</p>
                  </div>
                </div>
              )}

              {solution && (
                <div className="prose max-w-none">
                  <div className="bg-slate-50 rounded-2xl p-8 text-slate-700 leading-relaxed">
                    <pre className="whitespace-pre-wrap font-sans">{solution}</pre>
                  </div>
                </div>
              )}
            </Card>

            {history.length > 0 && (
              <Card className="p-8 bg-white/50 backdrop-blur-sm border-2 border-slate-200 rounded-3xl">
                <h3 className="text-2xl font-bold text-slate-900 mb-6">Recent Solutions</h3>
                <div className="space-y-4">
                  {history.map((item, idx) => (
                    <div
                      key={idx}
                      className="bg-slate-50 rounded-xl p-4 cursor-pointer hover:bg-slate-100 transition-all"
                      onClick={() => {
                        setProblem(item.problem)
                        setSolution(item.solution)
                      }}
                    >
                      <p className="font-mono text-sm text-slate-700 mb-2">{item.problem.slice(0, 100)}...</p>
                    </div>
                  ))}
                </div>
              </Card>
            )}
          </div>
        </div>

        <div className="mt-16 mb-12 grid md:grid-cols-3 gap-6">
          <div className="p-6 rounded-2xl bg-blue-50/50 border border-blue-100">
            <div className="w-10 h-10 rounded-full bg-blue-500 text-white flex items-center justify-center font-bold mb-4">
              1
            </div>
            <h4 className="font-bold mb-2">Input Problem</h4>
            <p className="text-sm text-slate-600">
              Type your query into our <strong className="text-blue-700">online math solver</strong> to get started.
            </p>
          </div>
          <div className="p-6 rounded-2xl bg-blue-50/50 border border-blue-100">
            <div className="w-10 h-10 rounded-full bg-blue-500 text-white flex items-center justify-center font-bold mb-4">
              2
            </div>
            <h4 className="font-bold mb-2">AI Analysis</h4>
            <p className="text-sm text-slate-600">
              Our <strong className="text-blue-700">math problem solver with steps</strong> will analyze the logic.
            </p>
          </div>
          <div className="p-6 rounded-2xl bg-blue-50/50 border border-blue-100">
            <div className="w-10 h-10 rounded-full bg-blue-500 text-white flex items-center justify-center font-bold mb-4">
              3
            </div>
            <h4 className="font-bold mb-2">Study Steps</h4>
            <p className="text-sm text-slate-600">
              Use our <strong className="text-blue-700">solve math online free</strong> tool to master any subject.
            </p>
          </div>
        </div>

        <div className="prose prose-slate max-w-none bg-white/50 backdrop-blur rounded-3xl p-8 shadow-sm border border-slate-200 mb-8">
          <h2 className="text-2xl font-bold mb-4">Advanced AI Math Solver for Complex Problem Solving</h2>
          <p className="text-slate-600 mb-4">
            Mastering mathematics is easier with our professional{" "}
            <strong className="text-blue-700 underline decoration-blue-200 decoration-2 underline-offset-4">
              online math solver
            </strong>
            . SaasTools.xyz provides a powerful{" "}
            <strong className="text-blue-700 underline decoration-blue-200 decoration-2 underline-offset-4">
              math problem solver with steps
            </strong>{" "}
            that breaks down difficult equations into understandable pieces. Whether you are a student or professional,
            our{" "}
            <strong className="text-blue-700 underline decoration-blue-200 decoration-2 underline-offset-4">
              solve math online free
            </strong>{" "}
            service provides the precision you need.
          </p>
          <p className="text-slate-600">
            Our platform is recognized as the best{" "}
            <strong className="text-blue-700 underline decoration-blue-200 decoration-2 underline-offset-4">
              math problem solver with steps
            </strong>{" "}
            for advanced learning. The{" "}
            <strong className="text-blue-700 underline decoration-blue-200 decoration-2 underline-offset-4">
              online math solver
            </strong>{" "}
            supports algebra, calculus, and geometry effortlessly. Experience the clarity of an automated{" "}
            <strong className="text-blue-700 underline decoration-blue-200 decoration-2 underline-offset-4">
              solve math online free
            </strong>{" "}
            tutor today.
          </p>
        </div>
      </div>
    </div>
  )
}
