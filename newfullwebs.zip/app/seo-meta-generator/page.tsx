"use client"

import { useState } from "react"
import { Search, Loader2, Copy, Globe, Home } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import { runGeminiPrompt } from "@/services/gemini"

export default function SEOMetaGeneratorPage() {
  const [topic, setTopic] = useState("")
  const [keywords, setKeywords] = useState("")
  const [description, setDescription] = useState("")
  const [metaTitle, setMetaTitle] = useState("")
  const [metaDescription, setMetaDescription] = useState("")
  const [ogTags, setOgTags] = useState("")
  const [isGenerating, setIsGenerating] = useState(false)
  const { toast } = useToast()

  const handleGenerate = async () => {
    if (!topic.trim()) {
      toast({
        title: "Missing Topic",
        description: "Please enter a topic or page title.",
        variant: "destructive",
      })
      return
    }

    setIsGenerating(true)

    try {
      const prompt = `Generate SEO-optimized meta tags for:\n\nTopic: ${topic}\nKeywords: ${keywords || "N/A"}\nDescription: ${description || "N/A"}\n\nProvide:\n1. Meta Title (max 60 chars)\n2. Meta Description (max 160 chars)\n3. Open Graph tags (og:title, og:description, og:type, og:image placeholder)\n\nFormat as:\n\n--- META TITLE ---\n[title here]\n\n--- META DESCRIPTION ---\n[description here]\n\n--- OPEN GRAPH TAGS ---\n[HTML tags here]`

      const result = await runGeminiPrompt(prompt, "seo-meta")

      const titleMatch = result.match(/--- META TITLE ---\s*(.*?)(?=\n\n---|\n---)/s)
      const descMatch = result.match(/--- META DESCRIPTION ---\s*(.*?)(?=\n\n---|\n---)/s)
      const ogMatch = result.match(/--- OPEN GRAPH TAGS ---\s*(.*?)$/s)

      setMetaTitle(titleMatch?.[1]?.trim() || "")
      setMetaDescription(descMatch?.[1]?.trim() || "")
      setOgTags(ogMatch?.[1]?.trim() || "")

      toast({
        title: "Success",
        description: "SEO meta tags generated!",
      })
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to generate meta tags.",
        variant: "destructive",
      })
    } finally {
      setIsGenerating(false)
    }
  }

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text)
    toast({
      title: "Copied!",
      description: `${label} copied to clipboard.`,
    })
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-white py-20 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <Button onClick={() => (window.location.href = "/")} variant="outline" className="rounded-2xl">
            <Home className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
        </div>

        <div className="text-center mb-16">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-green-500 to-emerald-600 shadow-xl shadow-green-200 mb-6">
            <Search className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-5xl md:text-6xl font-bold text-slate-900 mb-4">SEO Meta Generator</h1>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto">
            Generate high-ranking meta tags and titles for your content
          </p>
        </div>

        <div className="mt-16 mb-12 grid md:grid-cols-3 gap-6">
          <div className="p-6 rounded-2xl bg-green-50/50 border border-green-100">
            <div className="w-10 h-10 rounded-full bg-green-500 text-white flex items-center justify-center font-bold mb-4">
              1
            </div>
            <h4 className="font-bold mb-2">Input URL</h4>
            <p className="text-sm text-slate-600">
              Enter your page topic into the <strong className="text-green-700">meta title generator</strong> to begin.
            </p>
          </div>
          <div className="p-6 rounded-2xl bg-green-50/50 border border-green-100">
            <div className="w-10 h-10 rounded-full bg-green-500 text-white flex items-center justify-center font-bold mb-4">
              2
            </div>
            <h4 className="font-bold mb-2">AI Optimization</h4>
            <p className="text-sm text-slate-600">
              Let our <strong className="text-green-700">meta description generator</strong> craft your search tags.
            </p>
          </div>
          <div className="p-6 rounded-2xl bg-green-50/50 border border-green-100">
            <div className="w-10 h-10 rounded-full bg-green-500 text-white flex items-center justify-center font-bold mb-4">
              3
            </div>
            <h4 className="font-bold mb-2">Boost Rankings</h4>
            <p className="text-sm text-slate-600">
              Use our <strong className="text-green-700">seo meta tool</strong> to improve your click-through rates.
            </p>
          </div>
        </div>

        <div className="prose prose-slate max-w-none bg-white/50 backdrop-blur rounded-3xl p-8 shadow-sm border border-slate-200 mb-8">
          <h2 className="text-2xl font-bold mb-4">Expert SEO Meta Tag Generator for Search Visibility</h2>
          <p className="text-slate-600 mb-4">
            Maximize your website's search potential with our professional{" "}
            <strong className="text-green-700 underline decoration-green-200 decoration-2 underline-offset-4">
              meta title generator
            </strong>
            . SaasTools.xyz provides a comprehensive{" "}
            <strong className="text-green-700 underline decoration-green-200 decoration-2 underline-offset-4">
              meta description generator
            </strong>{" "}
            that crafts compelling snippets to drive traffic. By using our{" "}
            <strong className="text-green-700 underline decoration-green-200 decoration-2 underline-offset-4">
              seo meta tool
            </strong>
            , you ensure that every page on your site is optimized for the highest search engine rankings.
          </p>
          <p className="text-slate-600">
            Our platform is the top choice for marketers needing a reliable{" "}
            <strong className="text-green-700 underline decoration-green-200 decoration-2 underline-offset-4">
              meta description generator
            </strong>
            . The{" "}
            <strong className="text-green-700 underline decoration-green-200 decoration-2 underline-offset-4">
              meta title generator
            </strong>{" "}
            ensures your headlines are both catchy and relevant. Start ranking higher today with our
            precision-engineered{" "}
            <strong className="text-green-700 underline decoration-green-200 decoration-2 underline-offset-4">
              seo meta tool
            </strong>
            .
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1">
            <Card className="p-6 bg-white/50 backdrop-blur-sm border-2 border-slate-200 rounded-3xl sticky top-8">
              <h3 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-2">
                <Globe className="w-6 h-6 text-green-500" />
                Page Info
              </h3>

              <div className="space-y-6">
                <div>
                  <Label htmlFor="topic" className="text-sm font-bold text-slate-700 mb-2 block">
                    Topic / Page Title *
                  </Label>
                  <Input
                    id="topic"
                    value={topic}
                    onChange={(e) => setTopic(e.target.value)}
                    placeholder="Best AI Tools for Productivity"
                    className="rounded-2xl"
                  />
                </div>

                <div>
                  <Label htmlFor="keywords" className="text-sm font-bold text-slate-700 mb-2 block">
                    Target Keywords
                  </Label>
                  <Input
                    id="keywords"
                    value={keywords}
                    onChange={(e) => setKeywords(e.target.value)}
                    placeholder="AI tools, productivity, automation"
                    className="rounded-2xl"
                  />
                </div>

                <div>
                  <Label htmlFor="description" className="text-sm font-bold text-slate-700 mb-2 block">
                    Page Description (Optional)
                  </Label>
                  <Textarea
                    id="description"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Brief overview of your content..."
                    className="min-h-[100px] rounded-2xl"
                  />
                </div>

                <Button
                  onClick={handleGenerate}
                  disabled={isGenerating}
                  className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white rounded-2xl py-6 text-lg font-bold shadow-xl shadow-green-200"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Search className="w-5 h-5 mr-2" />
                      Generate SEO Tags
                    </>
                  )}
                </Button>
              </div>
            </Card>
          </div>

          <div className="lg:col-span-2 space-y-6">
            <Card className="p-8 bg-white/50 backdrop-blur-sm border-2 border-slate-200 rounded-3xl">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-bold text-slate-900">Meta Title</h3>
                {metaTitle && (
                  <Button
                    onClick={() => handleCopy(metaTitle, "Meta Title")}
                    variant="outline"
                    size="sm"
                    className="rounded-xl"
                  >
                    <Copy className="w-4 h-4 mr-2" />
                    Copy
                  </Button>
                )}
              </div>
              {metaTitle ? (
                <div className="bg-slate-50 rounded-xl p-4">
                  <p className="text-slate-700">{metaTitle}</p>
                  <p className="text-xs text-slate-500 mt-2">{metaTitle.length} characters</p>
                </div>
              ) : (
                <div className="border-2 border-dashed border-slate-300 rounded-xl p-8 text-center">
                  <p className="text-slate-400">Meta title will appear here</p>
                </div>
              )}
            </Card>

            <Card className="p-8 bg-white/50 backdrop-blur-sm border-2 border-slate-200 rounded-3xl">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-bold text-slate-900">Meta Description</h3>
                {metaDescription && (
                  <Button
                    onClick={() => handleCopy(metaDescription, "Meta Description")}
                    variant="outline"
                    size="sm"
                    className="rounded-xl"
                  >
                    <Copy className="w-4 h-4 mr-2" />
                    Copy
                  </Button>
                )}
              </div>
              {metaDescription ? (
                <div className="bg-slate-50 rounded-xl p-4">
                  <p className="text-slate-700">{metaDescription}</p>
                  <p className="text-xs text-slate-500 mt-2">{metaDescription.length} characters</p>
                </div>
              ) : (
                <div className="border-2 border-dashed border-slate-300 rounded-xl p-8 text-center">
                  <p className="text-slate-400">Meta description will appear here</p>
                </div>
              )}
            </Card>

            <Card className="p-8 bg-white/50 backdrop-blur-sm border-2 border-slate-200 rounded-3xl">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-bold text-slate-900">Open Graph Tags</h3>
                {ogTags && (
                  <Button
                    onClick={() => handleCopy(ogTags, "Open Graph Tags")}
                    variant="outline"
                    size="sm"
                    className="rounded-xl"
                  >
                    <Copy className="w-4 h-4 mr-2" />
                    Copy
                  </Button>
                )}
              </div>
              {ogTags ? (
                <div className="bg-slate-50 rounded-xl p-4">
                  <pre className="text-slate-700 text-sm whitespace-pre-wrap font-mono">{ogTags}</pre>
                </div>
              ) : (
                <div className="border-2 border-dashed border-slate-300 rounded-xl p-8 text-center">
                  <p className="text-slate-400">Open Graph tags will appear here</p>
                </div>
              )}
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
