"use client"

import type React from "react"

import { useState, useRef } from "react"
import { useRouter } from "next/navigation"
import { MessageSquare, Upload, Loader2, FileText, Send, Home } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { useToast } from "@/components/ui/use-toast"
import { extractTextFromPdf, runGeminiPrompt } from "@/services/gemini"

interface Message {
  role: "user" | "assistant"
  content: string
}

export default function PdfQAPage() {
  const router = useRouter()
  const [pdfText, setPdfText] = useState("")
  const [fileName, setFileName] = useState("")
  const [messages, setMessages] = useState<Message[]>([])
  const [question, setQuestion] = useState("")
  const [isExtracting, setIsExtracting] = useState(false)
  const [isAsking, setIsAsking] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    if (file.type !== "application/pdf") {
      toast({
        title: "Invalid File",
        description: "Please select a PDF file.",
        variant: "destructive",
      })
      return
    }

    setFileName(file.name)
    setIsExtracting(true)

    try {
      const text = await extractTextFromPdf(file, "pdf-qa")
      setPdfText(text)
      setMessages([
        {
          role: "assistant",
          content: `PDF "${file.name}" loaded successfully! I've extracted the content. Ask me anything about it.`,
        },
      ])

      toast({
        title: "Success",
        description: "PDF text extracted successfully!",
      })
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to extract PDF text.",
        variant: "destructive",
      })
    } finally {
      setIsExtracting(false)
    }
  }

  const handleAsk = async () => {
    if (!question.trim() || !pdfText) return

    const userMessage: Message = { role: "user", content: question }
    setMessages([...messages, userMessage])
    setQuestion("")
    setIsAsking(true)

    try {
      const prompt = `Based on this PDF content:\n\n${pdfText}\n\nUser Question: ${question}\n\nProvide a helpful answer based only on the content above.`
      const answer = await runGeminiPrompt(prompt, "pdf-qa")

      const assistantMessage: Message = { role: "assistant", content: answer }
      setMessages((prev) => [...prev, assistantMessage])
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to get answer.",
        variant: "destructive",
      })
    } finally {
      setIsAsking(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-white py-20 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <Button onClick={() => router.push("/")} variant="outline" className="rounded-2xl">
            <Home className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
        </div>

        <div className="text-center mb-16">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-amber-500 to-orange-600 shadow-xl shadow-amber-200 mb-6">
            <MessageSquare className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-5xl md:text-6xl font-bold text-slate-900 mb-4">PDF Chatbot</h1>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto">Upload a PDF and ask questions about its content</p>
        </div>

        {!pdfText ? (
          <Card className="p-12 bg-white/50 backdrop-blur-sm border-2 border-slate-200 rounded-3xl max-w-2xl mx-auto">
            <div
              onClick={() => fileInputRef.current?.click()}
              className="border-4 border-dashed border-slate-300 rounded-2xl p-16 text-center cursor-pointer hover:border-amber-500 transition-all hover:bg-amber-50"
            >
              {isExtracting ? (
                <>
                  <Loader2 className="w-16 h-16 text-amber-500 mx-auto mb-4 animate-spin" />
                  <p className="text-slate-700 font-medium">Extracting PDF content...</p>
                </>
              ) : (
                <>
                  <Upload className="w-16 h-16 text-slate-400 mx-auto mb-4" />
                  <p className="text-slate-600 font-medium mb-2">Click to upload a PDF</p>
                  <p className="text-sm text-slate-400">Maximum file size: 10MB</p>
                </>
              )}
              <input ref={fileInputRef} type="file" accept=".pdf" onChange={handleFileSelect} className="hidden" />
            </div>
          </Card>
        ) : (
          <div className="grid lg:grid-cols-4 gap-8">
            <Card className="lg:col-span-1 p-6 bg-white/50 backdrop-blur-sm border-2 border-slate-200 rounded-3xl h-fit sticky top-8">
              <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
                <FileText className="w-5 h-5 text-amber-500" />
                Document Info
              </h3>
              <div className="bg-slate-50 rounded-xl p-4 mb-4">
                <p className="text-sm font-bold text-slate-700 mb-1">File Name:</p>
                <p className="text-xs text-slate-600 break-words">{fileName}</p>
              </div>
              <div className="bg-slate-50 rounded-xl p-4">
                <p className="text-sm font-bold text-slate-700 mb-1">Characters:</p>
                <p className="text-xs text-slate-600">{pdfText.length.toLocaleString()}</p>
              </div>
              <Button
                onClick={() => {
                  setPdfText("")
                  setFileName("")
                  setMessages([])
                  if (fileInputRef.current) fileInputRef.current.value = ""
                }}
                variant="outline"
                className="w-full mt-4 rounded-xl"
              >
                Upload New PDF
              </Button>
            </Card>

            <Card className="lg:col-span-3 p-8 bg-white/50 backdrop-blur-sm border-2 border-slate-200 rounded-3xl flex flex-col">
              <h3 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-2">
                <MessageSquare className="w-6 h-6 text-amber-500" />
                Chat
              </h3>

              <div className="flex-1 mb-6 space-y-4 max-h-[500px] overflow-y-auto">
                {messages.map((msg, idx) => (
                  <div key={idx} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
                    <div
                      className={`max-w-[80%] rounded-2xl p-4 ${
                        msg.role === "user" ? "bg-blue-600 text-white" : "bg-slate-100 text-slate-700"
                      }`}
                    >
                      <p className="whitespace-pre-wrap">{msg.content}</p>
                    </div>
                  </div>
                ))}
                {isAsking && (
                  <div className="flex justify-start">
                    <div className="bg-slate-100 rounded-2xl p-4">
                      <Loader2 className="w-5 h-5 text-amber-500 animate-spin" />
                    </div>
                  </div>
                )}
              </div>

              <div className="flex gap-2">
                <Input
                  value={question}
                  onChange={(e) => setQuestion(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && !isAsking && handleAsk()}
                  placeholder="Ask a question about the PDF..."
                  className="rounded-2xl flex-1"
                  disabled={isAsking}
                />
                <Button
                  onClick={handleAsk}
                  disabled={!question.trim() || isAsking}
                  className="bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 rounded-2xl px-6"
                >
                  <Send className="w-5 h-5" />
                </Button>
              </div>
            </Card>
          </div>
        )}
      </div>
    </div>
  )
}
