"use client"

import { useState } from "react"
import { Edit, Loader2, Copy, Sparkles, Home } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { generateSmartContent, type WriterOptions } from "@/services/gemini"

export default function WriterPage() {
  const [type, setType] = useState("Blog Post")
  const [topic, setTopic] = useState("")
  const [tone, setTone] = useState("Professional")
  const [keywords, setKeywords] = useState("")
  const [structure, setStructure] = useState("standard")
  const [content, setContent] = useState("")
  const [isGenerating, setIsGenerating] = useState(false)
  const { toast } = useToast()

  const handleGenerate = async () => {
    if (!topic.trim()) {
      toast({
        title: "Missing Topic",
        description: "Please enter a topic to write about.",
        variant: "destructive",
      })
      return
    }

    setIsGenerating(true)

    try {
      const options: WriterOptions = {
        type,
        tone,
        topic,
        keywords: keywords || undefined,
        structure: structure as any,
      }

      const result = await generateSmartContent(options, "writer")
      setContent(result)

      toast({
        title: "Success",
        description: "Content generated successfully!",
      })
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to generate content.",
        variant: "destructive",
      })
    } finally {
      setIsGenerating(false)
    }
  }

  const handleCopy = () => {
    navigator.clipboard.writeText(content)
    toast({ title: "Copied!", description: "Content copied to clipboard." })
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-violet-50 to-white py-20 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <Button onClick={() => (window.location.href = "/")} variant="outline" className="rounded-2xl">
            <Home className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
        </div>

        <div className="text-center mb-16">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-violet-500 to-purple-600 shadow-xl shadow-violet-200 mb-6">
            <Edit className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-5xl md:text-6xl font-bold text-slate-900 mb-4">Content Writer</h1>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto">
            Create high-quality content with advanced AI models
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1">
            <Card className="p-6 bg-white/50 backdrop-blur-sm border-2 border-slate-200 rounded-3xl sticky top-8">
              <h3 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-2">
                <Sparkles className="w-6 h-6 text-violet-500" />
                Settings
              </h3>

              <div className="space-y-6">
                <div>
                  <Label className="text-sm font-bold text-slate-700 mb-2 block">Content Type</Label>
                  <Select value={type} onValueChange={setType}>
                    <SelectTrigger className="rounded-2xl">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Blog Post">Blog Post</SelectItem>
                      <SelectItem value="Article">Article</SelectItem>
                      <SelectItem value="Social Media Post">Social Media Post</SelectItem>
                      <SelectItem value="Email">Email</SelectItem>
                      <SelectItem value="Product Description">Product Description</SelectItem>
                      <SelectItem value="Ad Copy">Ad Copy</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="topic" className="text-sm font-bold text-slate-700 mb-2 block">
                    Topic *
                  </Label>
                  <Input
                    id="topic"
                    value={topic}
                    onChange={(e) => setTopic(e.target.value)}
                    placeholder="AI in Healthcare"
                    className="rounded-2xl"
                  />
                </div>

                <div>
                  <Label className="text-sm font-bold text-slate-700 mb-2 block">Tone</Label>
                  <Select value={tone} onValueChange={setTone}>
                    <SelectTrigger className="rounded-2xl">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Professional">Professional</SelectItem>
                      <SelectItem value="Casual">Casual</SelectItem>
                      <SelectItem value="Friendly">Friendly</SelectItem>
                      <SelectItem value="Formal">Formal</SelectItem>
                      <SelectItem value="Humorous">Humorous</SelectItem>
                      <SelectItem value="Persuasive">Persuasive</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="keywords" className="text-sm font-bold text-slate-700 mb-2 block">
                    Keywords (Optional)
                  </Label>
                  <Input
                    id="keywords"
                    value={keywords}
                    onChange={(e) => setKeywords(e.target.value)}
                    placeholder="machine learning, diagnostics"
                    className="rounded-2xl"
                  />
                </div>

                <div>
                  <Label className="text-sm font-bold text-slate-700 mb-2 block">Structure</Label>
                  <Select value={structure} onValueChange={setStructure}>
                    <SelectTrigger className="rounded-2xl">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="standard">Standard</SelectItem>
                      <SelectItem value="twitter_thread">Twitter Thread</SelectItem>
                      <SelectItem value="linkedin_post">LinkedIn Post</SelectItem>
                      <SelectItem value="seo_blog">SEO Blog</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Button
                  onClick={handleGenerate}
                  disabled={isGenerating}
                  className="w-full bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-700 hover:to-purple-700 text-white rounded-2xl py-6 text-lg font-bold shadow-xl shadow-violet-200"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Writing...
                    </>
                  ) : (
                    <>
                      <Edit className="w-5 h-5 mr-2" />
                      Generate Content
                    </>
                  )}
                </Button>
              </div>
            </Card>
          </div>

          <div className="lg:col-span-2">
            <Card className="p-8 bg-white/50 backdrop-blur-sm border-2 border-slate-200 rounded-3xl">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-2xl font-bold text-slate-900">Generated Content</h3>
                {content && (
                  <Button onClick={handleCopy} variant="outline" size="sm" className="rounded-xl bg-transparent">
                    <Copy className="w-4 h-4 mr-2" />
                    Copy
                  </Button>
                )}
              </div>

              {!content && !isGenerating && (
                <div className="border-4 border-dashed border-slate-300 rounded-2xl p-16 text-center min-h-[600px] flex items-center justify-center">
                  <div>
                    <Edit className="w-20 h-20 text-slate-300 mx-auto mb-4" />
                    <p className="text-slate-400 text-lg">Generated content will appear here</p>
                  </div>
                </div>
              )}

              {isGenerating && (
                <div className="border-4 border-dashed border-violet-300 rounded-2xl p-16 text-center min-h-[600px] flex items-center justify-center bg-violet-50">
                  <div>
                    <Loader2 className="w-20 h-20 text-violet-500 mx-auto mb-4 animate-spin" />
                    <p className="text-slate-700 font-medium text-lg">Crafting your content...</p>
                  </div>
                </div>
              )}

              {content && (
                <div className="prose max-w-none">
                  <div className="bg-slate-50 rounded-2xl p-8">
                    <div className="text-slate-700 leading-relaxed whitespace-pre-wrap">{content}</div>
                  </div>
                  <div className="mt-4 text-sm text-slate-500">
                    {content.split(/\s+/).length} words • {content.length} characters
                  </div>
                </div>
              )}
            </Card>
          </div>
        </div>

        <div className="mt-16 mb-12 grid md:grid-cols-3 gap-6">
          <div className="p-6 rounded-2xl bg-violet-50/50 border border-violet-100">
            <div className="w-10 h-10 rounded-full bg-violet-500 text-white flex items-center justify-center font-bold mb-4">
              1
            </div>
            <h4 className="font-bold mb-2">Define Topic</h4>
            <p className="text-sm text-slate-600">
              Input your niche into our <strong className="text-violet-700">ai content generator</strong> to start.
            </p>
          </div>
          <div className="p-6 rounded-2xl bg-violet-50/50 border border-violet-100">
            <div className="w-10 h-10 rounded-full bg-violet-500 text-white flex items-center justify-center font-bold mb-4">
              2
            </div>
            <h4 className="font-bold mb-2">Set Tone</h4>
            <p className="text-sm text-slate-600">
              Customize the style with our <strong className="text-violet-700">ai article writer</strong> settings.
            </p>
          </div>
          <div className="p-6 rounded-2xl bg-violet-50/50 border border-violet-100">
            <div className="w-10 h-10 rounded-full bg-violet-500 text-white flex items-center justify-center font-bold mb-4">
              3
            </div>
            <h4 className="font-bold mb-2">Generate Post</h4>
            <p className="text-sm text-slate-600">
              Use our <strong className="text-violet-700">ai writer free</strong> to create high-quality content
              instantly.
            </p>
          </div>
        </div>

        <div className="prose prose-slate max-w-none bg-white/50 backdrop-blur rounded-3xl p-8 shadow-sm border border-slate-200 mb-8">
          <h2 className="text-2xl font-bold mb-4">Professional AI Content Writer for High-Impact Copy</h2>
          <p className="text-slate-600 mb-4">
            Creating compelling copy is effortless with our advanced{" "}
            <strong className="text-violet-700 underline decoration-violet-200 decoration-2 underline-offset-4">
              ai content generator
            </strong>
            . SaasTools.xyz offers a versatile{" "}
            <strong className="text-violet-700 underline decoration-violet-200 decoration-2 underline-offset-4">
              ai article writer
            </strong>{" "}
            that produces original, SEO-friendly articles in seconds. Whether you need blog posts, marketing copy, or
            product descriptions, our{" "}
            <strong className="text-violet-700 underline decoration-violet-200 decoration-2 underline-offset-4">
              ai writer free
            </strong>{" "}
            ensures your message is delivered with professional clarity.
          </p>
          <p className="text-slate-600">
            Our platform is designed to be the ultimate{" "}
            <strong className="text-violet-700 underline decoration-violet-200 decoration-2 underline-offset-4">
              ai article writer
            </strong>{" "}
            for modern digital needs. By leveraging our{" "}
            <strong className="text-violet-700 underline decoration-violet-200 decoration-2 underline-offset-4">
              ai content generator
            </strong>
            , you can maintain a consistent publishing schedule without the stress. Experience the future of copywriting
            with our powerful{" "}
            <strong className="text-violet-700 underline decoration-violet-200 decoration-2 underline-offset-4">
              ai writer free
            </strong>{" "}
            today.
          </p>
        </div>
      </div>
    </div>
  )
}
