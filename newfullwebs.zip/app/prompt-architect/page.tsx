"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Zap, Loader2, Copy, Sparkles, Home } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import { runGeminiPrompt } from "@/services/gemini"

export default function PromptArchitectPage() {
  const router = useRouter()
  const [input, setInput] = useState("")
  const [output, setOutput] = useState("")
  const [isGenerating, setIsGenerating] = useState(false)
  const { toast } = useToast()

  const handleGenerate = async () => {
    if (!input.trim()) {
      toast({
        title: "Missing Input",
        description: "Please enter your basic idea.",
        variant: "destructive",
      })
      return
    }

    setIsGenerating(true)

    try {
      const prompt = `You are an expert AI prompt engineer with deep knowledge of how to craft effective prompts for Large Language Models.

Your task: Transform the user's basic idea into a professional, production-ready AI prompt.

User's basic idea: "${input}"

Create an optimized prompt that includes:

1. **Role Definition**: Clearly define what persona or expert the AI should adopt
2. **Context & Background**: Provide necessary context for the task
3. **Specific Instructions**: Break down the task into clear, actionable steps
4. **Constraints & Requirements**: Define boundaries, tone, style, length
5. **Output Format**: Specify exactly how the response should be structured
6. **Quality Criteria**: Include what makes a good response

Best Practices to Apply:
- Use clear, specific language
- Include examples if helpful
- Define the desired tone and style
- Specify any constraints (length, format, etc.)
- Add quality checks or success criteria

Output ONLY the final engineered prompt - do not include explanations or meta-commentary. The prompt should be ready to copy and paste directly into an AI chat.`

      const result = await runGeminiPrompt(prompt, "prompt-architect")
      setOutput(result)

      toast({
        title: "Success",
        description: "Professional prompt generated!",
      })
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to generate prompt.",
        variant: "destructive",
      })
    } finally {
      setIsGenerating(false)
    }
  }

  const handleCopy = () => {
    navigator.clipboard.writeText(output)
    toast({
      title: "Copied!",
      description: "Prompt copied to clipboard.",
    })
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-cyan-50 to-white py-20 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <Button onClick={() => router.push("/")} variant="outline" className="rounded-2xl">
            <Home className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
        </div>

        <div className="text-center mb-16">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-cyan-500 to-blue-600 shadow-xl shadow-cyan-200 mb-6">
            <Zap className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-5xl md:text-6xl font-bold text-slate-900 mb-4">Prompt Architect</h1>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto">
            Transform simple ideas into professional AI prompts
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <Card className="p-8 bg-white/50 backdrop-blur-sm border-2 border-slate-200 rounded-3xl">
            <h3 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-2">
              <Sparkles className="w-6 h-6 text-cyan-500" />
              Your Basic Idea
            </h3>

            <div className="space-y-6">
              <div>
                <Label htmlFor="input" className="text-sm font-bold text-slate-700 mb-2 block">
                  Describe what you want *
                </Label>
                <Textarea
                  id="input"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Example: Write a blog post about AI productivity tools"
                  className="min-h-[300px] rounded-2xl"
                />
              </div>

              <Button
                onClick={handleGenerate}
                disabled={isGenerating}
                className="w-full bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700 text-white rounded-2xl py-6 text-lg font-bold shadow-xl shadow-cyan-200"
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    Engineering...
                  </>
                ) : (
                  <>
                    <Zap className="w-5 h-5 mr-2" />
                    Engineer Prompt
                  </>
                )}
              </Button>
            </div>
          </Card>

          <Card className="p-8 bg-white/50 backdrop-blur-sm border-2 border-slate-200 rounded-3xl">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
                <Zap className="w-6 h-6 text-cyan-500" />
                Professional Prompt
              </h3>
              {output && (
                <Button onClick={handleCopy} variant="outline" size="sm" className="rounded-xl bg-transparent">
                  <Copy className="w-4 h-4 mr-2" />
                  Copy
                </Button>
              )}
            </div>

            {!output && !isGenerating && (
              <div className="border-4 border-dashed border-slate-300 rounded-2xl p-16 text-center min-h-[400px] flex items-center justify-center">
                <div>
                  <Zap className="w-20 h-20 text-slate-300 mx-auto mb-4" />
                  <p className="text-slate-400 text-lg">Engineered prompt will appear here</p>
                </div>
              </div>
            )}

            {isGenerating && (
              <div className="border-4 border-dashed border-cyan-300 rounded-2xl p-16 text-center min-h-[400px] flex items-center justify-center bg-cyan-50">
                <div>
                  <Loader2 className="w-20 h-20 text-cyan-500 mx-auto mb-4 animate-spin" />
                  <p className="text-slate-700 font-medium text-lg">Engineering your prompt...</p>
                </div>
              </div>
            )}

            {output && (
              <div className="bg-slate-50 rounded-2xl p-6">
                <pre className="whitespace-pre-wrap text-slate-700 font-mono text-sm leading-relaxed">{output}</pre>
              </div>
            )}
          </Card>
        </div>
      </div>
    </div>
  )
}
