"use client"

import { useState } from "react"
import { RefreshCw, Loader2, Copy, Sparkles, Home } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import { runGeminiPrompt } from "@/services/gemini"

export default function TextHumanizerPage() {
  const [input, setInput] = useState("")
  const [output, setOutput] = useState("")
  const [isHumanizing, setIsHumanizing] = useState(false)
  const { toast } = useToast()

  const handleHumanize = async () => {
    if (!input.trim()) {
      toast({
        title: "Missing Input",
        description: "Please enter text to humanize.",
        variant: "destructive",
      })
      return
    }

    setIsHumanizing(true)

    try {
      const prompt = `You are an expert at transforming AI-generated text into natural, human-written content.

Your task: Rewrite the following text to make it sound completely natural and human-like.

Original text:
"${input}"

Guidelines for humanization:
1. Use varied sentence structures (mix short and long sentences)
2. Include natural contractions (don't, can't, it's, etc.)
3. Add conversational transitions and connectors
4. Use a warm, relatable tone
5. Include occasional imperfections that make it feel authentic
6. Vary vocabulary - avoid repetitive word choices
7. Add personal touches and relatable examples where appropriate
8. Remove overly formal or robotic phrasing
9. Make it flow naturally as if speaking to a friend

Output ONLY the humanized version - no explanations, no meta-commentary, just the rewritten text.`

      const result = await runGeminiPrompt(prompt, "text-humanizer")
      setOutput(result)

      toast({
        title: "Success",
        description: "Text humanized successfully!",
      })
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to humanize text.",
        variant: "destructive",
      })
    } finally {
      setIsHumanizing(false)
    }
  }

  const handleCopy = () => {
    navigator.clipboard.writeText(output)
    toast({
      title: "Copied!",
      description: "Humanized text copied to clipboard.",
    })
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-white py-20 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <Button onClick={() => (window.location.href = "/")} variant="outline" className="rounded-2xl">
            <Home className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
        </div>

        <div className="text-center mb-16">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-purple-500 to-violet-600 shadow-xl shadow-purple-200 mb-6">
            <RefreshCw className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-5xl md:text-6xl font-bold text-slate-900 mb-4">AI Humanizer</h1>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto">Transform AI text into natural, human-like writing</p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <Card className="p-8 bg-white/50 backdrop-blur-sm border-2 border-slate-200 rounded-3xl">
            <h3 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-2">
              <Sparkles className="w-6 h-6 text-purple-500" />
              AI-Generated Text
            </h3>

            <div className="space-y-6">
              <div>
                <Label htmlFor="input" className="text-sm font-bold text-slate-700 mb-2 block">
                  Paste your AI text here *
                </Label>
                <Textarea
                  id="input"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Enter the AI-generated text that needs humanizing..."
                  className="min-h-[400px] rounded-2xl"
                />
                <p className="text-xs text-slate-500 mt-2">{input.length} characters</p>
              </div>

              <Button
                onClick={handleHumanize}
                disabled={isHumanizing}
                className="w-full bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-700 hover:to-violet-700 text-white rounded-2xl py-6 text-lg font-bold shadow-xl shadow-purple-200"
              >
                {isHumanizing ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    Humanizing...
                  </>
                ) : (
                  <>
                    <RefreshCw className="w-5 h-5 mr-2" />
                    Humanize Text
                  </>
                )}
              </Button>
            </div>
          </Card>

          <Card className="p-8 bg-white/50 backdrop-blur-sm border-2 border-slate-200 rounded-3xl">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
                <RefreshCw className="w-6 h-6 text-purple-500" />
                Humanized Text
              </h3>
              {output && (
                <Button onClick={handleCopy} variant="outline" size="sm" className="rounded-xl bg-transparent">
                  <Copy className="w-4 h-4 mr-2" />
                  Copy
                </Button>
              )}
            </div>

            {!output && !isHumanizing && (
              <div className="border-4 border-dashed border-slate-300 rounded-2xl p-16 text-center min-h-[400px] flex items-center justify-center">
                <div>
                  <RefreshCw className="w-20 h-20 text-slate-300 mx-auto mb-4" />
                  <p className="text-slate-400 text-lg">Humanized text will appear here</p>
                </div>
              </div>
            )}

            {isHumanizing && (
              <div className="border-4 border-dashed border-purple-300 rounded-2xl p-16 text-center min-h-[400px] flex items-center justify-center bg-purple-50">
                <div>
                  <Loader2 className="w-20 h-20 text-purple-500 mx-auto mb-4 animate-spin" />
                  <p className="text-slate-700 font-medium text-lg">Making your text more human...</p>
                </div>
              </div>
            )}

            {output && (
              <div>
                <div className="bg-slate-50 rounded-2xl p-6 min-h-[400px]">
                  <p className="text-slate-700 whitespace-pre-wrap leading-relaxed">{output}</p>
                </div>
                <p className="text-xs text-slate-500 mt-2">{output.length} characters</p>
              </div>
            )}
          </Card>
        </div>

        <div className="mt-16 mb-12 grid md:grid-cols-3 gap-6">
          <div className="p-6 rounded-2xl bg-purple-50/50 border border-purple-100">
            <div className="w-10 h-10 rounded-full bg-purple-500 text-white flex items-center justify-center font-bold mb-4">
              1
            </div>
            <h4 className="font-bold mb-2">Paste Content</h4>
            <p className="text-sm text-slate-600">
              Input your AI text into our <strong className="text-purple-700">ai to human text converter</strong>.
            </p>
          </div>
          <div className="p-6 rounded-2xl bg-purple-50/50 border border-purple-100">
            <div className="w-10 h-10 rounded-full bg-purple-500 text-white flex items-center justify-center font-bold mb-4">
              2
            </div>
            <h4 className="font-bold mb-2">Refine Flow</h4>
            <p className="text-sm text-slate-600">
              Click generate to <strong className="text-purple-700">humanize ai text free</strong> of robotic patterns.
            </p>
          </div>
          <div className="p-6 rounded-2xl bg-purple-50/50 border border-purple-100">
            <div className="w-10 h-10 rounded-full bg-purple-500 text-white flex items-center justify-center font-bold mb-4">
              3
            </div>
            <h4 className="font-bold mb-2">Get Results</h4>
            <p className="text-sm text-slate-600">
              Use our <strong className="text-purple-700">ai humanizer tool</strong> for natural, undetectable content.
            </p>
          </div>
        </div>

        <div className="prose prose-slate max-w-none bg-white/50 backdrop-blur rounded-3xl p-8 shadow-sm border border-slate-200 mb-8">
          <h2 className="text-2xl font-bold mb-4">Professional AI Text Humanizer for Natural Communication</h2>
          <p className="text-slate-600 mb-4">
            Bypass robotic detection with our advanced{" "}
            <strong className="text-purple-700 underline decoration-purple-200 decoration-2 underline-offset-4">
              ai to human text converter
            </strong>
            . SaasTools.xyz offers an elite{" "}
            <strong className="text-purple-700 underline decoration-purple-200 decoration-2 underline-offset-4">
              ai humanizer tool
            </strong>{" "}
            that rewrites AI-generated content to sound authentically human. Whether you use ChatGPT or Claude, our
            ability to{" "}
            <strong className="text-purple-700 underline decoration-purple-200 decoration-2 underline-offset-4">
              humanize ai text free
            </strong>{" "}
            ensures your writing resonates with your audience.
          </p>
          <p className="text-slate-600">
            Our platform is the premier{" "}
            <strong className="text-purple-700 underline decoration-purple-200 decoration-2 underline-offset-4">
              ai humanizer tool
            </strong>{" "}
            for writers who value authenticity. The{" "}
            <strong className="text-purple-700 underline decoration-purple-200 decoration-2 underline-offset-4">
              ai to human text converter
            </strong>{" "}
            maintains your original intent while improving readability. Discover why professionals choose to{" "}
            <strong className="text-purple-700 underline decoration-purple-200 decoration-2 underline-offset-4">
              humanize ai text free
            </strong>{" "}
            with our sophisticated AI engine.
          </p>
        </div>
      </div>
    </div>
  )
}
