"use client"

import type React from "react"

import { useState } from "react"
import { Upload, Home, Video, AlertCircle, RefreshCw } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"

export default function VideoConverterPage() {
  const [video, setVideo] = useState<File | null>(null)
  const [format, setFormat] = useState("mp4")
  const [converting, setConverting] = useState(false)
  const { toast } = useToast()

  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file && file.type.startsWith("video/")) {
      setVideo(file)
    } else {
      toast({
        title: "Invalid File",
        description: "Please upload a video file",
        variant: "destructive",
      })
    }
  }

  const convertVideo = () => {
    if (!video) return
    setConverting(true)
    setTimeout(() => {
      setConverting(false)
      toast({
        title: "Video Converted!",
        description: `Converted to ${format.toUpperCase()}`,
      })
    }, 3000)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 via-blue-50 to-indigo-50 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <Link href="/">
            <Button variant="outline" className="gap-2 bg-transparent">
              <Home className="w-4 h-4" />
              Back to Home
            </Button>
          </Link>
        </div>

        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-sky-500 to-blue-500 mb-6 shadow-lg">
            <RefreshCw className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-5xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-sky-600 to-blue-600">
            Video Converter
          </h1>
          <p className="text-xl text-slate-600">Convert videos to any format</p>
        </div>

        <div className="bg-white rounded-3xl shadow-2xl p-8 mb-8">
          <div className="border-2 border-dashed border-slate-300 rounded-2xl p-12 text-center hover:border-sky-500 transition-colors">
            <input type="file" accept="video/*" onChange={handleVideoUpload} className="hidden" id="video-upload" />
            <label htmlFor="video-upload" className="cursor-pointer">
              <Upload className="w-16 h-16 mx-auto mb-4 text-sky-500" />
              <p className="text-lg font-semibold text-slate-700 mb-2">Click to upload video</p>
              <p className="text-sm text-slate-500">Any video format supported</p>
            </label>
          </div>

          {video && (
            <div className="mt-8">
              <div className="bg-slate-50 p-4 rounded-xl mb-6">
                <div className="flex items-center gap-3">
                  <Video className="w-5 h-5 text-sky-500" />
                  <p className="text-sm font-medium">{video.name}</p>
                </div>
              </div>

              <div className="mb-6">
                <label className="block text-sm font-medium mb-2">Convert to:</label>
                <Select value={format} onValueChange={setFormat}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="mp4">MP4</SelectItem>
                    <SelectItem value="avi">AVI</SelectItem>
                    <SelectItem value="mov">MOV</SelectItem>
                    <SelectItem value="webm">WebM</SelectItem>
                    <SelectItem value="mkv">MKV</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button onClick={convertVideo} disabled={converting} className="w-full" size="lg">
                {converting ? "Converting..." : `Convert to ${format.toUpperCase()}`}
              </Button>
            </div>
          )}
        </div>

        <div className="bg-sky-50 rounded-2xl p-6 border border-sky-100">
          <div className="flex gap-3">
            <AlertCircle className="w-5 h-5 text-sky-600 flex-shrink-0 mt-0.5" />
            <div className="text-sm text-sky-900">
              <p className="font-semibold mb-1">Keywords for SEO:</p>
              <p className="text-sky-700">
                video converter online, mp4 converter, convert video format, video format converter, video to mp4
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
