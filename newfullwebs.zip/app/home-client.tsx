"use client"

import { useState } from "react"
import Link from "next/link"
import {
  FileText,
  Edit,
  ImageIcon,
  Calculator,
  ArrowRight,
  Layers,
  Search,
  RefreshCw,
  MessageSquare,
  Zap,
  Sparkles,
  Star,
  Scissors,
  ScanEye,
  Minimize2,
  Maximize2,
  Video,
  Music,
  CheckCircle,
  TrendingUp,
  QrCodeIcon,
  Shield,
  Activity,
  LayoutGrid,
} from "lucide-react"
import WhyChooseUs from "@/components/why-choose-us"

const CATEGORIES = [
  "Popular Tools",
  "AI Productivity",
  "Image Tools",
  "Text & AI Writing",
  "PDF Tools",
  "Video & Audio Tools",
  "SEO & Web Tools",
  "Utility Tools",
  "Calculator Tool",
]

export default function HomeClient() {
  const tools = [
    {
      id: "bg-remover",
      title: "Background Remover",
      description: "Remove backgrounds from images instantly with AI.",
      icon: Scissors,
      gradient: "linear-gradient(135deg, #EC4899 0%, #BE185D 100%)",
      shadow: "rgba(236, 72, 153, 0.4)",
      path: "/background-remover",
      popular: true,
      cornerColor: "from-pink-400 to-rose-400",
      category: "Image Tools",
    },
    {
      id: "image-gen",
      title: "AI Image Studio",
      description: "Generate high-fidelity art and images from text.",
      icon: ImageIcon,
      gradient: "linear-gradient(135deg, #8B5CF6 0%, #6D28D9 100%)",
      shadow: "rgba(139, 92, 246, 0.4)",
      path: "/image-gen",
      popular: true,
      cornerColor: "from-purple-400 to-violet-400",
      category: "Image Tools",
    },
    {
      id: "analyzer",
      title: "Vision AI Analyzer",
      description: "Identify objects, read text, and describe images.",
      icon: ScanEye,
      gradient: "linear-gradient(135deg, #F59E0B 0%, #D97706 100%)",
      shadow: "rgba(245, 158, 11, 0.4)",
      path: "/analyzer",
      cornerColor: "from-amber-400 to-orange-400",
      category: "Image Tools",
    },
    {
      id: "media-processor",
      title: "Image Compressor",
      description: "Compress images and reduce file size.",
      icon: Layers,
      gradient: "linear-gradient(135deg, #FF6B6B 0%, #FF8E8E 100%)",
      shadow: "rgba(255, 107, 107, 0.4)",
      path: "/image-compressor",
      cornerColor: "from-red-400 to-pink-400",
      category: "Image Tools",
    },
    {
      id: "math-solver",
      title: "Math Solver",
      description: "Solve complex math problems with AI step-by-step.",
      icon: Calculator,
      gradient: "linear-gradient(135deg, #3B82F6 0%, #2563EB 100%)",
      shadow: "rgba(59, 130, 246, 0.4)",
      path: "/math-solver",
      popular: true,
      cornerColor: "from-blue-400 to-cyan-400",
      category: "AI Productivity",
    },
    {
      id: "pdf-qa",
      title: "PDF Chatbot",
      description: "Chat with your PDFs and get instant answers.",
      icon: MessageSquare,
      gradient: "linear-gradient(135deg, #F59E0B 0%, #D97706 100%)",
      shadow: "rgba(245, 158, 11, 0.4)",
      path: "/pdf-qa",
      popular: true,
      cornerColor: "from-yellow-400 to-amber-400",
      category: "PDF Tools",
    },
    {
      id: "prompt-architect",
      title: "Prompt Architect",
      description: "Turn simple ideas into professional AI prompts.",
      icon: Zap,
      gradient: "linear-gradient(135deg, #00C6FF 0%, #0072FF 100%)",
      shadow: "rgba(0, 198, 255, 0.4)",
      path: "/prompt-architect",
      cornerColor: "from-cyan-400 to-blue-400",
      category: "AI Productivity",
    },
    {
      id: "seo-meta",
      title: "SEO Meta Gen",
      description: "Generate high-ranking meta tags and titles.",
      icon: Search,
      gradient: "linear-gradient(135deg, #10B981 0%, #059669 100%)",
      shadow: "rgba(16, 185, 129, 0.4)",
      path: "/seo-meta-generator",
      cornerColor: "from-green-400 to-emerald-400",
      category: "SEO & Web Tools",
    },
    {
      id: "text-humanizer",
      title: "AI Humanizer",
      description: "Transform AI text into natural human speech.",
      icon: RefreshCw,
      gradient: "linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%)",
      shadow: "rgba(139, 92, 246, 0.4)",
      path: "/text-humanizer",
      popular: true,
      cornerColor: "from-violet-400 to-purple-400",
      category: "Text & AI Writing",
    },
    {
      id: "summarizer",
      title: "AI Summarizer",
      description: "Summarize long texts in seconds with AI.",
      icon: FileText,
      gradient: "linear-gradient(135deg, #EC4899 0%, #F472B6 100%)",
      shadow: "rgba(236, 72, 153, 0.4)",
      path: "/summarizer",
      cornerColor: "from-fuchsia-400 to-pink-400",
      category: "Text & AI Writing",
    },
    {
      id: "writer",
      title: "Content Writer",
      description: "Create content with advanced AI models.",
      icon: Edit,
      gradient: "linear-gradient(135deg, #A78BFA 0%, #C4B5FD 100%)",
      shadow: "rgba(167, 139, 250, 0.4)",
      path: "/writer",
      cornerColor: "from-indigo-400 to-purple-400",
      category: "Text & AI Writing",
    },
    {
      id: "pdf-merge",
      title: "PDF Merge",
      description: "Combine multiple PDFs into one document.",
      icon: FileText,
      gradient: "linear-gradient(135deg, #3B82F6 0%, #2563EB 100%)",
      shadow: "rgba(59, 130, 246, 0.4)",
      path: "/pdf-merge",
      cornerColor: "from-blue-400 to-sky-400",
      category: "PDF Tools",
    },
    {
      id: "pdf-split",
      title: "PDF Split",
      description: "Separate PDF pages into individual files.",
      icon: Scissors,
      gradient: "linear-gradient(135deg, #A855F7 0%, #EC4899 100%)",
      shadow: "rgba(168, 85, 247, 0.4)",
      path: "/pdf-split",
      cornerColor: "from-purple-400 to-pink-400",
      category: "PDF Tools",
    },
    {
      id: "pdf-compress",
      title: "PDF Compress",
      description: "Reduce PDF file size without losing quality.",
      icon: Minimize2,
      gradient: "linear-gradient(135deg, #F97316 0%, #DC2626 100%)",
      shadow: "rgba(249, 115, 22, 0.4)",
      path: "/pdf-compress",
      cornerColor: "from-orange-400 to-red-400",
      category: "PDF Tools",
    },
    {
      id: "image-resizer",
      title: "Image Resizer",
      description: "Resize images online for free.",
      icon: Maximize2,
      gradient: "linear-gradient(135deg, #14B8A6 0%, #06B6D4 100%)",
      shadow: "rgba(20, 184, 166, 0.4)",
      path: "/image-resizer",
      cornerColor: "from-teal-400 to-cyan-400",
      category: "Image Tools",
    },
    {
      id: "image-converter",
      title: "Image Converter",
      description: "Convert images to any format.",
      icon: RefreshCw,
      gradient: "linear-gradient(135deg, #10B981 0%, #14B8A6 100%)",
      shadow: "rgba(16, 185, 129, 0.4)",
      path: "/image-converter",
      cornerColor: "from-green-400 to-teal-400",
      category: "Image Tools",
    },
    {
      id: "video-compressor",
      title: "Video Compressor",
      description: "Reduce video file size online.",
      icon: Minimize2,
      gradient: "linear-gradient(135deg, #8B5CF6 0%, #A855F7 100%)",
      shadow: "rgba(139, 92, 246, 0.4)",
      path: "/video-compressor",
      cornerColor: "from-violet-400 to-purple-400",
      category: "Video & Audio Tools",
    },
    {
      id: "video-converter",
      title: "Video Converter",
      description: "Convert videos to any format.",
      icon: Video,
      gradient: "linear-gradient(135deg, #0EA5E9 0%, #3B82F6 100%)",
      shadow: "rgba(14, 165, 233, 0.4)",
      path: "/video-converter",
      cornerColor: "from-sky-400 to-blue-400",
      category: "Video & Audio Tools",
    },
    {
      id: "video-to-audio",
      title: "Video to Audio",
      description: "Extract audio from video files.",
      icon: Music,
      gradient: "linear-gradient(135deg, #F43F5E 0%, #EC4899 100%)",
      shadow: "rgba(244, 63, 94, 0.4)",
      path: "/video-to-audio",
      cornerColor: "from-rose-400 to-pink-400",
      category: "Video & Audio Tools",
    },
    {
      id: "paraphraser",
      title: "AI Paraphraser",
      description: "Rephrase text while keeping the meaning.",
      icon: RefreshCw,
      gradient: "linear-gradient(135deg, #F59E0B 0%, #F97316 100%)",
      shadow: "rgba(245, 158, 11, 0.4)",
      path: "/paraphraser",
      cornerColor: "from-amber-400 to-orange-400",
      category: "Text & AI Writing",
    },
    {
      id: "grammar-checker",
      title: "Grammar Checker",
      description: "Check and correct grammar mistakes.",
      icon: CheckCircle,
      gradient: "linear-gradient(135deg, #84CC16 0%, #10B981 100%)",
      shadow: "rgba(132, 204, 22, 0.4)",
      path: "/grammar-checker",
      cornerColor: "from-lime-400 to-green-400",
      category: "Text & AI Writing",
    },
    {
      id: "resume-builder",
      title: "AI Resume Builder",
      description: "Create professional resumes with AI.",
      icon: FileText,
      gradient: "linear-gradient(135deg, #6366F1 0%, #3B82F6 100%)",
      shadow: "rgba(99, 102, 241, 0.4)",
      path: "/resume-builder",
      cornerColor: "from-indigo-400 to-blue-400",
      category: "AI Productivity",
    },
    {
      id: "keyword-research",
      title: "Keyword Research",
      description: "Find the best SEO keywords for your content.",
      icon: TrendingUp,
      gradient: "linear-gradient(135deg, #059669 0%, #14B8A6 100%)",
      shadow: "rgba(5, 150, 105, 0.4)",
      path: "/keyword-research",
      cornerColor: "from-emerald-400 to-teal-400",
      category: "SEO & Web Tools",
    },
    {
      id: "qr-generator",
      title: "QR Code Generator",
      description: "Create custom QR codes instantly.",
      icon: QrCodeIcon,
      gradient: "linear-gradient(135deg, #475569 0%, #1E293B 100%)",
      shadow: "rgba(71, 85, 105, 0.4)",
      path: "/qr-generator",
      cornerColor: "from-slate-400 to-gray-600",
      category: "Utility Tools",
    },
    {
      id: "password-generator",
      title: "Password Generator",
      description: "Create strong, secure passwords.",
      icon: Shield,
      gradient: "linear-gradient(135deg, #DC2626 0%, #F97316 100%)",
      shadow: "rgba(220, 38, 38, 0.4)",
      path: "/password-generator",
      cornerColor: "from-red-400 to-orange-400",
      category: "Utility Tools",
    },
    {
      id: "bmi-calculator",
      title: "BMI Calculator",
      description: "Calculate your Body Mass Index.",
      icon: Activity,
      gradient: "linear-gradient(135deg, #06B6D4 0%, #3B82F6 100%)",
      shadow: "rgba(6, 182, 212, 0.4)",
      path: "/bmi-calculator",
      cornerColor: "from-cyan-400 to-blue-400",
      category: "Calculator Tool",
    },
  ]

  const [searchQuery, setSearchQuery] = useState("")
  const [activeCategory, setActiveCategory] = useState("Popular Tools")

  const filteredTools = tools.filter((tool) => {
    const matchesSearch =
      tool.title.toLowerCase().includes(searchQuery.toLowerCase().trim()) ||
      tool.description.toLowerCase().includes(searchQuery.toLowerCase().trim())

    if (searchQuery.trim()) return matchesSearch

    if (activeCategory === "Popular Tools") return tool.popular && matchesSearch
    return tool.category === activeCategory && matchesSearch
  })

  return (
    <div className="relative">
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 px-4 overflow-hidden">
        <div className="absolute top-20 left-10 w-72 h-72 bg-blue-400 rounded-full mix-blend-multiply filter blur-3xl opacity-10 animate-blob"></div>
        <div className="absolute top-20 right-10 w-72 h-72 bg-purple-400 rounded-full mix-blend-multiply filter blur-3xl opacity-10 animate-blob animation-delay-2000"></div>
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] bg-indigo-400/20 rounded-full blur-[120px] pointer-events-none"></div>

        <div className="max-w-6xl mx-auto text-center relative z-10">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/50 backdrop-blur-sm border border-slate-200 shadow-sm mb-8">
            <Sparkles className="w-4 h-4 text-amber-500" />
            <span className="text-[10px] font-black text-slate-600 uppercase tracking-[0.2em]">
              Next-Generation Workflow
            </span>
          </div>

          <h1 className="text-5xl md:text-8xl font-bold mb-8 tracking-tighter leading-[0.9] text-slate-900 drop-shadow-sm">
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-500 via-purple-500 to-amber-500">
              The Ultimate AI Toolkit
            </span>
            <br />
            <span className="text-slate-900">for High-Speed Productivity</span>
          </h1>

          <p className="text-lg md:text-2xl mb-12 text-slate-500 max-w-3xl mx-auto font-medium leading-relaxed">
            Transform your workflow with cutting-edge AI tools. Optimized for speed, privacy, and precision.
          </p>

          <div className="max-w-2xl mx-auto mb-12">
            <div className="relative group">
              <div className="absolute -inset-1 bg-gradient-to-r from-blue-500 to-amber-400 rounded-3xl blur opacity-20 group-hover:opacity-40 transition duration-1000 group-hover:duration-200"></div>
              <div className="relative flex items-center bg-white rounded-2xl p-2 pr-3 shadow-xl border border-slate-100">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="What can we help you create today?"
                  className="w-full px-6 py-4 rounded-xl border-none focus:outline-none focus:ring-0 text-lg text-slate-700 bg-transparent"
                />
                <button className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-xl font-bold transition-all flex items-center gap-2 shadow-lg shadow-blue-200">
                  <Search className="w-5 h-5" />
                  <span className="hidden sm:inline">Search</span>
                </button>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-2 mt-8">
              {CATEGORIES.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className={`px-4 py-2 rounded-full text-xs font-bold transition-all ${
                    activeCategory === cat && !searchQuery
                      ? "bg-blue-600 text-white shadow-lg shadow-blue-200 scale-105"
                      : "bg-white text-slate-600 border border-slate-200 hover:border-blue-300 hover:text-blue-600"
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a
              href="#tools"
              className="w-full sm:w-auto px-10 py-5 text-lg font-bold text-white rounded-2xl bg-gradient-to-r from-blue-600 to-blue-700 shadow-2xl shadow-blue-200 hover:scale-105 transition-all"
            >
              Explore Tools
            </a>
            <Link
              href="/signup"
              className="w-full sm:w-auto px-10 py-5 text-lg font-bold rounded-2xl border-2 border-blue-600 text-blue-600 bg-white hover:bg-blue-50 transition-all"
            >
              Get Started Free
            </Link>
          </div>
        </div>
      </section>

      {/* Featured Tools Section */}
      <section id="tools" className="py-24 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
            <div className="text-left">
              <h2 className="text-4xl md:text-5xl font-black text-slate-900 tracking-tight mb-4 flex items-center gap-3">
                <LayoutGrid className="w-10 h-10 text-blue-600" />
                {searchQuery ? "Search Results" : activeCategory}
              </h2>
              <p className="text-lg text-slate-500 font-medium">
                {searchQuery
                  ? `Found ${filteredTools.length} tools matching your search`
                  : `Explore our top-tier tools in the ${activeCategory} category`}
              </p>
            </div>
            {!searchQuery && (
              <div className="flex gap-2 bg-slate-100 p-1.5 rounded-2xl self-start">
                {/* Mini category switcher for the tools section */}
                {["Popular Tools", "AI Productivity", "Image Tools"].map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setActiveCategory(cat)}
                    className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                      activeCategory === cat
                        ? "bg-white text-blue-600 shadow-sm"
                        : "text-slate-500 hover:text-slate-700"
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
            {filteredTools.map((tool) => (
              <div
                key={tool.id}
                className="rounded-[2.5rem] p-10 flex flex-col group relative overflow-hidden bg-white/50 backdrop-blur-sm border border-slate-200 shadow-lg hover:shadow-2xl transition-all"
              >
                <div className="absolute -top-20 -right-20 w-48 h-48 opacity-70 group-hover:opacity-90 transition-opacity duration-500">
                  <div className={`w-full h-full rounded-full bg-gradient-to-br ${tool.cornerColor}`}></div>
                </div>

                {tool.popular && (
                  <div className="absolute top-6 right-6 bg-amber-100 text-amber-600 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest flex items-center gap-1 z-10">
                    <Star className="w-3 h-3 fill-amber-600" /> High Performance
                  </div>
                )}

                <div
                  className="w-20 h-20 rounded-3xl flex items-center justify-center mb-10 shadow-lg group-hover:scale-110 transition-transform duration-500"
                  style={{ background: tool.gradient }}
                >
                  <tool.icon className="w-10 h-10 text-white" />
                </div>

                <h3 className="text-3xl font-bold mb-4 text-slate-900 group-hover:text-blue-600 transition-colors">
                  {tool.title}
                </h3>
                <p className="text-slate-500 mb-10 text-lg leading-relaxed font-medium">{tool.description}</p>

                <div className="mt-auto">
                  <Link
                    href={tool.path}
                    className="flex items-center justify-between w-full px-8 py-5 rounded-2xl bg-slate-50 group-hover:bg-blue-600 group-hover:text-white transition-all duration-500 group-hover:shadow-xl group-hover:shadow-blue-200"
                  >
                    <span className="font-bold uppercase tracking-[0.15em] text-sm">Launch Tool</span>
                    <ArrowRight className="w-5 h-5 group-hover:translate-x-2 transition-transform" />
                  </Link>
                </div>

                <div
                  className="absolute bottom-0 right-0 w-32 h-32 blur-[60px] opacity-10 -z-10 group-hover:opacity-20 transition-opacity"
                  style={{ background: tool.gradient }}
                ></div>
              </div>
            ))}
          </div>

          {filteredTools.length === 0 && (
            <div className="text-center py-20">
              <p className="text-2xl text-slate-400 font-medium">No tools found matching "{searchQuery}"</p>
              <button
                onClick={() => setSearchQuery("")}
                className="mt-6 px-6 py-3 text-sm font-bold text-blue-600 bg-blue-50 rounded-xl hover:bg-blue-100 transition-all"
              >
                Clear Search
              </button>
            </div>
          )}
        </div>
      </section>

      <WhyChooseUs />
    </div>
  )
}
