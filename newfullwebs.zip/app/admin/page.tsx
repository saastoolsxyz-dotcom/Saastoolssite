"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import {
  Settings,
  Key,
  Globe,
  PenTool as Tool,
  Save,
  CheckCircle2,
  Shield,
  LogOut,
  Sparkles,
  ImageIcon,
  FileText,
  Trash2,
  TestTube,
  Loader2,
  AlertCircle,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { getSettings, saveSettings, type AdminSettings, type ToolConfig } from "@/utils/adminSettings"
import { useToast } from "@/hooks/use-toast"

const TOOLS_LIST = [
  { id: "bg-remover", name: "Background Remover", category: "image" },
  { id: "image-gen", name: "AI Image Studio", category: "image" },
  { id: "analyzer", name: "Vision AI Analyzer", category: "image" },
  { id: "image-compressor", name: "Media Processor", category: "image" },
  { id: "math-solver", name: "Math Solver", category: "text" },
  { id: "pdf-qa", name: "PDF Chatbot", category: "text" },
  { id: "prompt-architect", name: "Prompt Architect", category: "text" },
  { id: "seo-meta-generator", name: "SEO Meta Gen", category: "text" },
  { id: "text-humanizer", name: "AI Humanizer", category: "text" },
  { id: "summarizer", name: "Summarizer", category: "text" },
  { id: "writer", name: "Writer", category: "text" },
]

const PROVIDERS = [
  { value: "google", label: "Google Gemini", icon: "🔷" },
  { value: "openrouter", label: "OpenRouter", icon: "🔀" },
  { value: "huggingface", label: "Hugging Face", icon: "🤗" },
]

export default function AdminPanel() {
  const router = useRouter()
  const { user, signOut, isAdmin } = useAuth()
  const { toast } = useToast()
  const [settings, setSettings] = useState<AdminSettings | null>(null)
  const [activeTab, setActiveTab] = useState("global")
  const [selectedTool, setSelectedTool] = useState<string>("")
  const [hasChanges, setHasChanges] = useState(false)
  const [testingApi, setTestingApi] = useState(false)
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null)

  // Check admin access
  useEffect(() => {
    if (!user || user.email !== "saastools.xyz@gmail.com") {
      toast({
        title: "Access Denied",
        description: "Only admin can access this panel.",
        variant: "destructive",
      })
      router.push("/")
    } else {
      setSettings(getSettings())
    }
  }, [user, router, toast])

  if (!settings || !user || user.email !== "saastools.xyz@gmail.com") {
    return null
  }

  const handleGlobalTextChange = (field: keyof ToolConfig, value: string) => {
    setSettings({
      ...settings,
      globalText: { ...settings.globalText, [field]: value },
    })
    setHasChanges(true)
    setTestResult(null)
  }

  const handleGlobalImageChange = (field: keyof ToolConfig, value: string) => {
    setSettings({
      ...settings,
      globalImage: { ...settings.globalImage, [field]: value },
    })
    setHasChanges(true)
    setTestResult(null)
  }

  const handleToolConfigChange = (toolId: string, field: keyof ToolConfig, value: string) => {
    setSettings({
      ...settings,
      tools: {
        ...settings.tools,
        [toolId]: {
          ...(settings.tools[toolId] || { provider: "google", apiKey: "", model: "" }),
          [field]: value,
        },
      },
    })
    setHasChanges(true)
    setTestResult(null)
  }

  const handleDeleteToolConfig = (toolId: string) => {
    const newTools = { ...settings.tools }
    delete newTools[toolId]
    setSettings({
      ...settings,
      tools: newTools,
    })
    setHasChanges(true)
    toast({
      title: "Configuration Removed",
      description: `${TOOLS_LIST.find((t) => t.id === toolId)?.name} will now use global settings.`,
    })
  }

  const handleTestApi = async () => {
    setTestingApi(true)
    setTestResult(null)

    try {
      // Use the current tab to determine which config to test
      const config = activeTab === "global" ? settings.globalText : selectedTool ? getToolConfig(selectedTool) : null

      if (!config || !config.apiKey) {
        throw new Error("Please enter an API key to test")
      }

      // Simple test based on provider
      const response = await fetch("/api/test-api", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(config),
      })

      const data = await response.json()

      if (data.success) {
        setTestResult({ success: true, message: "API is working correctly!" })
        toast({
          title: "Success",
          description: "API connection successful!",
        })
      } else {
        throw new Error(data.error || "API test failed")
      }
    } catch (error: any) {
      setTestResult({ success: false, message: error.message || "API test failed" })
      toast({
        title: "Error",
        description: error.message || "Failed to test API",
        variant: "destructive",
      })
    } finally {
      setTestingApi(false)
    }
  }

  const handleSave = () => {
    saveSettings(settings)
    setHasChanges(false)
    toast({
      title: "Settings Saved",
      description: "API configurations have been updated successfully.",
    })
  }

  const handleLogout = () => {
    signOut()
    router.push("/")
  }

  const getToolConfig = (toolId: string): ToolConfig => {
    const tool = TOOLS_LIST.find((t) => t.id === toolId)
    const category = tool?.category || "text"
    const globalConfig = category === "image" ? settings.globalImage : settings.globalText

    const toolSpecific = settings.tools[toolId]

    return {
      provider: toolSpecific?.provider || globalConfig.provider,
      apiKey: toolSpecific?.apiKey || globalConfig.apiKey || "",
      model: toolSpecific?.model || globalConfig.model || "",
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50">
      {/* Header */}
      <header className="border-b border-slate-200 bg-white/80 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="p-3 rounded-2xl bg-gradient-to-br from-blue-500 to-purple-600 shadow-lg">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-slate-900">Admin Panel</h1>
              <p className="text-sm text-slate-500">API Configuration & Management</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            {hasChanges && (
              <Button onClick={handleSave} size="lg" className="bg-gradient-to-r from-blue-600 to-purple-600 shadow-lg">
                <Save className="w-4 h-4 mr-2" />
                Save Changes
              </Button>
            )}
            <Button onClick={handleLogout} variant="outline" size="lg">
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-12">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-3xl p-6 shadow-lg border border-slate-200">
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-2xl bg-blue-100">
                <Globe className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-slate-500 font-medium">Global APIs</p>
                <p className="text-3xl font-bold text-slate-900">2</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-3xl p-6 shadow-lg border border-slate-200">
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-2xl bg-purple-100">
                <Tool className="w-6 h-6 text-purple-600" />
              </div>
              <div>
                <p className="text-sm text-slate-500 font-medium">Total Tools</p>
                <p className="text-3xl font-bold text-slate-900">{TOOLS_LIST.length}</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-3xl p-6 shadow-lg border border-slate-200">
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-2xl bg-amber-100">
                <Key className="w-6 h-6 text-amber-600" />
              </div>
              <div>
                <p className="text-sm text-slate-500 font-medium">Custom Configs</p>
                <p className="text-3xl font-bold text-slate-900">{Object.keys(settings.tools).length}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Main Configuration */}
        <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="w-full justify-start border-b border-slate-200 rounded-none h-auto p-0 bg-transparent">
              <TabsTrigger
                value="global"
                className="data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700 data-[state=active]:border-b-2 data-[state=active]:border-blue-600 rounded-none px-8 py-4 text-base font-semibold"
              >
                <Globe className="w-5 h-5 mr-2" />
                Global Settings
              </TabsTrigger>
              <TabsTrigger
                value="tools"
                className="data-[state=active]:bg-purple-50 data-[state=active]:text-purple-700 data-[state=active]:border-b-2 data-[state=active]:border-purple-600 rounded-none px-8 py-4 text-base font-semibold"
              >
                <Tool className="w-5 h-5 mr-2" />
                Tool-Specific
              </TabsTrigger>
            </TabsList>

            {/* Global Settings Tab */}
            <TabsContent value="global" className="p-8 space-y-8">
              {/* LLM Tools Global Config */}
              <div className="space-y-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-2 rounded-xl bg-gradient-to-br from-blue-500 to-blue-600">
                    <FileText className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-slate-900">LLM Tools (Text Generation)</h3>
                    <p className="text-sm text-slate-500">
                      Default API for all text-based tools (Writer, Summarizer, Math Solver, etc.)
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 p-6 rounded-2xl bg-slate-50 border border-slate-200">
                  <div className="space-y-2">
                    <Label htmlFor="global-text-provider" className="text-sm font-semibold text-slate-700">
                      Provider
                    </Label>
                    <Select
                      value={settings.globalText.provider}
                      onValueChange={(v) => handleGlobalTextChange("provider", v)}
                    >
                      <SelectTrigger id="global-text-provider" className="h-12">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {PROVIDERS.map((p) => (
                          <SelectItem key={p.value} value={p.value}>
                            {p.icon} {p.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="global-text-key" className="text-sm font-semibold text-slate-700">
                      API Key
                    </Label>
                    <Input
                      id="global-text-key"
                      type="password"
                      value={settings.globalText.apiKey || ""}
                      onChange={(e) => handleGlobalTextChange("apiKey", e.target.value)}
                      placeholder="Enter API key..."
                      className="h-12"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="global-text-model" className="text-sm font-semibold text-slate-700">
                      Model Name
                    </Label>
                    <Input
                      id="global-text-model"
                      value={settings.globalText.model || ""}
                      onChange={(e) => handleGlobalTextChange("model", e.target.value)}
                      placeholder="e.g., gemini-2.0-flash-exp"
                      className="h-12"
                    />
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <Button
                    onClick={handleTestApi}
                    disabled={testingApi || !settings.globalText.apiKey}
                    variant="outline"
                    className="border-2 border-blue-300 bg-transparent"
                  >
                    {testingApi ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Testing...
                      </>
                    ) : (
                      <>
                        <TestTube className="w-4 h-4 mr-2" />
                        Test API
                      </>
                    )}
                  </Button>

                  {testResult && (
                    <div
                      className={`flex items-center gap-2 px-4 py-2 rounded-xl ${
                        testResult.success ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"
                      }`}
                    >
                      {testResult.success ? <CheckCircle2 className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
                      <span className="text-sm font-semibold">{testResult.message}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Image Tools Global Config */}
              <div className="space-y-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-2 rounded-xl bg-gradient-to-br from-purple-500 to-purple-600">
                    <ImageIcon className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-slate-900">Image Tools</h3>
                    <p className="text-sm text-slate-500">Default API for image generation and processing tools</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 p-6 rounded-2xl bg-slate-50 border border-slate-200">
                  <div className="space-y-2">
                    <Label htmlFor="global-image-provider" className="text-sm font-semibold text-slate-700">
                      Provider
                    </Label>
                    <Select
                      value={settings.globalImage.provider}
                      onValueChange={(v) => handleGlobalImageChange("provider", v)}
                    >
                      <SelectTrigger id="global-image-provider" className="h-12">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {PROVIDERS.map((p) => (
                          <SelectItem key={p.value} value={p.value}>
                            {p.icon} {p.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="global-image-key" className="text-sm font-semibold text-slate-700">
                      API Key
                    </Label>
                    <Input
                      id="global-image-key"
                      type="password"
                      value={settings.globalImage.apiKey || ""}
                      onChange={(e) => handleGlobalImageChange("apiKey", e.target.value)}
                      placeholder="Enter API key..."
                      className="h-12"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="global-image-model" className="text-sm font-semibold text-slate-700">
                      Model Name
                    </Label>
                    <Input
                      id="global-image-model"
                      value={settings.globalImage.model || ""}
                      onChange={(e) => handleGlobalImageChange("model", e.target.value)}
                      placeholder="e.g., gemini-2.0-flash-exp or stable-diffusion-xl"
                      className="h-12"
                    />
                  </div>
                </div>
              </div>

              <div className="p-6 rounded-2xl bg-blue-50 border border-blue-200">
                <div className="flex items-start gap-3">
                  <Sparkles className="w-5 h-5 text-blue-600 mt-0.5" />
                  <div>
                    <p className="text-sm font-semibold text-blue-900 mb-1">Global API Configuration</p>
                    <p className="text-sm text-blue-700">
                      These settings will be used as defaults for all tools. You can override them for specific tools in
                      the Tool-Specific tab.
                    </p>
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* Tool-Specific Settings Tab */}
            <TabsContent value="tools" className="p-8 space-y-6">
              <div className="mb-6">
                <Label htmlFor="tool-select" className="text-base font-semibold text-slate-700 mb-3 block">
                  Select Tool to Configure
                </Label>
                <Select value={selectedTool} onValueChange={setSelectedTool}>
                  <SelectTrigger id="tool-select" className="h-14 text-base">
                    <SelectValue placeholder="Choose a tool..." />
                  </SelectTrigger>
                  <SelectContent>
                    {TOOLS_LIST.map((tool) => (
                      <SelectItem key={tool.id} value={tool.id}>
                        <div className="flex items-center gap-2">
                          {tool.category === "image" ? (
                            <ImageIcon className="w-4 h-4" />
                          ) : (
                            <FileText className="w-4 h-4" />
                          )}
                          {tool.name}
                          {settings.tools[tool.id] && <CheckCircle2 className="w-4 h-4 text-green-600" />}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {selectedTool && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between p-4 rounded-2xl bg-gradient-to-r from-purple-50 to-blue-50 border border-purple-200">
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-xl bg-white shadow-sm">
                        <Settings className="w-5 h-5 text-purple-600" />
                      </div>
                      <div>
                        <h3 className="text-lg font-bold text-slate-900">
                          {TOOLS_LIST.find((t) => t.id === selectedTool)?.name}
                        </h3>
                        <p className="text-sm text-slate-600">Custom API Configuration</p>
                      </div>
                    </div>
                    {settings.tools[selectedTool] && (
                      <Button
                        onClick={() => handleDeleteToolConfig(selectedTool)}
                        variant="outline"
                        size="sm"
                        className="border-red-300 text-red-600 hover:bg-red-50"
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Remove Config
                      </Button>
                    )}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 p-6 rounded-2xl bg-slate-50 border border-slate-200">
                    <div className="space-y-2">
                      <Label htmlFor="tool-provider" className="text-sm font-semibold text-slate-700">
                        Provider
                      </Label>
                      <Select
                        value={getToolConfig(selectedTool).provider}
                        onValueChange={(v) => handleToolConfigChange(selectedTool, "provider", v)}
                      >
                        <SelectTrigger id="tool-provider" className="h-12">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {PROVIDERS.map((p) => (
                            <SelectItem key={p.value} value={p.value}>
                              {p.icon} {p.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="tool-key" className="text-sm font-semibold text-slate-700">
                        API Key
                      </Label>
                      <Input
                        id="tool-key"
                        type="password"
                        value={getToolConfig(selectedTool).apiKey || ""}
                        onChange={(e) => handleToolConfigChange(selectedTool, "apiKey", e.target.value)}
                        placeholder="Leave empty to use global..."
                        className="h-12"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="tool-model" className="text-sm font-semibold text-slate-700">
                        Model Name
                      </Label>
                      <Input
                        id="tool-model"
                        value={getToolConfig(selectedTool).model || ""}
                        onChange={(e) => handleToolConfigChange(selectedTool, "model", e.target.value)}
                        placeholder="Leave empty to use global..."
                        className="h-12"
                      />
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    <Button
                      onClick={handleTestApi}
                      disabled={testingApi || !getToolConfig(selectedTool).apiKey}
                      variant="outline"
                      className="border-2 border-purple-300 bg-transparent"
                    >
                      {testingApi ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Testing...
                        </>
                      ) : (
                        <>
                          <TestTube className="w-4 h-4 mr-2" />
                          Test API
                        </>
                      )}
                    </Button>

                    {testResult && (
                      <div
                        className={`flex items-center gap-2 px-4 py-2 rounded-xl ${
                          testResult.success ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"
                        }`}
                      >
                        {testResult.success ? (
                          <CheckCircle2 className="w-5 h-5" />
                        ) : (
                          <AlertCircle className="w-5 h-5" />
                        )}
                        <span className="text-sm font-semibold">{testResult.message}</span>
                      </div>
                    )}
                  </div>

                  <div className="p-6 rounded-2xl bg-purple-50 border border-purple-200">
                    <div className="flex items-start gap-3">
                      <Sparkles className="w-5 h-5 text-purple-600 mt-0.5" />
                      <div>
                        <p className="text-sm font-semibold text-purple-900 mb-1">Tool-Specific Configuration</p>
                        <p className="text-sm text-purple-700">
                          Settings configured here will override the global settings for this specific tool. Leave
                          fields empty to use global defaults.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
