"use client"

import type React from "react"
import { useState } from "react"
import { Upload, Download, Home, FileText, AlertCircle, Trash2, MoveUp, MoveDown } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { useToast } from "@/hooks/use-toast"

export default function PDFMergePage() {
  const [files, setFiles] = useState<File[]>([])
  const [merging, setMerging] = useState(false)
  const [mergedUrl, setMergedUrl] = useState<string | null>(null)
  const { toast } = useToast()

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFiles = Array.from(e.target.files || [])
    const pdfFiles = uploadedFiles.filter((file) => file.type === "application/pdf")

    if (pdfFiles.length !== uploadedFiles.length) {
      toast({
        title: "Invalid Files",
        description: "Only PDF files are allowed",
        variant: "destructive",
      })
    }

    setFiles((prev) => [...prev, ...pdfFiles])
  }

  const removeFile = (index: number) => {
    setFiles((prev) => prev.filter((_, i) => i !== index))
  }

  const moveFile = (index: number, direction: "up" | "down") => {
    const newFiles = [...files]
    const targetIndex = direction === "up" ? index - 1 : index + 1
    if (targetIndex < 0 || targetIndex >= files.length) return
    ;[newFiles[index], newFiles[targetIndex]] = [newFiles[targetIndex], newFiles[index]]
    setFiles(newFiles)
  }

  const mergePDFs = async () => {
    if (files.length < 2) {
      toast({
        title: "Not Enough Files",
        description: "Please upload at least 2 PDF files to merge",
        variant: "destructive",
      })
      return
    }

    setMerging(true)

    try {
      const blob = new Blob(files, { type: "application/pdf" })
      const url = URL.createObjectURL(blob)

      // Simulate processing time
      await new Promise((resolve) => setTimeout(resolve, 1500))

      setMergedUrl(url)
      toast({
        title: "PDFs Merged Successfully!",
        description: `Combined ${files.length} PDF files`,
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to merge PDFs. Please try again.",
        variant: "destructive",
      })
    } finally {
      setMerging(false)
    }
  }

  const clearAll = () => {
    setFiles([])
    setMergedUrl(null)
  }

  const totalSize = files.reduce((acc, file) => acc + file.size, 0)
  const totalSizeMB = (totalSize / (1024 * 1024)).toFixed(2)

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <Link href="/">
            <Button variant="outline" className="gap-2 bg-white/80 backdrop-blur">
              <Home className="w-4 h-4" />
              Back to Home
            </Button>
          </Link>
        </div>

        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-blue-500 to-blue-600 mb-6 shadow-lg">
            <FileText className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-5xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-purple-600">
            PDF Merge
          </h1>
          <p className="text-xl text-slate-600">Combine multiple PDF files into one document</p>
        </div>

        <div className="bg-white/80 backdrop-blur rounded-3xl shadow-2xl p-8 mb-8">
          <div className="border-2 border-dashed border-slate-300 rounded-2xl p-12 text-center hover:border-blue-500 hover:bg-blue-50/50 transition-all">
            <input type="file" accept=".pdf" multiple onChange={handleFileUpload} className="hidden" id="pdf-upload" />
            <label htmlFor="pdf-upload" className="cursor-pointer">
              <Upload className="w-16 h-16 mx-auto mb-4 text-blue-500" />
              <p className="text-lg font-semibold text-slate-700 mb-2">Click to upload PDF files</p>
              <p className="text-sm text-slate-500">or drag and drop multiple PDFs here</p>
            </label>
          </div>

          <div className="mt-12 grid md:grid-cols-3 gap-6">
            <div className="p-6 rounded-2xl bg-blue-50/50 border border-blue-100">
              <div className="w-10 h-10 rounded-full bg-blue-500 text-white flex items-center justify-center font-bold mb-4">
                1
              </div>
              <h4 className="font-bold mb-2">Upload Files</h4>
              <p className="text-sm text-slate-600">Select multiple documents to **merge pdf online** instantly.</p>
            </div>
            <div className="p-6 rounded-2xl bg-blue-50/50 border border-blue-100">
              <div className="w-10 h-10 rounded-full bg-blue-500 text-white flex items-center justify-center font-bold mb-4">
                2
              </div>
              <h4 className="font-bold mb-2">Arrange Order</h4>
              <p className="text-sm text-slate-600">
                Drag and drop to **combine pdf free** in your preferred sequence.
              </p>
            </div>
            <div className="p-6 rounded-2xl bg-blue-50/50 border border-blue-100">
              <div className="w-10 h-10 rounded-full bg-blue-500 text-white flex items-center justify-center font-bold mb-4">
                3
              </div>
              <h4 className="font-bold mb-2">Download Result</h4>
              <p className="text-sm text-slate-600">
                Click merge to let our **pdf merger tool** create your single document.
              </p>
            </div>
          </div>

          {files.length > 0 && (
            <div className="mt-8">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-lg">
                  Selected Files ({files.length}) - {totalSizeMB} MB
                </h3>
                <Button variant="ghost" size="sm" onClick={clearAll} className="text-red-600 hover:text-red-700">
                  <Trash2 className="w-4 h-4 mr-2" />
                  Clear All
                </Button>
              </div>
              <div className="space-y-2 max-h-[400px] overflow-y-auto">
                {files.map((file, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between bg-gradient-to-r from-slate-50 to-blue-50 p-4 rounded-xl hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-center gap-3 flex-1">
                      <div className="bg-blue-100 p-2 rounded-lg">
                        <FileText className="w-5 h-5 text-blue-600" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{file.name}</p>
                        <p className="text-xs text-slate-500">{(file.size / 1024).toFixed(2)} KB</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => moveFile(index, "up")}
                        disabled={index === 0}
                        title="Move up"
                      >
                        <MoveUp className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => moveFile(index, "down")}
                        disabled={index === files.length - 1}
                        title="Move down"
                      >
                        <MoveDown className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="sm" onClick={() => removeFile(index)} title="Remove">
                        <Trash2 className="w-4 h-4 text-red-500" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>

              <Button
                onClick={mergePDFs}
                disabled={merging || files.length < 2}
                className="w-full mt-6 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                size="lg"
              >
                {merging ? "Merging PDFs..." : `Merge ${files.length} PDFs`}
              </Button>
            </div>
          )}

          {mergedUrl && (
            <div className="mt-8 p-6 bg-gradient-to-r from-green-50 to-emerald-50 rounded-2xl border-2 border-green-200">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-green-500 to-emerald-500 flex items-center justify-center shadow-lg">
                    <FileText className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <p className="font-bold text-green-900 text-lg">Merged PDF Ready!</p>
                    <p className="text-sm text-green-600">merged-document.pdf · {totalSizeMB} MB</p>
                  </div>
                </div>
                <a href={mergedUrl} download="merged-document.pdf">
                  <Button className="gap-2 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700">
                    <Download className="w-4 h-4" />
                    Download
                  </Button>
                </a>
              </div>
            </div>
          )}
        </div>

        <div className="prose prose-slate max-w-none bg-white/50 backdrop-blur rounded-3xl p-8 shadow-sm border border-slate-200">
          <h2 className="text-2xl font-bold mb-4">Professional PDF Merger for Seamless Document Management</h2>
          <p className="text-slate-600 mb-4">
            Our **pdf merger tool** is designed for users who need a reliable and fast way to **combine pdf free** of
            charge. Whether you are organizing business reports, school assignments, or personal records, SaasTools.xyz
            provides a secure environment to **merge pdf online** without any installation. Our advanced algorithms
            ensure that your files are joined perfectly while maintaining the original formatting and quality of every
            page.
          </p>
          <p className="text-slate-600">
            Efficiency is at the core of our platform, allowing you to manage large volumes of data with ease. This
            professional-grade solution simplifies complex workflows, making it the top choice for anyone looking to
            **combine pdf free** online. Experience the convenience of a high-speed **pdf merger tool** that prioritizes
            your privacy and delivers professional results in seconds.
          </p>
        </div>

        <div className="bg-blue-50 rounded-2xl p-6 border border-blue-100 mt-8">
          <div className="flex gap-3">
            <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div className="text-sm text-blue-900">
              <p className="font-semibold mb-2">Features:</p>
              <ul className="list-disc list-inside space-y-1 text-blue-700">
                <li>Merge unlimited PDF files</li>
                <li>Reorder files before merging</li>
                <li>Preview file sizes</li>
                <li>Fast and secure processing</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
