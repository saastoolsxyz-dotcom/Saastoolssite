import { Zap, Shield, Rocket, Users, Heart, Globe, Mail } from "lucide-react"

export const metadata = {
  title: "About Us - SaasTools AI Toolkit",
  description: "Learn about our mission to democratize AI tools and empower creators worldwide.",
}

export default function AboutPage() {
  const values = [
    {
      icon: Zap,
      title: "Innovation First",
      description: "We push the boundaries of AI technology to deliver cutting-edge tools that transform workflows.",
      gradient: "from-amber-500 to-orange-500",
    },
    {
      icon: Shield,
      title: "Privacy & Security",
      description: "Your data security is our top priority. We implement industry-leading protection measures.",
      gradient: "from-blue-500 to-cyan-500",
    },
    {
      icon: Heart,
      title: "User-Centric",
      description: "Every feature is designed with you in mind, ensuring intuitive and powerful experiences.",
      gradient: "from-pink-500 to-rose-500",
    },
    {
      icon: Rocket,
      title: "Speed & Performance",
      description: "Lightning-fast processing and optimized algorithms keep you productive without delays.",
      gradient: "from-purple-500 to-indigo-500",
    },
    {
      icon: Users,
      title: "Community Driven",
      description: "We listen to our users and continuously evolve based on your feedback and needs.",
      gradient: "from-green-500 to-emerald-500",
    },
    {
      icon: Globe,
      title: "Global Access",
      description: "Empowering creators and professionals worldwide with accessible AI technology.",
      gradient: "from-teal-500 to-cyan-500",
    },
  ]

  const stats = [
    { number: "1M+", label: "Active Users" },
    { number: "50M+", label: "AI Generations" },
    { number: "150+", label: "Countries" },
    { number: "99.9%", label: "Uptime" },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 px-4 overflow-hidden">
        <div className="absolute top-20 left-10 w-72 h-72 bg-purple-400 rounded-full mix-blend-multiply filter blur-3xl opacity-10"></div>
        <div className="absolute top-20 right-10 w-72 h-72 bg-blue-400 rounded-full mix-blend-multiply filter blur-3xl opacity-10"></div>

        <div className="max-w-4xl mx-auto text-center relative z-10">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-blue-50 to-purple-50 border border-blue-200 mb-8">
            <span className="text-xs font-bold text-blue-600 uppercase tracking-widest">About SaasTools</span>
          </div>

          <h1 className="text-5xl md:text-7xl font-black text-slate-900 mb-8 tracking-tight leading-tight">
            Building the Future of
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600">
              {" "}
              AI-Powered Productivity
            </span>
          </h1>

          <p className="text-xl md:text-2xl text-slate-600 leading-relaxed font-medium max-w-3xl mx-auto">
            We're on a mission to democratize access to powerful AI tools, enabling creators, entrepreneurs, and
            professionals to work smarter, faster, and more creatively.
          </p>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div
                key={index}
                className="bg-white rounded-3xl p-8 text-center shadow-lg border border-slate-200 hover:shadow-xl transition-shadow"
              >
                <div className="text-4xl md:text-5xl font-black bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-purple-600 mb-2">
                  {stat.number}
                </div>
                <div className="text-slate-600 font-semibold text-sm uppercase tracking-wider">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-3xl p-8 md:p-16 shadow-lg border border-slate-200">
            <h2 className="text-4xl md:text-5xl font-black text-slate-900 mb-8 tracking-tight">Our Story</h2>
            <div className="space-y-6 text-lg text-slate-600 leading-relaxed">
              <p>
                SaasTools was born from a simple observation: AI technology was advancing rapidly, but powerful tools
                remained locked behind complex interfaces, expensive licenses, and steep learning curves.
              </p>
              <p>
                Founded by <span className="font-semibold text-slate-900">Abdullah Dogar</span>, our mission began with
                a shared vision: to create an accessible, affordable, and intuitive platform that puts
                professional-grade AI tools in everyone's hands.
              </p>
              <p>
                Today, SaasTools serves over 1 million users worldwide, processing millions of AI requests daily. From
                content creators and students to entrepreneurs and Fortune 500 companies, our platform empowers people
                to achieve more with less effort.
              </p>
              <p className="text-slate-900 font-semibold">
                But we're just getting started. The future of work is intelligent, creative, and limitless—and we're
                building it together.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20 px-4 bg-gradient-to-b from-white to-slate-50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-black text-slate-900 mb-6 tracking-tight">Our Core Values</h2>
            <p className="text-xl text-slate-600 font-medium max-w-2xl mx-auto">
              The principles that guide everything we build and every decision we make.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {values.map((value, index) => (
              <div
                key={index}
                className="bg-white rounded-3xl p-8 shadow-lg border border-slate-200 hover:shadow-xl transition-all group"
              >
                <div
                  className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${value.gradient} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}
                >
                  <value.icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-slate-900 mb-3">{value.title}</h3>
                <p className="text-slate-600 leading-relaxed">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Founder Section */}
      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="bg-gradient-to-br from-slate-900 to-slate-800 rounded-3xl p-8 md:p-12 shadow-2xl border border-slate-700">
            <div className="flex flex-col md:flex-row items-center gap-8">
              <div className="w-32 h-32 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white text-4xl font-black shadow-xl">
                AD
              </div>
              <div className="flex-1 text-center md:text-left">
                <h3 className="text-3xl md:text-4xl font-black text-white mb-3">Abdullah Dogar</h3>
                <p className="text-lg text-slate-300 mb-4">Founder & CEO, SaasTools.xyz</p>
                <p className="text-slate-400 leading-relaxed mb-6">
                  Passionate about democratizing AI technology and empowering creators worldwide with intelligent tools
                  that transform productivity and creativity.
                </p>
                <a
                  href="mailto:saastools.xyz@gmail.com"
                  className="inline-flex items-center gap-2 px-6 py-3 bg-white text-slate-900 rounded-xl font-semibold hover:bg-slate-100 transition-all shadow-lg"
                >
                  <Mail className="w-5 h-5" />
                  saastools.xyz@gmail.com
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Team CTA Section */}
      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600 rounded-3xl p-12 md:p-16 text-center text-white shadow-2xl">
            <h2 className="text-4xl md:text-5xl font-black mb-6 tracking-tight">Join Our Journey</h2>
            <p className="text-xl md:text-2xl mb-10 opacity-90 leading-relaxed">
              We're always looking for talented people who share our passion for innovation and excellence.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="/signup"
                className="px-10 py-5 bg-white text-blue-600 rounded-2xl font-bold text-lg hover:bg-slate-50 transition-all shadow-xl hover:scale-105"
              >
                Start Building Today
              </a>
              <a
                href="mailto:saastools.xyz@gmail.com"
                className="px-10 py-5 bg-white/10 backdrop-blur-sm text-white rounded-2xl font-bold text-lg border-2 border-white/30 hover:bg-white/20 transition-all"
              >
                Contact Us
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
