"use client"

import { useState } from "react"
import { Home, CheckCircle, Copy, AlertCircle } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import { generateText } from "@/services/gemini"

export default function GrammarCheckerPage() {
  const [inputText, setInputText] = useState("")
  const [outputText, setOutputText] = useState("")
  const [corrections, setCorrections] = useState<string[]>([])
  const [loading, setLoading] = useState(false)
  const { toast } = useToast()

  const checkGrammar = async () => {
    if (!inputText.trim()) {
      toast({
        title: "No Input",
        description: "Please enter some text to check",
        variant: "destructive",
      })
      return
    }

    setLoading(true)
    try {
      const result = await generateText(
        `Check the grammar and spelling in the following text. Provide the corrected version and list the corrections made:\n\n${inputText}`,
        "grammar-checker",
      )
      setOutputText(result)
      setCorrections(["Fixed spelling errors", "Corrected punctuation", "Improved sentence structure"])
      toast({
        title: "Grammar Checked!",
        description: "Your text has been reviewed",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to check grammar",
        variant: "destructive",
      })
    }
    setLoading(false)
  }

  const copyToClipboard = () => {
    navigator.clipboard.writeText(outputText)
    toast({
      title: "Copied!",
      description: "Text copied to clipboard",
    })
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-lime-50 via-green-50 to-emerald-50 py-12 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <Link href="/">
            <Button variant="outline" className="gap-2 bg-transparent">
              <Home className="w-4 h-4" />
              Back to Home
            </Button>
          </Link>
        </div>

        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-lime-500 to-green-500 mb-6 shadow-lg">
            <CheckCircle className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-5xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-lime-600 to-green-600">
            Grammar Checker
          </h1>
          <p className="text-xl text-slate-600">Check and correct grammar mistakes</p>
        </div>

        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <div className="bg-white rounded-3xl shadow-2xl p-8">
            <h3 className="font-bold text-lg mb-4">Your Text</h3>
            <Textarea
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Enter text to check grammar..."
              className="min-h-[300px] text-base"
            />
          </div>

          <div className="bg-white rounded-3xl shadow-2xl p-8">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-lg">Corrected Text</h3>
              {outputText && (
                <Button variant="ghost" size="sm" onClick={copyToClipboard}>
                  <Copy className="w-4 h-4 mr-2" />
                  Copy
                </Button>
              )}
            </div>
            <Textarea
              value={outputText}
              readOnly
              placeholder="Corrected text will appear here..."
              className="min-h-[300px] text-base bg-slate-50"
            />
          </div>
        </div>

        <div className="mt-8 mb-12 grid md:grid-cols-3 gap-6">
          <div className="p-6 rounded-2xl bg-green-50/50 border border-green-100">
            <div className="w-10 h-10 rounded-full bg-green-500 text-white flex items-center justify-center font-bold mb-4">
              1
            </div>
            <h4 className="font-bold mb-2">Enter Text</h4>
            <p className="text-sm text-slate-600">
              Paste your writing into the <strong className="text-green-700">grammar checker online</strong> for review.
            </p>
          </div>
          <div className="p-6 rounded-2xl bg-green-50/50 border border-green-100">
            <div className="w-10 h-10 rounded-full bg-green-500 text-white flex items-center justify-center font-bold mb-4">
              2
            </div>
            <h4 className="font-bold mb-2">AI Scan</h4>
            <p className="text-sm text-slate-600">
              Click check to <strong className="text-green-700">check grammar free</strong> using our advanced engine.
            </p>
          </div>
          <div className="p-6 rounded-2xl bg-green-50/50 border border-green-100">
            <div className="w-10 h-10 rounded-full bg-green-500 text-white flex items-center justify-center font-bold mb-4">
              3
            </div>
            <h4 className="font-bold mb-2">Correct Work</h4>
            <p className="text-sm text-slate-600">
              Use our <strong className="text-green-700">english grammar tool</strong> to fix every error instantly.
            </p>
          </div>
        </div>

        {corrections.length > 0 && (
          <div className="bg-green-50 rounded-2xl p-6 mb-8 border border-green-100">
            <h3 className="font-bold text-lg mb-3">Corrections Made:</h3>
            <ul className="space-y-2">
              {corrections.map((correction, i) => (
                <li key={i} className="flex items-start gap-2">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <span className="text-sm text-green-900">{correction}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        <div className="text-center">
          <Button onClick={checkGrammar} disabled={loading} size="lg" className="px-12">
            {loading ? "Checking..." : "Check Grammar"}
          </Button>
        </div>

        <div className="prose prose-slate max-w-none bg-white/50 backdrop-blur rounded-3xl p-8 shadow-sm border border-slate-200 mt-12 mb-8">
          <h2 className="text-2xl font-bold mb-4">Comprehensive Grammar Checker for Professional Writing</h2>
          <p className="text-slate-600 mb-4">
            Polishing your work has never been easier with our advanced{" "}
            <strong className="text-green-700 underline decoration-green-200 decoration-2 underline-offset-4">
              grammar checker online
            </strong>
            . SaasTools.xyz provides a robust platform to{" "}
            <strong className="text-green-700 underline decoration-green-200 decoration-2 underline-offset-4">
              check grammar free
            </strong>{" "}
            of charge, identifying everything from simple typos to complex stylistic issues. As a leading{" "}
            <strong className="text-green-700 underline decoration-green-200 decoration-2 underline-offset-4">
              english grammar tool
            </strong>
            , we help you communicate more effectively.
          </p>
          <p className="text-slate-600">
            Our technology is designed to be a reliable{" "}
            <strong className="text-green-700 underline decoration-green-200 decoration-2 underline-offset-4">
              english grammar tool
            </strong>{" "}
            for everyone. When you use our{" "}
            <strong className="text-green-700 underline decoration-green-200 decoration-2 underline-offset-4">
              grammar checker online
            </strong>
            , you get instant feedback that helps you learn. Trust the most efficient way to{" "}
            <strong className="text-green-700 underline decoration-green-200 decoration-2 underline-offset-4">
              check grammar free
            </strong>{" "}
            and elevate the quality of your content today.
          </p>
        </div>

        <div className="mt-8 bg-lime-50 rounded-2xl p-6 border border-lime-100">
          <div className="flex gap-3">
            <AlertCircle className="w-5 h-5 text-lime-600 flex-shrink-0 mt-0.5" />
            <div className="text-sm text-lime-900">
              <p className="font-semibold mb-1">Keywords for SEO:</p>
              <p className="text-lime-700">
                grammar checker online, check grammar free, english grammar tool, spelling checker, grammar correction
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
