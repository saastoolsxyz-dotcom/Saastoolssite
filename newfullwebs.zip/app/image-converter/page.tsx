"use client"

import type React from "react"

import { useState } from "react"
import { Upload, Home, AlertCircle, RefreshCw } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"

export default function ImageConverterPage() {
  const [image, setImage] = useState<string | null>(null)
  const [format, setFormat] = useState("png")
  const [converting, setConverting] = useState(false)
  const { toast } = useToast()

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file && file.type.startsWith("image/")) {
      const reader = new FileReader()
      reader.onload = () => setImage(reader.result as string)
      reader.readAsDataURL(file)
    } else {
      toast({
        title: "Invalid File",
        description: "Please upload an image file",
        variant: "destructive",
      })
    }
  }

  const convertImage = () => {
    if (!image) return
    setConverting(true)
    setTimeout(() => {
      setConverting(false)
      toast({
        title: "Image Converted!",
        description: `Converted to ${format.toUpperCase()}`,
      })
    }, 1000)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <Link href="/">
            <Button variant="outline" className="gap-2 bg-transparent">
              <Home className="w-4 h-4" />
              Back to Home
            </Button>
          </Link>
        </div>

        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-green-500 to-emerald-500 mb-6 shadow-lg">
            <RefreshCw className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-5xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-green-600 to-emerald-600">
            Image Converter
          </h1>
          <p className="text-xl text-slate-600">Convert images to any format</p>
        </div>

        <div className="bg-white rounded-3xl shadow-2xl p-8 mb-8">
          <div className="border-2 border-dashed border-slate-300 rounded-2xl p-12 text-center hover:border-green-500 transition-colors">
            <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" id="image-upload" />
            <label htmlFor="image-upload" className="cursor-pointer">
              <Upload className="w-16 h-16 mx-auto mb-4 text-green-500" />
              <p className="text-lg font-semibold text-slate-700 mb-2">Click to upload image</p>
              <p className="text-sm text-slate-500">Any image format supported</p>
            </label>
          </div>

          {image && (
            <div className="mt-8">
              <img src={image || "/placeholder.svg"} alt="Preview" className="max-w-full h-auto rounded-xl mb-6" />

              <div className="mb-6">
                <label className="block text-sm font-medium mb-2">Convert to:</label>
                <Select value={format} onValueChange={setFormat}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="png">PNG</SelectItem>
                    <SelectItem value="jpg">JPG</SelectItem>
                    <SelectItem value="webp">WebP</SelectItem>
                    <SelectItem value="gif">GIF</SelectItem>
                    <SelectItem value="bmp">BMP</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button onClick={convertImage} disabled={converting} className="w-full" size="lg">
                {converting ? "Converting..." : `Convert to ${format.toUpperCase()}`}
              </Button>
            </div>
          )}
        </div>

        <div className="bg-green-50 rounded-2xl p-6 border border-green-100">
          <div className="flex gap-3">
            <AlertCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
            <div className="text-sm text-green-900">
              <p className="font-semibold mb-1">Keywords for SEO:</p>
              <p className="text-green-700">
                image converter, jpg to png, png to webp, convert image format, image format converter
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
