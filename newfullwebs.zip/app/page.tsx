import { Suspense } from "react"
import HomeClient from "./home-client"

export const metadata = {
  title: "The Ultimate AI Toolkit - SaasTools",
  description: "Transform your workflow with cutting-edge AI tools. Optimized for speed, privacy, and precision.",
}

export default function HomePage() {
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <HomeClient />
    </Suspense>
  )
}
