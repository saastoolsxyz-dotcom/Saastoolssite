"use client"

import type React from "react"
import { useState, useRef } from "react"
import { Upload, Home, AlertCircle, Maximize2, Download, Lock } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { useToast } from "@/hooks/use-toast"

export default function ImageResizerPage() {
  const [image, setImage] = useState<string | null>(null)
  const [originalDimensions, setOriginalDimensions] = useState({ width: 0, height: 0 })
  const [width, setWidth] = useState<number>(800)
  const [height, setHeight] = useState<number>(600)
  const [maintainRatio, setMaintainRatio] = useState(true)
  const [resizedImage, setResizedImage] = useState<string | null>(null)
  const [resizing, setResizing] = useState(false)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const { toast } = useToast()

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file && file.type.startsWith("image/")) {
      const reader = new FileReader()
      reader.onload = (event) => {
        const img = new Image()
        img.onload = () => {
          setImage(event.target?.result as string)
          setOriginalDimensions({ width: img.width, height: img.height })
          setWidth(img.width)
          setHeight(img.height)
          setResizedImage(null)
        }
        img.src = event.target?.result as string
      }
      reader.readAsDataURL(file)
    } else {
      toast({
        title: "Invalid File",
        description: "Please upload an image file",
        variant: "destructive",
      })
    }
  }

  const resizeImage = () => {
    if (!image || !canvasRef.current) return

    setResizing(true)

    const img = new Image()
    img.onload = () => {
      const canvas = canvasRef.current!
      canvas.width = width
      canvas.height = height

      const ctx = canvas.getContext("2d")!
      ctx.drawImage(img, 0, 0, width, height)

      const resized = canvas.toDataURL("image/png")
      setResizedImage(resized)
      setResizing(false)

      toast({
        title: "Image Resized!",
        description: `Resized to ${width}x${height}px`,
      })
    }
    img.src = image
  }

  const handleWidthChange = (newWidth: number) => {
    setWidth(newWidth)
    if (maintainRatio && originalDimensions.width > 0) {
      const ratio = originalDimensions.height / originalDimensions.width
      setHeight(Math.round(newWidth * ratio))
    }
  }

  const handleHeightChange = (newHeight: number) => {
    setHeight(newHeight)
    if (maintainRatio && originalDimensions.height > 0) {
      const ratio = originalDimensions.width / originalDimensions.height
      setWidth(Math.round(newHeight * ratio))
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 via-cyan-50 to-blue-50 py-12 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <Link href="/">
            <Button variant="outline" className="gap-2 bg-white/80 backdrop-blur">
              <Home className="w-4 h-4" />
              Back to Home
            </Button>
          </Link>
        </div>

        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-teal-500 to-cyan-500 mb-6 shadow-lg">
            <Maximize2 className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-5xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-teal-600 to-cyan-600">
            Image Resizer
          </h1>
          <p className="text-xl text-slate-600">Resize images with precision</p>
        </div>

        <div className="bg-white/80 backdrop-blur rounded-3xl shadow-2xl p-8 mb-8">
          <div className="border-2 border-dashed border-slate-300 rounded-2xl p-12 text-center hover:border-teal-500 hover:bg-teal-50/50 transition-all">
            <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" id="image-upload" />
            <label htmlFor="image-upload" className="cursor-pointer">
              <Upload className="w-16 h-16 mx-auto mb-4 text-teal-500" />
              <p className="text-lg font-semibold text-slate-700 mb-2">Click to upload image</p>
              <p className="text-sm text-slate-500">JPG, PNG, GIF, WebP supported</p>
            </label>
          </div>

          <div className="mt-12 grid md:grid-cols-3 gap-6">
            <div className="p-6 rounded-2xl bg-teal-50/50 border border-teal-100">
              <div className="w-10 h-10 rounded-full bg-teal-500 text-white flex items-center justify-center font-bold mb-4">
                1
              </div>
              <h4 className="font-bold mb-2">Upload Photo</h4>
              <p className="text-sm text-slate-600">
                Upload any file to **resize image online** without losing quality.
              </p>
            </div>
            <div className="p-6 rounded-2xl bg-teal-50/50 border border-teal-100">
              <div className="w-10 h-10 rounded-full bg-teal-500 text-white flex items-center justify-center font-bold mb-4">
                2
              </div>
              <h4 className="font-bold mb-2">Set Dimensions</h4>
              <p className="text-sm text-slate-600">Use our **image resizer free** to enter custom width and height.</p>
            </div>
            <div className="p-6 rounded-2xl bg-teal-50/50 border border-teal-100">
              <div className="w-10 h-10 rounded-full bg-teal-500 text-white flex items-center justify-center font-bold mb-4">
                3
              </div>
              <h4 className="font-bold mb-2">Apply Change</h4>
              <p className="text-sm text-slate-600">
                Instantly **change image size** and download your optimized visual.
              </p>
            </div>
          </div>

          {image && (
            <div className="mt-8 grid md:grid-cols-2 gap-8">
              <div>
                <h3 className="font-bold text-lg mb-4">Original Image</h3>
                <div className="bg-slate-50 rounded-xl p-4 mb-4">
                  <img src={image || "/placeholder.svg"} alt="Original" className="max-w-full h-auto rounded-lg" />
                </div>
                <p className="text-sm text-slate-600">
                  Size: {originalDimensions.width} x {originalDimensions.height}px
                </p>
              </div>

              <div>
                <h3 className="font-bold text-lg mb-4">New Dimensions</h3>
                <div className="space-y-4 mb-6">
                  <div>
                    <label className="block text-sm font-medium mb-2">Width (px)</label>
                    <Input
                      type="number"
                      value={width}
                      onChange={(e) => handleWidthChange(Number.parseInt(e.target.value) || 0)}
                      className="w-full"
                      min="1"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Height (px)</label>
                    <Input
                      type="number"
                      value={height}
                      onChange={(e) => handleHeightChange(Number.parseInt(e.target.value) || 0)}
                      className="w-full"
                      min="1"
                    />
                  </div>
                  <label className="flex items-center gap-3">
                    <Checkbox checked={maintainRatio} onCheckedChange={(checked) => setMaintainRatio(!!checked)} />
                    <span className="text-sm flex items-center gap-2">
                      <Lock className="w-4 h-4" />
                      Maintain aspect ratio
                    </span>
                  </label>
                </div>

                <Button
                  onClick={resizeImage}
                  disabled={resizing || width < 1 || height < 1}
                  className="w-full bg-gradient-to-r from-teal-600 to-cyan-600 hover:from-teal-700 hover:to-cyan-700"
                  size="lg"
                >
                  {resizing ? "Resizing..." : "Resize Image"}
                </Button>

                {resizedImage && (
                  <div className="mt-6">
                    <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl p-4 border border-green-200">
                      <img
                        src={resizedImage || "/placeholder.svg"}
                        alt="Resized"
                        className="max-w-full h-auto rounded-lg mb-4"
                      />
                      <a href={resizedImage} download="resized-image.png">
                        <Button className="w-full gap-2 bg-gradient-to-r from-green-600 to-emerald-600">
                          <Download className="w-4 h-4" />
                          Download Resized Image
                        </Button>
                      </a>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          <canvas ref={canvasRef} className="hidden" />
        </div>

        <div className="prose prose-slate max-w-none bg-white/50 backdrop-blur rounded-3xl p-8 shadow-sm border border-slate-200">
          <h2 className="text-2xl font-bold mb-4">Professional Image Resizer for Social Media and Web</h2>
          <p className="text-slate-600 mb-4">
            SaasTools.xyz provides a state-of-the-art solution to **resize image online** for any platform or device.
            Our **image resizer free** tool is perfect for bloggers, marketers, and photographers who need to **change
            image size** while maintaining perfect aspect ratios. Whether you are preparing images for a website header,
            an Instagram post, or a professional presentation, our tool ensures that your visuals are perfectly scaled
            every time.
          </p>
          <p className="text-slate-600">
            With our user-friendly interface, you can **change image size** in a matter of seconds, making it a highly
            efficient **image resizer free** online. We prioritize speed and quality, ensuring that every time you
            **resize image online**, the output is sharp and professional. Optimize your visual content workflow with
            our reliable and precise resizing technology.
          </p>
        </div>

        <div className="bg-teal-50 rounded-2xl p-6 border border-teal-100 mt-8">
          <div className="flex gap-3">
            <AlertCircle className="w-5 h-5 text-teal-600 flex-shrink-0 mt-0.5" />
            <div className="text-sm text-teal-900">
              <p className="font-semibold mb-2">Features:</p>
              <ul className="list-disc list-inside space-y-1 text-teal-700">
                <li>Custom width and height control</li>
                <li>Maintain aspect ratio option</li>
                <li>Instant preview before download</li>
                <li>High-quality image output</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
