"use client"

import type React from "react"

import { useState, useRef } from "react"
import { FileText, Loader2, Upload, Copy, Home, Sparkles, Wand2, History, ChevronRight, Zap } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"
import { summarizeContent, type SummaryOptions } from "@/services/gemini"
import { Badge } from "@/components/ui/badge"

export default function SummarizerPage() {
  const [inputType, setInputType] = useState<"text" | "url" | "file">("text")
  const [textInput, setTextInput] = useState("")
  const [urlInput, setUrlInput] = useState("")
  const [fileInput, setFileInput] = useState<File | null>(null)
  const [length, setLength] = useState<"short" | "medium" | "detailed">("medium")
  const [format, setFormat] = useState<"paragraph" | "bullets" | "headline" | "action_items">("paragraph")
  const [style, setStyle] = useState<"simple" | "formal" | "academic" | "creative">("simple")
  const [summary, setSummary] = useState("")
  const [isSummarizing, setIsSummarizing] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) setFileInput(file)
  }

  const handleSummarize = async () => {
    let input = ""
    let type: "text" | "url" | "file" = "text"

    if (inputType === "text") {
      if (!textInput.trim()) {
        toast({ title: "Missing Input", description: "Please enter text to summarize.", variant: "destructive" })
        return
      }
      input = textInput
      type = "text"
    } else if (inputType === "url") {
      if (!urlInput.trim()) {
        toast({ title: "Missing URL", description: "Please enter a URL to summarize.", variant: "destructive" })
        return
      }
      input = urlInput
      type = "url"
    } else if (inputType === "file") {
      if (!fileInput) {
        toast({ title: "Missing File", description: "Please upload a file to summarize.", variant: "destructive" })
        return
      }
      const reader = new FileReader()
      const readFile = new Promise<string>((resolve) => {
        reader.onload = () => {
          const base64 = (reader.result as string).split(",")[1]
          resolve(base64)
        }
        reader.readAsDataURL(fileInput)
      })
      input = await readFile
      type = "file"
    }

    setIsSummarizing(true)

    try {
      const options: SummaryOptions = { length, format, style }
      const result = await summarizeContent(input, type, options, fileInput?.type || "text/plain", "summarizer")
      setSummary(result)

      toast({
        title: "Success",
        description: "Content summarized successfully!",
      })
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to summarize content.",
        variant: "destructive",
      })
    } finally {
      setIsSummarizing(false)
    }
  }

  const handleCopy = () => {
    navigator.clipboard.writeText(summary)
    toast({ title: "Copied!", description: "Summary copied to clipboard." })
  }

  return (
    <div className="min-h-screen bg-[#FDFCFD] dark:bg-slate-950 py-12 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Navigation & Breadcrumb */}
        <div className="flex items-center justify-between mb-12">
          <Button
            onClick={() => (window.location.href = "/")}
            variant="ghost"
            className="rounded-xl hover:bg-rose-50 hover:text-rose-600 transition-colors"
          >
            <Home className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
          <div className="flex items-center gap-2 text-sm text-slate-500 font-medium">
            <span>Tools</span>
            <ChevronRight className="w-3 h-3" />
            <span className="text-slate-900 dark:text-slate-100">AI Summarizer</span>
          </div>
        </div>

        {/* Header Section */}
        <div className="relative mb-16">
          <div className="absolute -top-12 left-1/2 -translate-x-1/2 w-64 h-64 bg-rose-200/30 rounded-full blur-3xl -z-10"></div>
          <div className="text-center">
            <Badge
              variant="secondary"
              className="mb-4 px-4 py-1 rounded-full bg-rose-50 text-rose-600 border-rose-100 flex items-center gap-1.5 w-fit mx-auto"
            >
              <Zap className="w-3 h-3 fill-rose-600" />
              Powered by Gemini 2.5
            </Badge>
            <h1 className="text-4xl md:text-6xl font-black text-slate-900 dark:text-white mb-6 tracking-tight">
              Transform Content into{" "}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-rose-500 to-pink-600">Insights</span>
            </h1>
            <p className="text-lg md:text-xl text-slate-500 dark:text-slate-400 max-w-2xl mx-auto font-medium leading-relaxed">
              Distill long documents, articles, and raw text into clear, actionable summaries in seconds.
            </p>
          </div>
        </div>

        <div className="grid lg:grid-cols-12 gap-8 items-start">
          {/* Main Input Area */}
          <div className="lg:col-span-7 space-y-6">
            <Card className="overflow-hidden border-slate-200 dark:border-slate-800 shadow-xl shadow-slate-200/50 dark:shadow-none rounded-[2rem] bg-white dark:bg-slate-900">
              <div className="p-1 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
                <Tabs value={inputType} onValueChange={(v: any) => setInputType(v)} className="w-full">
                  <TabsList className="bg-transparent h-12 gap-2 p-1">
                    <TabsTrigger
                      value="text"
                      className="rounded-xl px-6 data-[state=active]:bg-white dark:data-[state=active]:bg-slate-800 data-[state=active]:shadow-sm text-sm font-bold"
                    >
                      Raw Text
                    </TabsTrigger>
                    <TabsTrigger
                      value="url"
                      className="rounded-xl px-6 data-[state=active]:bg-white dark:data-[state=active]:bg-slate-800 data-[state=active]:shadow-sm text-sm font-bold"
                    >
                      Website URL
                    </TabsTrigger>
                    <TabsTrigger
                      value="file"
                      className="rounded-xl px-6 data-[state=active]:bg-white dark:data-[state=active]:bg-slate-800 data-[state=active]:shadow-sm text-sm font-bold"
                    >
                      Upload PDF
                    </TabsTrigger>
                  </TabsList>
                </Tabs>
              </div>

              <div className="p-8">
                {inputType === "text" && (
                  <div className="space-y-4">
                    <Textarea
                      value={textInput}
                      onChange={(e) => setTextInput(e.target.value)}
                      placeholder="Paste the content you want to summarize here..."
                      className="min-h-[300px] border-none focus-visible:ring-0 text-lg leading-relaxed resize-none p-0 bg-transparent placeholder:text-slate-300 dark:placeholder:text-slate-700"
                    />
                    <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-800">
                      <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">
                        {textInput.length} characters
                      </span>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-rose-600 font-bold hover:bg-rose-50"
                        onClick={() => setTextInput("")}
                      >
                        Clear
                      </Button>
                    </div>
                  </div>
                )}

                {inputType === "url" && (
                  <div className="py-12 space-y-6">
                    <div className="w-16 h-16 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto mb-4">
                      <Sparkles className="w-8 h-8" />
                    </div>
                    <div className="text-center max-w-sm mx-auto">
                      <h3 className="text-lg font-bold text-slate-900 mb-2">Fetch from URL</h3>
                      <p className="text-sm text-slate-500 mb-6">
                        Enter a public article or blog post URL and we'll extract the core content for you.
                      </p>
                      <Input
                        value={urlInput}
                        onChange={(e) => setUrlInput(e.target.value)}
                        placeholder="https://example.com/blog/article-name"
                        className="rounded-xl h-12 bg-slate-50 border-slate-200 dark:bg-slate-800 dark:border-slate-700"
                      />
                    </div>
                  </div>
                )}

                {inputType === "file" && (
                  <div className="py-12 text-center">
                    <div
                      onClick={() => fileInputRef.current?.click()}
                      className="group border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-[2rem] p-12 hover:border-rose-500 hover:bg-rose-50/30 dark:hover:bg-rose-950/20 transition-all cursor-pointer"
                    >
                      <div className="w-20 h-20 rounded-3xl bg-slate-50 dark:bg-slate-800 group-hover:bg-rose-100 dark:group-hover:bg-rose-900 flex items-center justify-center mx-auto mb-6 transition-colors">
                        <Upload className="w-10 h-10 text-slate-400 group-hover:text-rose-600 transition-colors" />
                      </div>
                      <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">
                        {fileInput ? fileInput.name : "Drop your PDF here"}
                      </h3>
                      <p className="text-slate-500 text-sm max-w-[240px] mx-auto font-medium">
                        Support for PDF, DOCX, and TXT files up to 20MB.
                      </p>
                      <input ref={fileInputRef} type="file" onChange={handleFileSelect} className="hidden" />
                    </div>
                  </div>
                )}
              </div>
            </Card>
          </div>

          {/* Sidebar Settings & Result */}
          <div className="lg:col-span-5 space-y-6">
            <Card className="p-8 border-slate-200 dark:border-slate-800 rounded-[2rem] bg-white dark:bg-slate-900 shadow-xl shadow-slate-200/50 dark:shadow-none">
              <h3 className="text-xl font-black text-slate-900 dark:text-white mb-6 uppercase tracking-wider flex items-center gap-2">
                <Wand2 className="w-5 h-5 text-rose-600" />
                Customize
              </h3>

              <div className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-xs font-black text-slate-400 uppercase tracking-widest">Length</Label>
                    <Select value={length} onValueChange={(v: any) => setLength(v)}>
                      <SelectTrigger className="rounded-xl bg-slate-50 border-none h-12 font-bold dark:bg-slate-800">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="rounded-xl font-bold">
                        <SelectItem value="short">Short</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="detailed">Detailed</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label className="text-xs font-black text-slate-400 uppercase tracking-widest">Format</Label>
                    <Select value={format} onValueChange={(v: any) => setFormat(v)}>
                      <SelectTrigger className="rounded-xl bg-slate-50 border-none h-12 font-bold dark:bg-slate-800">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="rounded-xl font-bold">
                        <SelectItem value="paragraph">Paragraph</SelectItem>
                        <SelectItem value="bullets">Bullets</SelectItem>
                        <SelectItem value="action_items">Action Items</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label className="text-xs font-black text-slate-400 uppercase tracking-widest">Tone & Style</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {["simple", "formal", "academic", "creative"].map((s) => (
                      <button
                        key={s}
                        onClick={() => setStyle(s as any)}
                        className={`px-4 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all border ${
                          style === s
                            ? "bg-rose-600 border-rose-600 text-white shadow-lg shadow-rose-200"
                            : "bg-white border-slate-100 text-slate-500 hover:border-rose-200 dark:bg-slate-800 dark:border-slate-700"
                        }`}
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                </div>

                <Button
                  onClick={handleSummarize}
                  disabled={isSummarizing}
                  className="w-full bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-700 hover:to-pink-700 text-white rounded-2xl py-8 text-lg font-black uppercase tracking-widest shadow-2xl shadow-rose-200 dark:shadow-none transition-all hover:scale-[1.02] active:scale-[0.98]"
                >
                  {isSummarizing ? (
                    <>
                      <Loader2 className="w-6 h-6 mr-3 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-6 h-6 mr-3" />
                      Generate Summary
                    </>
                  )}
                </Button>
              </div>
            </Card>

            <Card className="p-8 border-slate-200 dark:border-slate-800 rounded-[2rem] bg-white dark:bg-slate-900 shadow-xl shadow-slate-200/50 dark:shadow-none min-h-[300px] flex flex-col relative overflow-hidden">
              <div className="flex items-center justify-between mb-6 relative z-10">
                <h3 className="text-xl font-black text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2">
                  <FileText className="w-5 h-5 text-rose-600" />
                  Result
                </h3>
                {summary && (
                  <div className="flex gap-2">
                    <Button
                      onClick={handleCopy}
                      variant="ghost"
                      size="sm"
                      className="rounded-xl h-10 w-10 p-0 text-slate-400 hover:text-rose-600 hover:bg-rose-50"
                    >
                      <Copy className="w-4 h-4" />
                    </Button>
                  </div>
                )}
              </div>

              <div className="flex-1 relative z-10">
                {!summary && !isSummarizing && (
                  <div className="h-full flex flex-col items-center justify-center text-center py-12">
                    <div className="w-16 h-16 rounded-full bg-slate-50 dark:bg-slate-800 flex items-center justify-center mb-4">
                      <History className="w-8 h-8 text-slate-300" />
                    </div>
                    <p className="text-slate-400 font-bold uppercase tracking-widest text-xs">Ready for input</p>
                  </div>
                )}

                {isSummarizing && (
                  <div className="h-full flex flex-col items-center justify-center text-center py-12">
                    <Loader2 className="w-12 h-12 text-rose-500 animate-spin mb-4" />
                    <p className="text-slate-600 dark:text-slate-400 font-medium">AI is reading and condensing...</p>
                  </div>
                )}

                {summary && (
                  <div className="prose prose-slate dark:prose-invert max-w-none">
                    <div className="text-slate-700 dark:text-slate-300 leading-relaxed font-medium whitespace-pre-wrap">
                      {summary}
                    </div>
                  </div>
                )}
              </div>

              {/* Decorative Background for Summary Card */}
              <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-rose-50 dark:bg-rose-900/10 rounded-full blur-3xl -z-0"></div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
