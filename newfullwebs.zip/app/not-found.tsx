"use client"

import Link from "next/link"
import { Home, Search, ArrowLeft, Sparkles, Wrench } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function NotFound() {
  const popularTools = [
    { name: "Image Generator", href: "/image-gen", icon: "🎨" },
    { name: "Text Humanizer", href: "/text-humanizer", icon: "✍️" },
    { name: "PDF Merge", href: "/pdf-merge", icon: "📄" },
    { name: "QR Generator", href: "/qr-generator", icon: "📱" },
    { name: "Background Remover", href: "/background-remover", icon: "🖼️" },
    { name: "Password Generator", href: "/password-generator", icon: "🔐" },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50 flex items-center justify-center px-4 py-12">
      <div className="max-w-4xl w-full text-center">
        {/* Animated 404 Illustration */}
        <div className="relative mb-8">
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-64 h-64 bg-gradient-to-br from-blue-400/20 via-purple-400/20 to-amber-400/20 rounded-full blur-3xl animate-pulse" />
          </div>

          <div className="relative">
            {/* Large 404 Text */}
            <h1 className="text-[180px] md:text-[240px] font-black leading-none bg-gradient-to-br from-blue-600 via-purple-600 to-amber-500 bg-clip-text text-transparent select-none">
              404
            </h1>

            {/* Floating Icons */}
            <div className="absolute top-1/4 left-1/4 animate-bounce delay-100">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-2xl flex items-center justify-center shadow-lg transform rotate-12">
                <Search className="w-8 h-8 text-white" />
              </div>
            </div>

            <div className="absolute top-1/3 right-1/4 animate-bounce delay-300">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center shadow-lg transform -rotate-12">
                <Wrench className="w-8 h-8 text-white" />
              </div>
            </div>

            <div className="absolute bottom-1/4 left-1/3 animate-bounce delay-500">
              <div className="w-12 h-12 bg-gradient-to-br from-amber-500 to-orange-500 rounded-xl flex items-center justify-center shadow-lg transform rotate-6">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
            </div>
          </div>
        </div>

        {/* Error Message */}
        <div className="mb-8 space-y-3">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900">Oops! Page Not Found</h2>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto leading-relaxed">
            The page you're looking for seems to have wandered off into the digital void. Don't worry though, we've got
            plenty of amazing AI tools waiting for you!
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
          <Link href="/">
            <Button
              size="lg"
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-lg hover:shadow-xl transition-all duration-300 group"
            >
              <Home className="w-5 h-5 mr-2 group-hover:scale-110 transition-transform" />
              Back to Home
            </Button>
          </Link>

          <Link href="/about">
            <Button
              size="lg"
              variant="outline"
              className="border-2 border-slate-300 hover:border-blue-500 hover:bg-blue-50 transition-all duration-300 group bg-transparent"
            >
              <ArrowLeft className="w-5 h-5 mr-2 group-hover:-translate-x-1 transition-transform" />
              Learn More About Us
            </Button>
          </Link>
        </div>

        {/* Popular Tools */}
        <div className="bg-white/60 backdrop-blur-sm border border-slate-200 rounded-3xl p-8 shadow-xl">
          <div className="flex items-center justify-center gap-2 mb-6">
            <Sparkles className="w-5 h-5 text-amber-500" />
            <h3 className="text-xl font-bold text-slate-900">Try Our Popular Tools</h3>
            <Sparkles className="w-5 h-5 text-amber-500" />
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {popularTools.map((tool, index) => (
              <Link
                key={tool.href}
                href={tool.href}
                className="group relative overflow-hidden bg-gradient-to-br from-white to-slate-50 hover:from-blue-50 hover:to-purple-50 border border-slate-200 hover:border-blue-300 rounded-2xl p-4 transition-all duration-300 hover:shadow-lg hover:scale-105"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                {/* Corner Decoration */}
                <div className="absolute -top-8 -right-8 w-24 h-24 bg-gradient-to-br from-blue-400/20 to-purple-400/20 rounded-full blur-2xl group-hover:scale-150 transition-transform duration-500" />

                <div className="relative flex flex-col items-center gap-2">
                  <div className="text-4xl group-hover:scale-110 transition-transform duration-300">{tool.icon}</div>
                  <span className="text-sm font-semibold text-slate-700 group-hover:text-blue-600 transition-colors text-center">
                    {tool.name}
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* Help Text */}
        <p className="mt-8 text-sm text-slate-500">
          Still can't find what you're looking for?{" "}
          <Link href="/about" className="text-blue-600 hover:text-blue-700 font-semibold underline underline-offset-4">
            Contact us
          </Link>{" "}
          and we'll help you out!
        </p>
      </div>
    </div>
  )
}
