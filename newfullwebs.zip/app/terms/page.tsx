export const metadata = {
  title: "Terms of Service - SaasTools AI Toolkit",
  description: "Read our terms of service and user agreement for using SaasTools.",
}

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      <div className="max-w-4xl mx-auto px-4 py-20">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-purple-50 border border-purple-200 mb-6">
            <span className="text-xs font-bold text-purple-600 uppercase tracking-widest">Legal</span>
          </div>
          <h1 className="text-5xl md:text-6xl font-black text-slate-900 mb-6 tracking-tight">Terms of Service</h1>
          <p className="text-xl text-slate-500 font-medium">Last updated: December 24, 2024</p>
        </div>

        {/* Content */}
        <div className="prose prose-lg max-w-none">
          <div className="bg-white rounded-3xl p-8 md:p-12 shadow-lg border border-slate-200 mb-8">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Agreement to Terms</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              These Terms of Service constitute a legally binding agreement between you and SaasTools regarding your
              access to and use of our AI toolkit platform and services.
            </p>
            <p className="text-slate-600 leading-relaxed">
              By accessing or using our services, you agree to be bound by these Terms. If you disagree with any part of
              these terms, you may not access our services.
            </p>
          </div>

          <div className="bg-white rounded-3xl p-8 md:p-12 shadow-lg border border-slate-200 mb-8">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">User Accounts</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              When you create an account with us, you must provide accurate, complete, and current information at all
              times. Failure to do so constitutes a breach of the Terms.
            </p>
            <p className="text-slate-600 leading-relaxed mb-4">
              You are responsible for safeguarding your password and for all activities that occur under your account.
              You agree to immediately notify us of any unauthorized use of your account.
            </p>
            <ul className="list-disc list-inside text-slate-600 space-y-2">
              <li>You must be at least 18 years old to create an account</li>
              <li>One person or entity may maintain only one account</li>
              <li>You may not transfer your account to another person</li>
              <li>Account credentials must be kept confidential</li>
            </ul>
          </div>

          <div className="bg-white rounded-3xl p-8 md:p-12 shadow-lg border border-slate-200 mb-8">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Acceptable Use</h2>
            <p className="text-slate-600 leading-relaxed mb-4">You agree not to:</p>
            <ul className="list-disc list-inside text-slate-600 space-y-2">
              <li>Use our services for any illegal purpose or in violation of any laws</li>
              <li>Violate or infringe the rights of others, including intellectual property rights</li>
              <li>Transmit any malicious code, viruses, or harmful components</li>
              <li>Attempt to gain unauthorized access to our systems or networks</li>
              <li>Use our services to harass, abuse, or harm another person</li>
              <li>Generate or distribute spam, malware, or inappropriate content</li>
              <li>Reverse engineer, decompile, or disassemble our software</li>
              <li>Use automated systems to access the service without permission</li>
            </ul>
          </div>

          <div className="bg-white rounded-3xl p-8 md:p-12 shadow-lg border border-slate-200 mb-8">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Intellectual Property</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              The service and its original content, features, and functionality are and will remain the exclusive
              property of SaasTools and its licensors. Our service is protected by copyright, trademark, and other laws.
            </p>
            <h3 className="text-2xl font-bold text-slate-800 mb-3 mt-6">Your Content</h3>
            <p className="text-slate-600 leading-relaxed mb-4">
              You retain all rights to the content you submit, post, or display on or through the service. By submitting
              content, you grant us a worldwide, non-exclusive, royalty-free license to use, reproduce, modify, and
              distribute your content solely for the purpose of providing our services.
            </p>
            <p className="text-slate-600 leading-relaxed">
              Content generated by our AI tools belongs to you, subject to our license to provide the services and
              improve our AI models.
            </p>
          </div>

          <div className="bg-white rounded-3xl p-8 md:p-12 shadow-lg border border-slate-200 mb-8">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Subscription and Billing</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              Some parts of our service are billed on a subscription basis. You will be billed in advance on a recurring
              basis according to your chosen plan.
            </p>
            <ul className="list-disc list-inside text-slate-600 space-y-2 mb-4">
              <li>Subscriptions automatically renew unless canceled</li>
              <li>You can cancel your subscription at any time</li>
              <li>Refunds are provided according to our refund policy</li>
              <li>Price changes will be communicated in advance</li>
              <li>Failed payments may result in service suspension</li>
            </ul>
            <p className="text-slate-600 leading-relaxed">
              We reserve the right to refuse service to anyone for any reason at any time.
            </p>
          </div>

          <div className="bg-white rounded-3xl p-8 md:p-12 shadow-lg border border-slate-200 mb-8">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Limitation of Liability</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              In no event shall SaasTools, its directors, employees, partners, agents, suppliers, or affiliates be
              liable for any indirect, incidental, special, consequential, or punitive damages, including loss of
              profits, data, use, or goodwill.
            </p>
            <p className="text-slate-600 leading-relaxed">
              Our aggregate liability shall not exceed the amount you paid us in the twelve months prior to the event
              giving rise to the liability, or $100, whichever is greater.
            </p>
          </div>

          <div className="bg-white rounded-3xl p-8 md:p-12 shadow-lg border border-slate-200 mb-8">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Disclaimer</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              Our services are provided "as is" and "as available" without any warranties of any kind, either express or
              implied. We do not warrant that:
            </p>
            <ul className="list-disc list-inside text-slate-600 space-y-2">
              <li>The service will function uninterrupted or error-free</li>
              <li>Defects will be corrected</li>
              <li>The service is free of viruses or harmful components</li>
              <li>Results obtained from the service will be accurate or reliable</li>
            </ul>
          </div>

          <div className="bg-white rounded-3xl p-8 md:p-12 shadow-lg border border-slate-200 mb-8">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Termination</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              We may terminate or suspend your account and access to our services immediately, without prior notice, for
              any reason, including breach of these Terms.
            </p>
            <p className="text-slate-600 leading-relaxed">
              Upon termination, your right to use the service will immediately cease. All provisions of the Terms which
              by their nature should survive termination shall survive.
            </p>
          </div>

          <div className="bg-white rounded-3xl p-8 md:p-12 shadow-lg border border-slate-200 mb-8">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Changes to Terms</h2>
            <p className="text-slate-600 leading-relaxed">
              We reserve the right to modify these Terms at any time. We will notify users of any material changes by
              posting the new Terms on this page and updating the "Last updated" date. Your continued use of the service
              after changes constitutes acceptance of the modified Terms.
            </p>
          </div>

          <div className="bg-white rounded-3xl p-8 md:p-12 shadow-lg border border-slate-200">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Contact Us</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              If you have any questions about these Terms, please contact us:
            </p>
            <div className="bg-slate-50 rounded-2xl p-6 border border-slate-200">
              <p className="text-slate-700 font-semibold mb-2">Email: legal@saastools.com</p>
              <p className="text-slate-700 font-semibold">Address: 123 AI Street, Tech Valley, CA 94000</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
