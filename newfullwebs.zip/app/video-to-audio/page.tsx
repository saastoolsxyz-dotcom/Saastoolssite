"use client"

import type React from "react"

import { useState } from "react"
import { Upload, Home, Music, AlertCircle, Video } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"

export default function VideoToAudioPage() {
  const [video, setVideo] = useState<File | null>(null)
  const [format, setFormat] = useState("mp3")
  const [extracting, setExtracting] = useState(false)
  const { toast } = useToast()

  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file && file.type.startsWith("video/")) {
      setVideo(file)
    } else {
      toast({
        title: "Invalid File",
        description: "Please upload a video file",
        variant: "destructive",
      })
    }
  }

  const extractAudio = () => {
    if (!video) return
    setExtracting(true)
    setTimeout(() => {
      setExtracting(false)
      toast({
        title: "Audio Extracted!",
        description: `Saved as ${format.toUpperCase()}`,
      })
    }, 2000)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 via-pink-50 to-fuchsia-50 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <Link href="/">
            <Button variant="outline" className="gap-2 bg-transparent">
              <Home className="w-4 h-4" />
              Back to Home
            </Button>
          </Link>
        </div>

        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-rose-500 to-pink-500 mb-6 shadow-lg">
            <Music className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-5xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-rose-600 to-pink-600">
            Video to Audio
          </h1>
          <p className="text-xl text-slate-600">Extract audio from video files</p>
        </div>

        <div className="bg-white rounded-3xl shadow-2xl p-8 mb-8">
          <div className="border-2 border-dashed border-slate-300 rounded-2xl p-12 text-center hover:border-rose-500 transition-colors">
            <input type="file" accept="video/*" onChange={handleVideoUpload} className="hidden" id="video-upload" />
            <label htmlFor="video-upload" className="cursor-pointer">
              <Upload className="w-16 h-16 mx-auto mb-4 text-rose-500" />
              <p className="text-lg font-semibold text-slate-700 mb-2">Click to upload video</p>
              <p className="text-sm text-slate-500">MP4, MOV, AVI, WebM supported</p>
            </label>
          </div>

          <div className="mt-12 grid md:grid-cols-3 gap-6">
            <div className="p-6 rounded-2xl bg-rose-50/50 border border-rose-100">
              <div className="w-10 h-10 rounded-full bg-rose-500 text-white flex items-center justify-center font-bold mb-4">
                1
              </div>
              <h4 className="font-bold mb-2">Select Video</h4>
              <p className="text-sm text-slate-600">Upload your file to our **video to mp3** converter to start.</p>
            </div>
            <div className="p-6 rounded-2xl bg-rose-50/50 border border-rose-100">
              <div className="w-10 h-10 rounded-full bg-rose-500 text-white flex items-center justify-center font-bold mb-4">
                2
              </div>
              <h4 className="font-bold mb-2">Extracting Sound</h4>
              <p className="text-sm text-slate-600">Our tool will **extract audio from video** files in seconds.</p>
            </div>
            <div className="p-6 rounded-2xl bg-rose-50/50 border border-rose-100">
              <div className="w-10 h-10 rounded-full bg-rose-500 text-white flex items-center justify-center font-bold mb-4">
                3
              </div>
              <h4 className="font-bold mb-2">Save Audio</h4>
              <p className="text-sm text-slate-600">
                Use our **video to audio converter** to download your soundtrack.
              </p>
            </div>
          </div>

          {video && (
            <div className="mt-8">
              <div className="bg-slate-50 p-4 rounded-xl mb-6">
                <div className="flex items-center gap-3">
                  <Video className="w-5 h-5 text-rose-500" />
                  <p className="text-sm font-medium">{video.name}</p>
                </div>
              </div>

              <div className="mb-6">
                <label className="block text-sm font-medium mb-2">Audio format:</label>
                <Select value={format} onValueChange={setFormat}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="mp3">MP3</SelectItem>
                    <SelectItem value="wav">WAV</SelectItem>
                    <SelectItem value="aac">AAC</SelectItem>
                    <SelectItem value="ogg">OGG</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button onClick={extractAudio} disabled={extracting} className="w-full" size="lg">
                {extracting ? "Extracting..." : "Extract Audio"}
              </Button>
            </div>
          )}
        </div>

        <div className="prose prose-slate max-w-none bg-white/50 backdrop-blur rounded-3xl p-8 shadow-sm border border-slate-200 mb-8">
          <h2 className="text-2xl font-bold mb-4">High-Fidelity Video to Audio Extraction Tool</h2>
          <p className="text-slate-600 mb-4">
            If you need to quickly **video to mp3**, SaasTools.xyz offers a high-performance solution that handles all
            popular formats. Our advanced technology allows you to **extract audio from video** with zero loss in sound
            quality, making it ideal for creating podcasts, ringtones, or music libraries. This reliable **video to
            audio converter** is built for speed, ensuring that you can get the audio track you need without waiting for
            complex software to load.
          </p>
          <p className="text-slate-600">
            Our platform is the ultimate choice for anyone looking to **extract audio from video** seamlessly. As a
            professional-grade **video to audio converter**, we support high bitrates to ensure your **video to mp3**
            conversion sounds professional and clear. Experience the fastest and most efficient way to turn your video
            content into standalone audio files today.
          </p>
        </div>

        <div className="bg-rose-50 rounded-2xl p-6 border border-rose-100">
          <div className="flex gap-3">
            <AlertCircle className="w-5 h-5 text-rose-600 flex-shrink-0 mt-0.5" />
            <div className="text-sm text-rose-900">
              <p className="font-semibold mb-1">Keywords for SEO:</p>
              <p className="text-rose-700">
                video to mp3, extract audio from video, video to audio converter, convert video to audio, rip audio
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
