"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Upload, Download, Loader2, X, Scissors, ImageIcon, Home } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"
import { removeBackground } from "@/services/gemini"

export default function BackgroundRemoverPage() {
  const [originalImage, setOriginalImage] = useState<string | null>(null)
  const [processedImage, setProcessedImage] = useState<string | null>(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const [fileName, setFileName] = useState("")
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()
  const abortControllerRef = useRef<AbortController | null>(null)

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    if (!file.type.startsWith("image/")) {
      toast({
        title: "Invalid File",
        description: "Please select an image file.",
        variant: "destructive",
      })
      return
    }

    setFileName(file.name)
    const reader = new FileReader()
    reader.onload = (e) => {
      setOriginalImage(e.target?.result as string)
      setProcessedImage(null)
    }
    reader.readAsDataURL(file)
  }

  const handleRemoveBackground = async () => {
    if (!originalImage) return

    setIsProcessing(true)
    abortControllerRef.current = new AbortController()

    try {
      const blob = await fetch(originalImage).then((r) => r.blob())
      const file = new File([blob], fileName, { type: blob.type })

      const base64Result = await removeBackground(file, "bg-remover", abortControllerRef.current.signal)
      setProcessedImage(`data:image/png;base64,${base64Result}`)

      toast({
        title: "Success",
        description: "Background removed successfully!",
      })
    } catch (error: any) {
      if (error.name === "AbortError") {
        toast({
          title: "Cancelled",
          description: "Background removal cancelled.",
        })
      } else {
        toast({
          title: "Error",
          description: error.message || "Failed to remove background.",
          variant: "destructive",
        })
      }
    } finally {
      setIsProcessing(false)
      abortControllerRef.current = null
    }
  }

  const handleCancel = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort()
    }
  }

  const handleDownload = () => {
    if (!processedImage) return
    const link = document.createElement("a")
    link.href = processedImage
    link.download = `no-bg-${fileName}`
    link.click()
  }

  const handleReset = () => {
    setOriginalImage(null)
    setProcessedImage(null)
    setFileName("")
    if (fileInputRef.current) fileInputRef.current.value = ""
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-pink-50 to-white py-20 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <Button onClick={() => (window.location.href = "/")} variant="outline" className="rounded-2xl">
            <Home className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
        </div>

        <div className="text-center mb-16">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-pink-500 to-rose-600 shadow-xl shadow-pink-200 mb-6">
            <Scissors className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-5xl md:text-6xl font-bold text-slate-900 mb-4">Background Remover</h1>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto">
            Remove backgrounds from images instantly with AI-powered precision
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-8">
          <Card className="p-8 bg-white/50 backdrop-blur-sm border-2 border-slate-200 rounded-3xl">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
                <ImageIcon className="w-6 h-6 text-pink-500" />
                Original
              </h3>
              {originalImage && (
                <Button variant="ghost" size="sm" onClick={handleReset}>
                  <X className="w-4 h-4 mr-2" />
                  Clear
                </Button>
              )}
            </div>

            {!originalImage ? (
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-4 border-dashed border-slate-300 rounded-2xl p-12 text-center cursor-pointer hover:border-pink-500 transition-all hover:bg-pink-50"
              >
                <Upload className="w-16 h-16 text-slate-400 mx-auto mb-4" />
                <p className="text-slate-600 font-medium mb-2">Click to upload an image</p>
                <p className="text-sm text-slate-400">PNG, JPG, WebP supported</p>
                <input ref={fileInputRef} type="file" accept="image/*" onChange={handleFileSelect} className="hidden" />
              </div>
            ) : (
              <div className="relative rounded-2xl overflow-hidden bg-[repeating-conic-gradient(#e5e7eb_0%_25%,white_0%_50%)] bg-[length:20px_20px]">
                <img src={originalImage || "/placeholder.svg"} alt="Original" className="w-full h-auto" />
              </div>
            )}
          </Card>

          <Card className="p-8 bg-white/50 backdrop-blur-sm border-2 border-slate-200 rounded-3xl">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
                <Scissors className="w-6 h-6 text-pink-500" />
                Processed
              </h3>
              {processedImage && (
                <Button onClick={handleDownload} size="sm" className="bg-pink-600 hover:bg-pink-700">
                  <Download className="w-4 h-4 mr-2" />
                  Download
                </Button>
              )}
            </div>

            {!processedImage && !isProcessing && (
              <div className="border-4 border-dashed border-slate-300 rounded-2xl p-12 text-center h-[400px] flex items-center justify-center">
                <div>
                  <Scissors className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                  <p className="text-slate-400">Processed image will appear here</p>
                </div>
              </div>
            )}

            {isProcessing && (
              <div className="border-4 border-dashed border-pink-300 rounded-2xl p-12 text-center h-[400px] flex items-center justify-center bg-pink-50">
                <div>
                  <Loader2 className="w-16 h-16 text-pink-500 mx-auto mb-4 animate-spin" />
                  <p className="text-slate-700 font-medium">Removing background...</p>
                </div>
              </div>
            )}

            {processedImage && (
              <div className="relative rounded-2xl overflow-hidden bg-[repeating-conic-gradient(#e5e7eb_0%_25%,white_0%_50%)] bg-[length:20px_20px]">
                <img src={processedImage || "/placeholder.svg"} alt="Processed" className="w-full h-auto" />
              </div>
            )}
          </Card>
        </div>

        <div className="flex justify-center gap-4">
          {isProcessing ? (
            <Button onClick={handleCancel} variant="outline" size="lg" className="rounded-2xl px-8 bg-transparent">
              Cancel
            </Button>
          ) : (
            <Button
              onClick={handleRemoveBackground}
              disabled={!originalImage || isProcessing}
              size="lg"
              className="bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-700 hover:to-rose-700 text-white rounded-2xl px-12 py-6 text-lg font-bold shadow-xl shadow-pink-200"
            >
              <Scissors className="w-5 h-5 mr-2" />
              Remove Background
            </Button>
          )}
        </div>
      </div>
    </div>
  )
}
