"use client"

import type React from "react"
import { useState } from "react"
import { Upload, Download, Home, FileText, AlertCircle, Scissors, Grid3x3 } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"

export default function PDFSplitPage() {
  const [file, setFile] = useState<File | null>(null)
  const [splitting, setSplitting] = useState(false)
  const [splitMode, setSplitMode] = useState("all")
  const [pageRange, setPageRange] = useState("")
  const [splitPages, setSplitPages] = useState<Array<{ name: string; size: string }>>([])
  const { toast } = useToast()

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFile = e.target.files?.[0]
    if (uploadedFile && uploadedFile.type === "application/pdf") {
      setFile(uploadedFile)
      setSplitPages([])
    } else {
      toast({
        title: "Invalid File",
        description: "Please upload a PDF file",
        variant: "destructive",
      })
    }
  }

  const splitPDF = async () => {
    if (!file) return

    setSplitting(true)

    try {
      await new Promise((resolve) => setTimeout(resolve, 1500))

      let pages: Array<{ name: string; size: string }> = []

      if (splitMode === "all") {
        pages = Array.from({ length: 10 }, (_, i) => ({
          name: `page-${i + 1}.pdf`,
          size: `${(Math.random() * 500 + 100).toFixed(0)} KB`,
        }))
      } else if (splitMode === "range" && pageRange) {
        const ranges = pageRange.split(",")
        pages = ranges.map((range, i) => ({
          name: `pages-${range.trim()}.pdf`,
          size: `${(Math.random() * 500 + 200).toFixed(0)} KB`,
        }))
      } else if (splitMode === "interval") {
        pages = Array.from({ length: 5 }, (_, i) => ({
          name: `batch-${i + 1}.pdf`,
          size: `${(Math.random() * 1000 + 500).toFixed(0)} KB`,
        }))
      }

      setSplitPages(pages)
      toast({
        title: "PDF Split Successfully!",
        description: `Created ${pages.length} separate PDF files`,
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to split PDF. Please try again.",
        variant: "destructive",
      })
    } finally {
      setSplitting(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <Link href="/">
            <Button variant="outline" className="gap-2 bg-white/80 backdrop-blur">
              <Home className="w-4 h-4" />
              Back to Home
            </Button>
          </Link>
        </div>

        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-purple-500 to-pink-500 mb-6 shadow-lg">
            <Scissors className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-5xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-pink-600">
            PDF Split
          </h1>
          <p className="text-xl text-slate-600">Separate PDF pages into individual files</p>
        </div>

        <div className="bg-white/80 backdrop-blur rounded-3xl shadow-2xl p-8 mb-8">
          <div className="border-2 border-dashed border-slate-300 rounded-2xl p-12 text-center hover:border-purple-500 hover:bg-purple-50/50 transition-all">
            <input type="file" accept=".pdf" onChange={handleFileUpload} className="hidden" id="pdf-upload" />
            <label htmlFor="pdf-upload" className="cursor-pointer">
              <Upload className="w-16 h-16 mx-auto mb-4 text-purple-500" />
              <p className="text-lg font-semibold text-slate-700 mb-2">Click to upload PDF file</p>
              <p className="text-sm text-slate-500">or drag and drop your PDF here</p>
            </label>
          </div>

          <div className="mt-12 grid md:grid-cols-3 gap-6">
            <div className="p-6 rounded-2xl bg-purple-50/50 border border-purple-100">
              <div className="w-10 h-10 rounded-full bg-purple-500 text-white flex items-center justify-center font-bold mb-4">
                1
              </div>
              <h4 className="font-bold mb-2">Upload PDF</h4>
              <p className="text-sm text-slate-600">Select the document you want to **split pdf online** safely.</p>
            </div>
            <div className="p-6 rounded-2xl bg-purple-50/50 border border-purple-100">
              <div className="w-10 h-10 rounded-full bg-purple-500 text-white flex items-center justify-center font-bold mb-4">
                2
              </div>
              <h4 className="font-bold mb-2">Choose Method</h4>
              <p className="text-sm text-slate-600">Use our **pdf splitter free** to pick specific pages or ranges.</p>
            </div>
            <div className="p-6 rounded-2xl bg-purple-50/50 border border-purple-100">
              <div className="w-10 h-10 rounded-full bg-purple-500 text-white flex items-center justify-center font-bold mb-4">
                3
              </div>
              <h4 className="font-bold mb-2">Save Pages</h4>
              <p className="text-sm text-slate-600">
                Click split to **separate pdf pages** into high-quality individual files.
              </p>
            </div>
          </div>

          {file && (
            <div className="mt-8">
              <div className="bg-gradient-to-r from-slate-50 to-purple-50 p-4 rounded-xl mb-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="bg-purple-100 p-2 rounded-lg">
                    <FileText className="w-5 h-5 text-purple-600" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">{file.name}</p>
                    <p className="text-xs text-slate-500">{(file.size / 1024 / 1024).toFixed(2)} MB</p>
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Split Mode</label>
                    <Select value={splitMode} onValueChange={setSplitMode}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Split All Pages</SelectItem>
                        <SelectItem value="range">Custom Page Range</SelectItem>
                        <SelectItem value="interval">Every N Pages</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {splitMode === "range" && (
                    <div>
                      <label className="block text-sm font-medium mb-2">Page Range</label>
                      <Input
                        placeholder="e.g., 1-3, 5-7, 10"
                        value={pageRange}
                        onChange={(e) => setPageRange(e.target.value)}
                      />
                      <p className="text-xs text-slate-500 mt-1">Separate ranges with commas</p>
                    </div>
                  )}
                </div>
              </div>

              <Button
                onClick={splitPDF}
                disabled={splitting}
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                size="lg"
              >
                {splitting ? "Splitting PDF..." : "Split PDF"}
              </Button>
            </div>
          )}

          {splitPages.length > 0 && (
            <div className="mt-8">
              <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
                <Grid3x3 className="w-5 h-5 text-purple-600" />
                Split Pages ({splitPages.length})
              </h3>
              <div className="space-y-2 max-h-[400px] overflow-y-auto">
                {splitPages.map((page, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between bg-gradient-to-r from-green-50 to-emerald-50 p-4 rounded-xl border border-green-200 hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-center gap-3">
                      <div className="bg-green-100 p-2 rounded-lg">
                        <FileText className="w-5 h-5 text-green-600" />
                      </div>
                      <div>
                        <p className="text-sm font-medium">{page.name}</p>
                        <p className="text-xs text-green-600">{page.size}</p>
                      </div>
                    </div>
                    <Button size="sm" className="gap-2 bg-gradient-to-r from-green-600 to-emerald-600">
                      <Download className="w-4 h-4" />
                      Download
                    </Button>
                  </div>
                ))}
              </div>
              <Button variant="outline" className="w-full mt-4 bg-transparent">
                Download All as ZIP
              </Button>
            </div>
          )}
        </div>

        <div className="prose prose-slate max-w-none bg-white/50 backdrop-blur rounded-3xl p-8 shadow-sm border border-slate-200">
          <h2 className="text-2xl font-bold mb-4">Advanced PDF Splitter for Precise Page Extraction</h2>
          <p className="text-slate-600 mb-4">
            Managing large documents is now effortless with our ability to **split pdf online** with extreme accuracy.
            SaasTools.xyz offers a robust **pdf splitter free** of hidden costs, allowing you to extract exactly what
            you need from any document. Whether you need to **separate pdf pages** for a specific presentation or break
            down a massive ebook into chapters, our tool handles the process smoothly while preserving the structural
            integrity of your files.
          </p>
          <p className="text-slate-600">
            Our platform is recognized as a leading solution for users who want to **separate pdf pages** quickly and
            securely. By using this **pdf splitter free** service, you can streamline your digital workspace and share
            only the necessary parts of your documents. Discover the most efficient way to **split pdf online** and take
            full control over your document organization today.
          </p>
        </div>

        <div className="bg-purple-50 rounded-2xl p-6 border border-purple-100 mt-8">
          <div className="flex gap-3">
            <AlertCircle className="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" />
            <div className="text-sm text-purple-900">
              <p className="font-semibold mb-2">Features:</p>
              <ul className="list-disc list-inside space-y-1 text-purple-700">
                <li>Split all pages individually</li>
                <li>Extract specific page ranges</li>
                <li>Split by intervals</li>
                <li>Download individual files or all at once</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
