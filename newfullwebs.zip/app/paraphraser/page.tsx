"use client"

import { useState } from "react"
import { Home, RefreshCw, Copy, AlertCircle } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import { generateText } from "@/services/gemini"

export default function ParaphraserPage() {
  const [inputText, setInputText] = useState("")
  const [outputText, setOutputText] = useState("")
  const [loading, setLoading] = useState(false)
  const { toast } = useToast()

  const paraphraseText = async () => {
    if (!inputText.trim()) {
      toast({
        title: "No Input",
        description: "Please enter some text to paraphrase",
        variant: "destructive",
      })
      return
    }

    setLoading(true)
    try {
      const result = await generateText(
        `Paraphrase the following text while maintaining the original meaning. Make it sound natural and human-written:\n\n${inputText}`,
        "paraphraser",
      )
      setOutputText(result)
      toast({
        title: "Paraphrased Successfully!",
        description: "Your text has been rephrased",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to paraphrase text",
        variant: "destructive",
      })
    }
    setLoading(false)
  }

  const copyToClipboard = () => {
    navigator.clipboard.writeText(outputText)
    toast({
      title: "Copied!",
      description: "Text copied to clipboard",
    })
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-yellow-50 to-orange-50 py-12 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <Link href="/">
            <Button variant="outline" className="gap-2 bg-transparent">
              <Home className="w-4 h-4" />
              Back to Home
            </Button>
          </Link>
        </div>

        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-amber-500 to-orange-500 mb-6 shadow-lg">
            <RefreshCw className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-5xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-amber-600 to-orange-600">
            AI Paraphraser
          </h1>
          <p className="text-xl text-slate-600">Rephrase text while keeping the meaning</p>
        </div>

        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <div className="bg-white rounded-3xl shadow-2xl p-8">
            <h3 className="font-bold text-lg mb-4">Original Text</h3>
            <Textarea
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Enter text to paraphrase..."
              className="min-h-[300px] text-base"
            />
          </div>

          <div className="bg-white rounded-3xl shadow-2xl p-8">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-lg">Paraphrased Text</h3>
              {outputText && (
                <Button variant="ghost" size="sm" onClick={copyToClipboard}>
                  <Copy className="w-4 h-4 mr-2" />
                  Copy
                </Button>
              )}
            </div>
            <Textarea
              value={outputText}
              readOnly
              placeholder="Paraphrased text will appear here..."
              className="min-h-[300px] text-base bg-slate-50"
            />
          </div>
        </div>

        <div className="mt-8 mb-12 grid md:grid-cols-3 gap-6">
          <div className="p-6 rounded-2xl bg-amber-50/50 border border-amber-100">
            <div className="w-10 h-10 rounded-full bg-amber-500 text-white flex items-center justify-center font-bold mb-4">
              1
            </div>
            <h4 className="font-bold mb-2">Input Content</h4>
            <p className="text-sm text-slate-600">Paste your text into the **paraphrase tool** to begin the process.</p>
          </div>
          <div className="p-6 rounded-2xl bg-amber-50/50 border border-amber-100">
            <div className="w-10 h-10 rounded-full bg-amber-500 text-white flex items-center justify-center font-bold mb-4">
              2
            </div>
            <h4 className="font-bold mb-2">Rephrase AI</h4>
            <p className="text-sm text-slate-600">Click generate to **rephrase text online** with natural AI output.</p>
          </div>
          <div className="p-6 rounded-2xl bg-amber-50/50 border border-amber-100">
            <div className="w-10 h-10 rounded-full bg-amber-500 text-white flex items-center justify-center font-bold mb-4">
              3
            </div>
            <h4 className="font-bold mb-2">Copy Results</h4>
            <p className="text-sm text-slate-600">Instantly use our **ai paraphraser** output for your projects.</p>
          </div>
        </div>

        <div className="text-center">
          <Button onClick={paraphraseText} disabled={loading} size="lg" className="px-12">
            {loading ? "Paraphrasing..." : "Paraphrase Text"}
          </Button>
        </div>

        <div className="prose prose-slate max-w-none bg-white/50 backdrop-blur rounded-3xl p-8 shadow-sm border border-slate-200 mt-12 mb-8">
          <h2 className="text-2xl font-bold mb-4">Intelligent AI Paraphraser for Unique and Natural Content</h2>
          <p className="text-slate-600 mb-4">
            Our **paraphrase tool** is the perfect companion for writers and students who need to **rephrase text
            online** while maintaining the original context. SaasTools.xyz uses sophisticated algorithms to provide an
            **ai paraphraser** experience that goes beyond simple word swapping, ensuring that your rewritten content
            sounds natural and professional. Whether you are avoiding plagiarism or simply trying to improve the flow of
            your writing, our tool delivers high-quality results.
          </p>
          <p className="text-slate-600">
            By using this advanced **ai paraphraser**, you can significantly speed up your content creation process. The
            ability to **rephrase text online** quickly is essential in today's digital landscape, and our **paraphrase
            tool** is optimized for both speed and accuracy. Transform your writing today with the most reliable
            rephrasing technology available online.
          </p>
        </div>

        <div className="mt-8 bg-amber-50 rounded-2xl p-6 border border-amber-100">
          <div className="flex gap-3">
            <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
            <div className="text-sm text-amber-900">
              <p className="font-semibold mb-1">Keywords for SEO:</p>
              <p className="text-amber-700">
                paraphrase tool, rephrase text online, ai paraphraser, rewrite text, paraphrasing tool free
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
