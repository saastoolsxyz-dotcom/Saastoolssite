export interface ToolConfig {
  provider: 'google' | 'openrouter' | 'huggingface';
  apiKey: string;
  model: string;
}

export interface AdminSettings {
  passwordHash: string;
  globalText: ToolConfig;
  globalImage: ToolConfig;
  tools: Record<string, ToolConfig>;
}

const DEFAULT_SETTINGS: AdminSettings = {
  passwordHash: '12wq@dogar#A',
  globalText: {
    provider: 'google',
    apiKey: '',
    model: 'gemini-3-flash-preview',
  },
  globalImage: {
    provider: 'google',
    apiKey: '',
    model: 'gemini-2.5-flash-image',
  },
  tools: {
    'bg-remover': {
      provider: 'huggingface',
      apiKey: '',
      model: 'briaai/RMBG-1.4'
    }
  }
};

const STORAGE_KEY = 'saas_tools_admin_v5'; 
const AUTH_KEY = 'saas_tools_auth_session';

export const getSettings = (): AdminSettings => {
  const stored = localStorage.getItem(STORAGE_KEY);
  if (!stored) return DEFAULT_SETTINGS;
  try {
    const parsed = JSON.parse(stored);
    return { ...DEFAULT_SETTINGS, ...parsed };
  } catch {
    return DEFAULT_SETTINGS;
  }
};

export const saveSettings = (settings: AdminSettings) => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
};

const getToolCategory = (toolId: string): 'text' | 'image' => {
  if (toolId === 'image-gen' || toolId === 'bg-remover' || toolId === 'analyzer') return 'image';
  return 'text'; 
};

export const getToolConfig = (toolId: string): ToolConfig => {
  const settings = getSettings();
  const specific = settings.tools[toolId];
  const category = getToolCategory(toolId);
  const globalConfig = category === 'image' ? settings.globalImage : settings.globalText;

  // 1. Determine the active provider (BG Remover defaults to HF)
  let provider = specific?.provider;
  if (!provider) {
    provider = toolId === 'bg-remover' ? 'huggingface' : globalConfig.provider;
  }

  // 2. Logic for API Key
  let apiKey = specific?.apiKey || '';
  if (!apiKey && provider === globalConfig.provider) {
    apiKey = globalConfig.apiKey;
  }
  
  // Fallback for Google to Env Var
  if (!apiKey && provider === 'google') {
    apiKey = process.env.API_KEY || '';
  }

  // 3. Logic for Model
  let model = specific?.model || '';
  if (!model && provider === globalConfig.provider) {
    model = globalConfig.model;
  }
  
  if (!model) {
    if (provider === 'google') model = category === 'image' ? 'gemini-2.5-flash-image' : 'gemini-3-flash-preview';
    else if (provider === 'openrouter') model = 'mistralai/mistral-7b-instruct';
    else if (provider === 'huggingface') {
        model = toolId === 'bg-remover' ? 'briaai/RMBG-1.4' : 'gpt2';
    }
  }

  return { provider, apiKey, model };
};

export const isAuthenticated = (): boolean => {
  return sessionStorage.getItem(AUTH_KEY) === 'true';
};

export const login = (password: string): boolean => {
  const settings = getSettings();
  if (password === settings.passwordHash) {
    sessionStorage.setItem(AUTH_KEY, 'true');
    return true;
  }
  return false;
};

export const logout = () => {
  sessionStorage.removeItem(AUTH_KEY);
};
