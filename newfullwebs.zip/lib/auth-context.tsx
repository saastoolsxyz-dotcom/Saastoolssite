"use client"

import type React from "react"

import { createContext, useContext, useEffect, useState } from "react"
import {
  type User,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut as firebaseSignOut,
  sendPasswordResetEmail,
} from "firebase/auth"
import { auth, isAdmin } from "./firebase"

interface AuthContextType {
  user: User | null
  loading: boolean
  isAdmin: boolean
  signIn: (email: string, password: string) => Promise<void>
  signUp: (email: string, password: string) => Promise<void>
  signOut: () => Promise<void>
  resetPassword: (email: string) => Promise<void>
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  loading: true,
  isAdmin: false,
  signIn: async () => {},
  signUp: async () => {},
  signOut: async () => {},
  resetPassword: async () => {},
})

export const useAuth = () => useContext(AuthContext)

const isPreviewMode = typeof window !== "undefined" && window.location.hostname.includes("v0.app")

const createMockUser = (email: string): User => ({
  uid: "preview-user-id",
  email,
  emailVerified: true,
  isAnonymous: false,
  metadata: {},
  providerData: [],
  refreshToken: "",
  tenantId: null,
  delete: async () => {},
  getIdToken: async () => "",
  getIdTokenResult: async () => ({}) as any,
  reload: async () => {},
  toJSON: () => ({}),
  displayName: null,
  phoneNumber: null,
  photoURL: null,
  providerId: "firebase",
})

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!auth) {
      console.error("[v0] Firebase auth not initialized")
      setLoading(false)
      return
    }

    if (isPreviewMode) {
      const storedUser = localStorage.getItem("preview_user")
      if (storedUser) {
        const userData = JSON.parse(storedUser)
        setUser(createMockUser(userData.email))
      }
      setLoading(false)
      return
    }

    // Real Firebase auth for production
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUser(user)
      setLoading(false)
    })

    return unsubscribe
  }, [])

  const signIn = async (email: string, password: string) => {
    if (isPreviewMode) {
      // Simulate network delay
      await new Promise((resolve) => setTimeout(resolve, 500))

      // Get stored users
      const users = JSON.parse(localStorage.getItem("preview_users") || "[]")
      const existingUser = users.find((u: any) => u.email === email)

      if (!existingUser || existingUser.password !== password) {
        throw new Error("Invalid email or password")
      }

      const mockUser = createMockUser(email)
      setUser(mockUser)
      localStorage.setItem("preview_user", JSON.stringify({ email }))
      return
    }

    if (!auth) {
      throw new Error("Firebase auth not initialized")
    }

    // Real Firebase auth for production
    await signInWithEmailAndPassword(auth, email, password)
  }

  const signUp = async (email: string, password: string) => {
    if (isPreviewMode) {
      // Simulate network delay
      await new Promise((resolve) => setTimeout(resolve, 500))

      // Get stored users
      const users = JSON.parse(localStorage.getItem("preview_users") || "[]")
      const existingUser = users.find((u: any) => u.email === email)

      if (existingUser) {
        throw new Error("Email already in use")
      }

      // Store new user
      users.push({ email, password })
      localStorage.setItem("preview_users", JSON.stringify(users))

      const mockUser = createMockUser(email)
      setUser(mockUser)
      localStorage.setItem("preview_user", JSON.stringify({ email }))
      return
    }

    if (!auth) {
      throw new Error("Firebase auth not initialized")
    }

    // Real Firebase auth for production
    await createUserWithEmailAndPassword(auth, email, password)
  }

  const signOut = async () => {
    if (isPreviewMode) {
      localStorage.removeItem("preview_user")
      setUser(null)
      return
    }

    if (!auth) {
      throw new Error("Firebase auth not initialized")
    }

    // Real Firebase auth for production
    await firebaseSignOut(auth)
  }

  const resetPassword = async (email: string) => {
    if (isPreviewMode) {
      await new Promise((resolve) => setTimeout(resolve, 500))
      // In preview mode, just simulate success
      return
    }

    if (!auth) {
      throw new Error("Firebase auth not initialized")
    }

    // Real Firebase auth for production
    await sendPasswordResetEmail(auth, email)
  }

  const value = {
    user,
    loading,
    isAdmin: isAdmin(user?.email || null),
    signIn,
    signUp,
    signOut,
    resetPassword,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}
