"use client"

import { initializeApp, getApps, type FirebaseApp } from "firebase/app"
import { getAuth, type Auth } from "firebase/auth"
import { getDatabase, type Database } from "firebase/database"

const firebaseConfig = {
  apiKey: "AIzaSyB-XiNqFarskIE7swy4kZvc-EnBBCkhuzo",
  authDomain: "asad-ecaad.firebaseapp.com",
  databaseURL: "https://asad-ecaad-default-rtdb.firebaseio.com",
  projectId: "asad-ecaad",
  storageBucket: "asad-ecaad.firebasestorage.app",
  messagingSenderId: "320496179933",
  appId: "1:320496179933:web:8515c812fb6a9ee8bad934",
  measurementId: "G-47DWHE06ZQ",
}

let app: FirebaseApp | undefined
let auth: Auth | undefined
let database: Database | undefined

if (typeof window !== "undefined") {
  try {
    app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0]
    auth = getAuth(app)
    database = getDatabase(app)
  } catch (error) {
    console.error("[v0] Firebase initialization error:", error)
  }
}

// Export with fallback
export { auth, database }

// Admin email constant
export const ADMIN_EMAIL = "saastools.xyz@gmail.com"

// Check if user is admin
export const isAdmin = (email: string | null) => {
  return email?.toLowerCase() === ADMIN_EMAIL.toLowerCase()
}
